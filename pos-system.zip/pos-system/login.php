<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts (Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Apply the Inter font family */
        body {
            font-family: 'Inter', sans-serif;
        }
        /* Define custom colors based on the image for reusability */
        .custom-teal {
            background-color: #167771;
        }
        .custom-teal-text {
            color: #167771;
        }
        .custom-teal-hover:hover {
            background-color: #12635e; /* A slightly darker teal for hover */
        }
        .focus-ring-custom-teal:focus {
            --tw-ring-color: #167771;
        }
    </style>
</head>
<body class="bg-white flex items-center justify-center min-h-screen p-4">

    <!-- Login Card Container -->
    <div class="bg-white rounded-3xl shadow-lg p-8 max-w-sm w-full">
        
        <div class="flex flex-col items-center">
            <!-- Logo -->
            <div class="custom-teal text-white font-semibold py-2 px-8 rounded-lg mb-8">
                LOGO
            </div>

            <!-- Welcome Text -->
            <h1 class="text-2xl font-bold text-gray-900">Welcome back</h1>
            <p class="text-gray-500 mt-1 text-sm">Sign in to your account</p>
        </div>

        <form class="mt-8 space-y-6">
            <!-- Email Address Input -->
            <div>
                <label for="email" class="block text-sm font-medium text-gray-700">Email address</label>
                <div class="mt-1 relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                         <!-- Envelope Icon -->
                         <svg class="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path d="M3 4a2 2 0 00-2 2v1.161l8.441 4.221a1.25 1.25 0 001.118 0L19 7.162V6a2 2 0 00-2-2H3z" />
                            <path d="M19 8.839l-7.77 3.885a2.75 2.75 0 01-2.46 0L1 8.839V14a2 2 0 002 2h14a2 2 0 002-2V8.839z" />
                        </svg>
                    </div>
                    <input id="email" name="email" type="email" autocomplete="email" required class="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg placeholder-gray-400 focus:outline-none focus:ring-1 focus-ring-custom-teal focus:border-[#167771] sm:text-sm" placeholder="Enter your email">
                </div>
            </div>

            <!-- Password Input -->
            <div>
                <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                <div class="mt-1 relative">
                     <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <!-- Lock Icon -->
                        <svg class="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                          <path fill-rule="evenodd" d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <input id="password" name="password" type="password" autocomplete="current-password" required class="block w-full pl-10 pr-10 py-3 border border-gray-300 rounded-lg placeholder-gray-400 focus:outline-none focus:ring-1 focus-ring-custom-teal focus:border-[#167771] sm:text-sm" value="••••••••">
                     <div class="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer">
                        <!-- Eye Icon -->
                        <svg class="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.432 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
                          <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Remember me & Forgot password -->
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <input id="remember-me" name="remember-me" type="checkbox" class="h-4 w-4 custom-teal-text border-gray-300 rounded focus:ring-0 focus-ring-custom-teal">
                    <label for="remember-me" class="ml-2 block text-sm text-gray-600">Remember me</label>
                </div>

                <div class="text-sm">
                    <a href="#" class="font-semibold custom-teal-text hover:underline">Forgot password?</a>
                </div>
            </div>

            <!-- CAPTCHA Placeholder -->
            <div class="w-full text-center border border-gray-300 rounded-lg py-8">
                <p class="text-sm text-gray-500">CAPTCHA will appear here</p>
            </div>

            <!-- Sign In Button -->
            <div>
                <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-semibold text-white custom-teal custom-teal-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus-ring-custom-teal">
                    Sign in
                </button>
            </div>
        </form>

        <!-- Footer Text -->
        <div class="mt-8 text-center text-sm">
            <p class="text-gray-500">
                Don't have an account? 
                <a href="#" class="font-semibold custom-teal-text hover:underline">Contact your administrator</a>
            </p>
        </div>
    </div>

</body>
</html>