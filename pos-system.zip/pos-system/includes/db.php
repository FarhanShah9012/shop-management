<?php
// Database configuration
$host = 'localhost';       // Database host (usually 'localhost')
$dbname = 'mobiles_pos';   // Name of the database
$username = 'root';        // Database username (default is 'root' for local setups)
$password = 'MysqldatabasE.9012';            // Database password (default is empty for local setups)

// Create a new MySQLi connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the character set to UTF-8 for proper encoding
$conn->set_charset("utf8");