<script src="https://cdn.tailwindcss.com"></script>
<?php
// Get current file name without extension to use as page heading
$pageTitle = basename($_SERVER['PHP_SELF'], ".php");

// Format page title (e.g., replace hyphens with spaces and capitalize)
$heading = ucwords(str_replace("-", " ", $pageTitle));
?>

<header class="bg-white shadow px-6 py-4 mb-4">
    <div class="max-w-7xl mx-auto flex justify-between items-center">
        <h1 class="text-2xl font-semibold text-gray-800"><?= $heading ?></h1>
    </div>
</header>
