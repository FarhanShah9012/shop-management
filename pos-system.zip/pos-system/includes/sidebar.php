<!-- Tailwind CSS CDN -->
<script src="https://cdn.tailwindcss.com"></script>
<!-- sidebar.html -->
<div id="sidebar" class="fixed inset-y-0 left-0 z-30 w-64 bg-gray-800 text-white flex flex-col transition-all duration-300 ease-in-out">
  <!-- Logo/Header Section -->
  <div class="flex items-center p-4 border-b border-gray-700">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
    </svg>
    <span class="ml-3 text-xl font-bold">BusinessPOS</span>
  </div>

  <!-- Navigation Items -->
  <nav class="flex-1 px-2 py-4">
    <ul class="space-y-1">
      <!-- Dashboard Link -->
      <li>
        <a href="/pos-system/pages/dashboard.php" class="flex items-center p-3 rounded-lg hover:bg-gray-700 transition-colors duration-200">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
          </svg>
          <span class="ml-3">Dashboard</span>
        </a>
      </li>

      <!-- Ledger Link -->
      <li>
        <a href="/pos-system/pages/customer_ledger.php" class="flex items-center p-3 rounded-lg hover:bg-gray-700 transition-colors duration-200">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5s3.332.477 4.5 1.253" />
          </svg>
          <span class="ml-3">Ledger</span>
        </a>
      </li>

      <!-- Mobiles Dropdown -->
      <li>
        <button id="mobiles-dropdown" class="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-700 transition-colors duration-200">
          <div class="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
            </svg>
            <span class="ml-3">Mobiles </span>
          </div>
          <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 transition-transform duration-200" fill="none" viewBox="0 0 24 24" stroke="currentColor" id="mobiles-arrow">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        <ul id="mobiles-submenu" class="ml-8 mt-1 space-y-1 hidden">
          <li>
            <a href="/pos-system/pages/purchase.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700 transition-colors duration-200">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
              <span class="ml-2 text-sm">Mobile Purchase</span>
            </a>
          </li>
          <li>
            <a href="/pos-system/pages/sales.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700 transition-colors duration-200">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span class="ml-2 text-sm">Mobile Sales</span>
            </a>
          </li>
          <li>
            <a href="/pos-system/pages/manage_sales.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700 transition-colors duration-200">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <span class="ml-2 text-sm">Manage Mobile Sales</span>
            </a>
          </li>
          <li>
            <a href="/pos-system/pages/sales_returns.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700 transition-colors duration-200">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              <span class="ml-2 text-sm">Mobile Sales Return</span>
            </a>
          </li>
        </ul>
      </li>

      <!-- Accessories Dropdown -->
      <li>
        <button id="accessories-dropdown" class="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-700 transition-colors duration-200">
          <div class="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
            <span class="ml-3">Accessories </span>
          </div>
          <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 transition-transform duration-200" fill="none" viewBox="0 0 24 24" stroke="currentColor" id="accessories-arrow">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        <ul id="accessories-submenu" class="ml-8 mt-1 space-y-1 hidden">
          <li>
            <a href="/pos-system/acc-pages/purchase.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700 transition-colors duration-200">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
              <span class="ml-2 text-sm">Accessories Purchase</span>
            </a>
          </li>
          <li>
            <a href="/pos-system/acc-pages/sales.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700 transition-colors duration-200">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span class="ml-2 text-sm">Accessories Sales</span>
            </a>
          </li>
          <li>
            <a href="/pos-system/acc-pages/acc-manage-sales.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700 transition-colors duration-200">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <span class="ml-2 text-sm">Manage Accessories Sales</span>
            </a>
          </li>
          <li>
            <a href="/pos-system/acc-pages/acc-returns.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700 transition-colors duration-200">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              <span class="ml-2 text-sm">Accessories Sales Return</span>
            </a>
          </li>
        </ul>
      </li>
    </ul>
  </nav>
</div>

<script>
  // Toggle dropdown menus
  const mobilesDropdown = document.getElementById('mobiles-dropdown');
  const accessoriesDropdown = document.getElementById('accessories-dropdown');
  const mobilesSubmenu = document.getElementById('mobiles-submenu');
  const accessoriesSubmenu = document.getElementById('accessories-submenu');
  const mobilesArrow = document.getElementById('mobiles-arrow');
  const accessoriesArrow = document.getElementById('accessories-arrow');

  mobilesDropdown.addEventListener('click', () => {
    mobilesSubmenu.classList.toggle('hidden');
    mobilesArrow.classList.toggle('rotate-180');
  });

  accessoriesDropdown.addEventListener('click', () => {
    accessoriesSubmenu.classList.toggle('hidden');
    accessoriesArrow.classList.toggle('rotate-180');
  });
</script>