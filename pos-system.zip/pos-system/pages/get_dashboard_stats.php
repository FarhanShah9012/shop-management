<?php
include '../includes/db.php';
header('Content-Type: application/json');

function get_date_condition($period, $date_column) {
    switch ($period) {
        case '7d':
            return " AND $date_column >= CURDATE() - INTERVAL 7 DAY";
        case '30d':
            return " AND $date_column >= CURDATE() - INTERVAL 30 DAY";
        case 'this_month':
            return " AND YEAR($date_column) = YEAR(CURDATE()) AND MONTH($date_column) = MONTH(CURDATE())";
        default: // 'all'
            return "";
    }
}

// Periods from GET request
$sales_period = $_GET['sales_period'] ?? '30d';
$purchases_period = $_GET['purchases_period'] ?? '30d';
$profit_period = $_GET['profit_period'] ?? '30d';

// Build conditions
$sales_cond = get_date_condition($sales_period, 'invoice_date');
$purchases_cond = get_date_condition($purchases_period, 'purchase_date');
$profit_sales_cond = get_date_condition($profit_period, 'i.invoice_date');
$profit_returns_cond = get_date_condition($profit_period, 'sr.return_date');


// --- Calculations ---

// Total Sales (Net Sales) Calculation
// 1. Get gross sales from all invoices created in the period.
$gross_sales_sql = "SELECT SUM(sub_total) as total FROM invoices WHERE 1=1 $sales_cond";
$gross_sales = $conn->query($gross_sales_sql)->fetch_assoc()['total'] ?? 0;

// 2. Get the total original value of items returned within the same period.
$return_date_cond_for_sales = get_date_condition($sales_period, 'sr.return_date');
$returns_sql = "SELECT SUM(ii.total) as total
                FROM sales_returns sr
                JOIN invoice_items ii ON sr.invoice_item_id = ii.id
                WHERE 1=1 $return_date_cond_for_sales";
$total_returns_value = $conn->query($returns_sql)->fetch_assoc()['total'] ?? 0;

// 3. Final total sales is gross sales minus the value of returns.
$total_sales = $gross_sales - $total_returns_value;


// Total Purchases
$purchases_sql = "SELECT SUM(purchase_price * quantity) as total FROM purchases WHERE 1=1 $purchases_cond";
$total_purchases = $conn->query($purchases_sql)->fetch_assoc()['total'] ?? 0;

// --- Net Profit Calculation ---
// 1. Profit from items that are still 'Sold' (not returned) within the period
$profit_sql = "SELECT SUM((ii.sale_price_per_unit - ii.purchase_price_per_unit) * ii.quantity) as total 
               FROM invoice_items ii
               JOIN invoices i ON ii.invoice_id = i.id
               WHERE ii.status = 'Sold' $profit_sales_cond";
$profit_from_sales = $conn->query($profit_sql)->fetch_assoc()['total'] ?? 0;

// 2. Profit from tax on returns within the period
$tax_sql = "SELECT SUM(sr.return_tax) as total
            FROM sales_returns sr
            WHERE 1=1 $profit_returns_cond";
$profit_from_tax = $conn->query($tax_sql)->fetch_assoc()['total'] ?? 0;

$net_profit = $profit_from_sales + $profit_from_tax;


// Stock Value (at sale price, for items currently in stock)
$stock_value_sql = "SELECT SUM(sale_price * quantity) as total FROM purchases WHERE quantity > 0";
$stock_value = $conn->query($stock_value_sql)->fetch_assoc()['total'] ?? 0;

echo json_encode([
    'total_sales' => $total_sales,
    'total_purchases' => $total_purchases,
    'net_profit' => $net_profit,
    'stock_value' => $stock_value
]);

$conn->close();
?>