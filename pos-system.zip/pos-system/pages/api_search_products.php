<?php
include '../includes/db.php';
header('Content-Type: application/json');

$term = $_GET['term'] ?? '';

// Find products that have a quantity greater than 0
$sql = "SELECT 
            p.id, 
            p.product_name, 
            p.specifications, 
            p.sale_price,
            p.quantity 
        FROM purchases p
        WHERE p.quantity > 0 AND p.product_name LIKE ?
        LIMIT 10";

$like_term = "%$term%";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $like_term);
$stmt->execute();
$result = $stmt->get_result();
$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = [
        'id' => $row['id'], // This is the purchase_id
        'label' => $row['product_name'] . ' (' . $row['specifications'] . ') - Stock: ' . $row['quantity'],
        'value' => $row['product_name'],
        'specifications' => $row['specifications'],
        'price' => $row['sale_price']
    ];
}
echo json_encode($products);
$stmt->close();
$conn->close();
?>