<?php
// File: /pos-system/pages/api_get_customer_ledger.php
include '../includes/db.php';
header('Content-Type: application/json');

$customer_id = (int)($_GET['customer_id'] ?? 0);
$from_date = $_GET['from_date'] ?? null;
$to_date = $_GET['to_date'] ?? null;
$transaction_type = $_GET['type'] ?? 'All';

if ($customer_id <= 0) {
    echo json_encode(['success' => false, 'error' => 'Customer ID is required.']);
    exit;
}

// Get customer info
$stmt_customer = $conn->prepare("SELECT * FROM customers WHERE id = ?");
$stmt_customer->bind_param("i", $customer_id);
$stmt_customer->execute();
$customer_info = $stmt_customer->get_result()->fetch_assoc();
$stmt_customer->close();

// --- CALCULATIONS ---

// 1. Opening Balance (balance before from_date)
$opening_balance = 0;
if ($from_date) {
    $stmt_opening = $conn->prepare("SELECT SUM(debit - credit) as balance FROM customer_ledger WHERE customer_id = ? AND transaction_date < ?");
    $stmt_opening->bind_param("is", $customer_id, $from_date);
    $stmt_opening->execute();
    $opening_balance = (float)($stmt_opening->get_result()->fetch_assoc()['balance'] ?? 0);
    $stmt_opening->close();
}

// 2. Ledger Transactions (with running balance)
$params = [$customer_id];
$types = 'i';
$where_clauses = ["customer_id = ?"];

if ($from_date) {
    $where_clauses[] = "transaction_date >= ?";
    $params[] = $from_date;
    $types .= 's';
}
if ($to_date) {
    $where_clauses[] = "transaction_date <= ?";
    $params[] = $to_date;
    $types .= 's';
}
if ($transaction_type !== 'All') {
    $where_clauses[] = "ref_type LIKE ?";
    $params[] = "%$transaction_type%";
    $types .= 's';
}
$where_sql = "WHERE " . implode(' AND ', $where_clauses);

$sql = "SELECT *,
            SUM(debit - credit) OVER (PARTITION BY customer_id ORDER BY transaction_date, id) as running_balance_total
        FROM customer_ledger
        WHERE customer_id = ? ORDER BY transaction_date, id";

$full_ledger_stmt = $conn->prepare($sql);
$full_ledger_stmt->bind_param("i", $customer_id);
$full_ledger_stmt->execute();
$full_ledger_result = $full_ledger_stmt->get_result();

$transactions = [];
$running_balance = $opening_balance;
$total_debit = 0;
$total_credit = 0;

$stmt_filtered = $conn->prepare("SELECT * FROM customer_ledger $where_sql ORDER BY transaction_date, id");
$stmt_filtered->bind_param($types, ...$params);
$stmt_filtered->execute();
$filtered_result = $stmt_filtered->get_result();
while($row = $filtered_result->fetch_assoc()) {
    $running_balance += $row['debit'] - $row['credit'];
    $row['running_balance'] = $running_balance;
    $transactions[] = $row;
    $total_debit += $row['debit'];
    $total_credit += $row['credit'];
}
$stmt_filtered->close();

// 3. Final summary stats
$stmt_summary = $conn->prepare("SELECT SUM(debit - credit) as outstanding, SUM(CASE WHEN ref_type = 'INVOICE' THEN debit ELSE 0 END) as total_sales FROM customer_ledger WHERE customer_id = ?");
$stmt_summary->bind_param("i", $customer_id);
$stmt_summary->execute();
$summary_data = $stmt_summary->get_result()->fetch_assoc();
$stmt_summary->close();

$response = [
    'success' => true,
    'summary' => [
        'customer_info' => $customer_info,
        'opening_balance' => $opening_balance,
        'outstanding_balance' => (float)($summary_data['outstanding'] ?? 0),
        'total_sales' => (float)($summary_data['total_sales'] ?? 0),
    ],
    'transactions' => $transactions,
    'totals' => [
        'total_debit' => $total_debit,
        'total_credit' => $total_credit,
        'closing_balance' => $running_balance
    ]
];

echo json_encode($response);
$conn->close();
?>