<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Inter', sans-serif; background-color: #F9FAFB; }
        .table-row:hover { background-color: #f3f4f6; }
        .pagination-btn.active { background-color: #3b82f6; color: white; border-color: #3b82f6; }
        .modal { transition: opacity 0.3s ease; }
    </style>
</head>
<body class="bg-secondary text-primary">
    <?php include '../includes/sidebar.php'; ?>
    <div class="ml-64 transition-all duration-300 ease-in-out">
        <?php include '../includes/header.php'; ?>
        <div class="container mx-auto px-4 py-8">
            <div class="flex justify-between items-center mb-8">
                <div>
                    <h1 class="text-3xl font-bold text-primary">Purchase Management</h1>
                    <p class="text-gray-600 mt-2">Manage all purchase records and transactions</p>
                </div>
                <button id="addPurchaseBtn" type="button" class="bg-blue-600 text-white px-5 py-2.5 rounded-lg font-semibold hover:bg-blue-700 inline-flex items-center">
                    <i class="fas fa-plus mr-2"></i> Add New Purchase
                </button>
            </div>

            <!-- Search and Filters -->
            <div class="bg-white p-4 rounded-lg shadow-sm mb-6">
                <form method="GET" action="purchase.php" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Search</label>
                        <input type="text" name="search" placeholder="Search by Product, IMEI, Supplier, Phone, CNIC..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">From Date</label>
                        <input type="date" name="from_date" value="<?php echo isset($_GET['from_date']) ? $_GET['from_date'] : ''; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">To Date</label>
                        <input type="date" name="to_date" value="<?php echo isset($_GET['to_date']) ? $_GET['to_date'] : ''; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div class="md:col-start-4">
                        <button type="submit" class="w-full bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">Filter</button>
                    </div>
                </form>
            </div>

            <!-- Purchase Table -->
            <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                <?php
                include '../includes/db.php';
                $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
                $per_page = isset($_GET['per_page']) && in_array($_GET['per_page'], [10, 25, 50, 100]) ? (int)$_GET['per_page'] : 10;
                $offset = ($page - 1) * $per_page;
                
                $search = isset($_GET['search']) ? trim($_GET['search']) : '';
                $from_date = isset($_GET['from_date']) && !empty($_GET['from_date']) ? $_GET['from_date'] : '';
                $to_date = isset($_GET['to_date']) && !empty($_GET['to_date']) ? $_GET['to_date'] : '';

                $where = [];
                $params = [];
                $types = '';

                if ($search) {
                    $where[] = "(p.product_name LIKE ? OR p.supplier_name LIKE ? OR p.phone LIKE ? OR p.cnic LIKE ? OR i.imei1 LIKE ? OR i.imei2 LIKE ?)";
                    $like_search = "%$search%";
                    array_push($params, $like_search, $like_search, $like_search, $like_search, $like_search, $like_search);
                    $types .= 'ssssss';
                }
                if ($from_date) {
                    $where[] = "p.purchase_date >= ?";
                    $params[] = $from_date;
                    $types .= 's';
                }
                if ($to_date) {
                    $where[] = "p.purchase_date <= ?";
                    $params[] = $to_date;
                    $types .= 's';
                }
                
                $where_clause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);
                $count_sql = "SELECT COUNT(DISTINCT p.id) as total FROM purchases p LEFT JOIN imei_table i ON p.id = i.purchase_id $where_clause";
                $stmt = $conn->prepare($count_sql);
                if ($types) $stmt->bind_param($types, ...$params);
                $stmt->execute();
                $total = $stmt->get_result()->fetch_assoc()['total'];
                $stmt->close();
                
                $pages = ceil($total / $per_page);
                $start = $offset + 1;
                $end = min($offset + $per_page, $total);
                ?>
                <div class="p-4 flex justify-between items-center border-b">
                     <p class="text-sm text-gray-600">Showing <?php echo $start; ?> to <?php echo $end; ?> of <?php echo $total; ?> entries</p>
                     <form method="GET" action="purchase.php">
                        <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
                        <input type="hidden" name="from_date" value="<?php echo htmlspecialchars($from_date); ?>">
                        <input type="hidden" name="to_date" value="<?php echo htmlspecialchars($to_date); ?>">
                        <label class="text-sm">Rows: <select name="per_page" onchange="this.form.submit()" class="border border-gray-300 rounded px-2 py-1">
                            <option value="10" <?php echo $per_page == 10 ? 'selected' : ''; ?>>10</option>
                            <option value="25" <?php echo $per_page == 25 ? 'selected' : ''; ?>>25</option>
                            <option value="50" <?php echo $per_page == 50 ? 'selected' : ''; ?>>50</option>
                            <option value="100" <?php echo $per_page == 100 ? 'selected' : ''; ?>>100</option>
                        </select></label>
                     </form>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <?php foreach(['Product Info', 'Date', 'Qty', 'Price (Purchase)', 'Supplier Info', 'Actions'] as $header): ?>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?= $header ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php
                            $sql = "SELECT DISTINCT p.* FROM purchases p LEFT JOIN imei_table i ON p.id = i.purchase_id $where_clause ORDER BY p.purchase_date DESC, p.id DESC LIMIT ? OFFSET ?";
                            $stmt = $conn->prepare($sql);
                            $query_params = $params;
                            array_push($query_params, $per_page, $offset);
                            $query_types = $types . 'ii';
                            if ($query_types) $stmt->bind_param($query_types, ...$query_params);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo '<tr class="table-row">';
                                    echo '<td class="px-6 py-4 whitespace-nowrap"><div class="font-medium">' . htmlspecialchars($row['product_name']) . '</div><div class="text-sm text-gray-500">' . htmlspecialchars($row['category']) . ' - ' . htmlspecialchars($row['specifications']) . '</div></td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap">' . date('d M Y', strtotime($row['purchase_date'])) . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap">' . $row['quantity'] . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap">Rs.' . number_format($row['purchase_price'], 2) . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap"><div class="font-medium">' . htmlspecialchars($row['supplier_name']) . '</div><div class="text-sm text-gray-500">' . htmlspecialchars($row['phone']) . '</div></td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap text-sm font-medium"><div class="flex space-x-3">
                                        <button class="view-purchase text-blue-600 hover:text-blue-900" data-id="' . $row['id'] . '" title="View"><i class="fas fa-eye"></i></button>
                                        <button class="edit-purchase text-yellow-600 hover:text-yellow-900" data-id="' . $row['id'] . '" title="Edit"><i class="fas fa-edit"></i></button>
                                        <button class="delete-purchase text-red-600 hover:text-red-900" data-id="' . $row['id'] . '" title="Delete"><i class="fas fa-trash"></i></button>
                                    </div></td>';
                                    echo '</tr>';
                                }
                            } else {
                                echo '<tr><td colspan="6" class="text-center py-10 text-gray-500">No purchase records found.</td></tr>';
                            }
                            $stmt->close();
                            ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($pages > 1): ?>
                <div class="border-t border-gray-200 px-4 py-3 flex items-center justify-between">
                    <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-center">
                        <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                            <?php
                            $query_string = "per_page=$per_page&search=".urlencode($search)."&from_date=$from_date&to_date=$to_date";
                            if ($page > 1) echo "<a href='?page=".($page-1)."&$query_string' class='relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50'><i class='fas fa-chevron-left'></i></a>";
                            for ($i = 1; $i <= $pages; $i++) {
                                if ($i == $page) {
                                    echo "<a href='#' aria-current='page' class='z-10 bg-blue-50 border-blue-500 text-blue-600 relative inline-flex items-center px-4 py-2 border text-sm font-medium'>$i</a>";
                                } else {
                                    echo "<a href='?page=$i&$query_string' class='bg-white border-gray-300 text-gray-500 hover:bg-gray-50 relative inline-flex items-center px-4 py-2 border text-sm font-medium'>$i</a>";
                                }
                            }
                            if ($page < $pages) echo "<a href='?page=".($page+1)."&$query_string' class='relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50'><i class='fas fa-chevron-right'></i></a>";
                            ?>
                        </nav>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modals Container -->
    <div id="modal-container"></div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const modalContainer = document.getElementById('modal-container');
        let purchaseData = {};
        // FIX: Use a separate variable to track only the new quantity being added during an edit.
        let newStockQuantity = 0;

        function renderStep1Modal(data = {}) {
            const isEdit = !!data.id;
            const modalHTML = `
            <div id="purchaseModal1" class="modal fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50">
                <div class="bg-white rounded-lg shadow-xl overflow-hidden w-full max-w-4xl">
                    <div class="px-6 py-4 bg-gray-50 border-b">
                        <h3 class="text-lg font-medium text-gray-900">${isEdit ? 'Edit' : 'Add New'} Purchase - Step 1/2</h3>
                    </div>
                    <form id="purchaseFormStep1" class="p-6">
                        <input type="hidden" name="id" value="${data.id || ''}">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div class="md:col-span-3 font-semibold text-gray-600 border-b pb-2 mb-2">Product Information</div>
                            <input type="text" name="product_name" placeholder="Product Name" class="p-2 border rounded" value="${data.product_name || ''}" required>
                            <select name="category" class="p-2 border rounded" required>
                                <option value="">Select Category</option>
                                <option value="Mobile" ${data.category === 'Mobile' ? 'selected' : ''}>Mobile</option>
                                <option value="Accessory" ${data.category === 'Accessory' ? 'selected' : ''}>Accessory</option>
                            </select>
                            <input type="text" name="specifications" placeholder="Specifications (e.g., Color, RAM/ROM)" class="p-2 border rounded" value="${data.specifications || ''}" required>
                            
                            <!-- FIX: The quantity field's meaning changes for an edit. -->
                            <input type="number" name="quantity" placeholder="${isEdit ? 'Add More Quantity' : 'Quantity'}" min="${isEdit ? '0' : '1'}" class="p-2 border rounded" value="${isEdit ? '' : (data.quantity || '1')}" required>
                            
                            <input type="number" name="purchase_price" placeholder="Purchase Price (per unit)" step="0.01" class="p-2 border rounded" value="${data.purchase_price || ''}" required>
                            <input type="number" name="sale_price" placeholder="Sale Price (per unit)" step="0.01" class="p-2 border rounded" value="${data.sale_price || ''}" required>
                            <input type="date" name="purchase_date" class="p-2 border rounded" value="${data.purchase_date || new Date().toISOString().split('T')[0]}" required>

                            <div class="md:col-span-3 font-semibold text-gray-600 border-b pb-2 mb-2 mt-4">Supplier Information</div>
                            <input type="text" name="supplier_name" placeholder="Supplier Name" class="p-2 border rounded" value="${data.supplier_name || ''}" required>
                            <input type="text" name="phone" placeholder="Phone" class="p-2 border rounded" value="${data.phone || ''}" required>
                            <input type="text" name="address" placeholder="Address" class="md:col-span-2 p-2 border rounded" value="${data.address || ''}" required>
                            <input type="text" name="cnic" placeholder="CNIC" class="p-2 border rounded" value="${data.cnic || ''}" required>
                        </div>
                        <div class="mt-6 flex justify-end space-x-3">
                            <button type="button" class="close-modal px-4 py-2 bg-gray-300 text-gray-800 rounded-md">Cancel</button>
                            <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded-md">Next <i class="fas fa-arrow-right ml-2"></i></button>
                        </div>
                    </form>
                </div>
            </div>`;
            modalContainer.innerHTML = modalHTML;
            document.getElementById('purchaseFormStep1').addEventListener('submit', handleStep1Submit);
        }

        function renderStep2Modal(isEdit = false) {
            let imeiFieldsHTML = '';
            const quantityForNewPurchase = parseInt(purchaseData.quantity) || 0;

            // FIX: Display existing IMEIs as read-only text, not editable inputs.
            if (isEdit && purchaseData.imeis && purchaseData.imeis.length > 0) {
                let existingImeisHTML = purchaseData.imeis.map((imei, index) => `
                    <div class="p-3 border rounded-md bg-gray-100">
                        <h4 class="font-medium text-gray-800">Existing Unit ${index + 1}</h4>
                        <div class="grid grid-cols-2 gap-2 mt-2 text-sm text-gray-700 font-mono">
                            <span>${imei.imei1 || 'N/A'}</span>
                            <span>${imei.imei2 || 'N/A'}</span>
                        </div>
                    </div>`).join('');
                imeiFieldsHTML += `<div class="space-y-3">${existingImeisHTML}</div>`;
            }

            // FIX: Generate input fields ONLY for the new quantity.
            const quantityToAdd = isEdit ? newStockQuantity : quantityForNewPurchase;
            if (quantityToAdd > 0) {
                let newImeisHTML = '';
                for (let i = 1; i <= quantityToAdd; i++) {
                    newImeisHTML += `
                        <div class="p-3 border rounded-md border-blue-300 bg-blue-50">
                            <h4 class="font-medium text-blue-800">New Unit ${i}</h4>
                            <div class="grid grid-cols-2 gap-2 mt-2">
                                <input type="text" name="new_imei1_${i}" placeholder="New IMEI 1" class="p-2 border rounded" required>
                                <input type="text" name="new_imei2_${i}" placeholder="New IMEI 2" class="p-2 border rounded" required>
                            </div>
                        </div>`;
                }
                imeiFieldsHTML += `<div class="mt-4 pt-4 border-t"><h3 class="font-semibold text-lg mb-3">Add New IMEIs</h3><div class="space-y-3">${newImeisHTML}</div></div>`;
            }
            
            if (isEdit && quantityToAdd === 0) {
                imeiFieldsHTML += '<p class="mt-4 text-center text-gray-600">No new quantity added. Click Save to update other details or Back to add more units.</p>';
            }

            const modalHTML = `
            <div id="purchaseModal2" class="modal fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50">
                <div class="bg-white rounded-lg shadow-xl w-full max-w-2xl">
                    <div class="px-6 py-4 bg-gray-50 border-b">
                        <h3 class="text-lg font-medium text-gray-900">${isEdit ? 'Edit' : 'Add New'} Purchase - Step 2/2: IMEIs</h3>
                    </div>
                    <form id="purchaseFormStep2" class="p-6">
                        <div id="imeiInputs" class="space-y-3 max-h-96 overflow-y-auto pr-2">${imeiFieldsHTML}</div>
                        <div class="mt-6 flex justify-end space-x-3">
                            <button type="button" class="back-to-step1 px-4 py-2 bg-gray-300 text-gray-800 rounded-md"><i class="fas fa-arrow-left mr-2"></i> Back</button>
                            <button type="submit" class="px-4 py-2 bg-green-500 text-white rounded-md"><i class="fas fa-save mr-2"></i> Save Purchase</button>
                        </div>
                    </form>
                </div>
            </div>`;
            modalContainer.innerHTML = modalHTML;
            document.getElementById('purchaseFormStep2').addEventListener('submit', handleStep2Submit);
            document.querySelector('.back-to-step1').addEventListener('click', () => renderStep1Modal(purchaseData));
        }
        
        function handleStep1Submit(e) {
            e.preventDefault();
            const formData = new FormData(e.target);
            const isEdit = !!purchaseData.id;

            // Update all fields in purchaseData
            for (let [key, value] of formData.entries()) {
                purchaseData[key] = value;
            }

            // FIX: If editing, the 'quantity' from the form is the *new* stock. Store it separately.
            if(isEdit) {
                newStockQuantity = parseInt(formData.get('quantity')) || 0;
            }

            renderStep2Modal(isEdit);
        }

        function handleStep2Submit(e) {
            e.preventDefault();
            const formData = new FormData(e.target);
            const isEdit = !!purchaseData.id;
            const newImeis = [];

            // FIX: The loop only runs for the quantity of NEW units being added.
            const quantityToValidate = isEdit ? newStockQuantity : (parseInt(purchaseData.quantity) || 0);
            for (let i = 1; i <= quantityToValidate; i++) {
                const imei1 = formData.get(`new_imei1_${i}`);
                const imei2 = formData.get(`new_imei2_${i}`);
                if (!imei1 || !imei2) {
                    alert(`Please enter both IMEIs for new unit ${i}.`);
                    return;
                }
                newImeis.push({ imei1, imei2 });
            }
            
            // Create the final payload. For edits, it will contain 'new_imeis'. For new, it will be 'imeis'.
            const finalData = { ...purchaseData };
            if (isEdit) {
                finalData.new_imeis = newImeis;
                finalData.new_quantity = newStockQuantity; // Send the new quantity to the backend
            } else {
                finalData.imeis = newImeis; // For a new purchase, this is the full list
            }

            fetch('add_purchase.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(finalData),
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    alert(result.message);
                    location.reload();
                } else {
                    alert('Error: ' + result.error);
                }
            });
        }
        
        function renderViewModal(data) {
             let imeisList = data.imeis.map(imei => `<li class="text-sm font-mono">${imei.imei1}, ${imei.imei2}</li>`).join('');
             const modalHTML = `
             <div id="viewPurchaseModal" class="modal fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50">
                <div class="bg-white rounded-lg shadow-xl w-full max-w-2xl">
                    <div class="px-6 py-4 bg-gray-50 border-b flex justify-between items-center"><h3 class="text-lg font-medium text-gray-900">Purchase Details</h3><button class="close-modal text-gray-500 hover:text-gray-800 text-2xl">×</button></div>
                    <div class="p-6 grid grid-cols-2 gap-x-8 gap-y-4">
                        <div><strong>Product:</strong> ${data.product_name}</div><div><strong>Category:</strong> ${data.category}</div>
                        <div><strong>Specs:</strong> ${data.specifications}</div><div><strong>Date:</strong> ${data.purchase_date}</div>
                        <div><strong>Total Qty:</strong> ${data.quantity}</div><div><strong>Purchase Price:</strong> Rs. ${parseFloat(data.purchase_price).toFixed(2)}</div>
                        <div><strong>Sale Price:</strong> Rs. ${parseFloat(data.sale_price).toFixed(2)}</div><div><strong>Supplier:</strong> ${data.supplier_name}</div>
                        <div><strong>Phone:</strong> ${data.phone}</div><div><strong>CNIC:</strong> ${data.cnic}</div>
                        <div class="col-span-2"><strong>Address:</strong> ${data.address}</div>
                        <div class="col-span-2"><strong class="block mb-2">IMEIs:</strong><ul class="list-disc list-inside max-h-40 overflow-y-auto bg-gray-50 p-2 rounded">${imeisList}</ul></div>
                    </div>
                    <div class="p-4 bg-gray-50 border-t flex justify-end"><button class="close-modal px-4 py-2 bg-gray-500 text-white rounded-md">Close</button></div>
                </div>
            </div>`;
            modalContainer.innerHTML = modalHTML;
        }

        // Event Delegation for all actions
        document.body.addEventListener('click', function(e) {
            const target = e.target;
            if (target.matches('.close-modal') || target.parentElement.matches('.close-modal') || target.id.includes('Modal')) {
                if(!target.closest('.bg-white')) modalContainer.innerHTML = '';
            }
            if (target.id === 'addPurchaseBtn') {
                purchaseData = {};
                newStockQuantity = 0;
                renderStep1Modal();
            }
            if (target.closest('.view-purchase')) {
                fetch(`get_purchase.php?id=${target.closest('.view-purchase').dataset.id}`).then(res => res.json()).then(data => renderViewModal(data));
            }
            if (target.closest('.edit-purchase')) {
                fetch(`get_purchase.php?id=${target.closest('.edit-purchase').dataset.id}`).then(res => res.json()).then(data => {
                    purchaseData = data;
                    newStockQuantity = 0; // Reset new stock counter
                    renderStep1Modal(data);
                });
            }
            if (target.closest('.delete-purchase')) {
                const id = target.closest('.delete-purchase').dataset.id;
                if (confirm('Are you sure you want to delete this purchase and all its associated stock/IMEIs? This action cannot be undone.')) {
                    fetch(`delete_purchase.php?id=${id}`, { method: 'DELETE' }).then(res => res.json()).then(data => {
                        if (data.success) { alert('Purchase deleted successfully'); location.reload(); } else { alert('Error: ' + data.error); }
                    });
                }
            }
        });
    });
    </script>
</body>
</html>