<?php
include '../includes/db.php';
header('Content-Type: application/json');

if (!isset($_GET['id'])) {
    echo json_encode(['error' => 'No ID provided']);
    exit;
}

$id = (int)$_GET['id'];
$response = [];

$stmt = $conn->prepare("SELECT * FROM purchases WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($purchase = $result->fetch_assoc()) {
    $response = $purchase;
    $response['imeis'] = [];

    $imei_stmt = $conn->prepare("SELECT imei1, imei2 FROM imei_table WHERE purchase_id = ?");
    $imei_stmt->bind_param("i", $id);
    $imei_stmt->execute();
    $imei_result = $imei_stmt->get_result();

    while ($imei_row = $imei_result->fetch_assoc()) {
        $response['imeis'][] = $imei_row;
    }
    $imei_stmt->close();
}

$stmt->close();
$conn->close();

echo json_encode($response);
?>