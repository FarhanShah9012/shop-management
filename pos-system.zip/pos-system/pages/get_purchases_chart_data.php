<?php
include '../includes/db.php';
header('Content-Type: application/json');

// Fetch purchases from the last 12 months
$sql = "SELECT 
            DATE_FORMAT(purchase_date, '%Y-%m') as month, 
            SUM(purchase_price * quantity) as total 
        FROM purchases 
        WHERE purchase_date >= CURDATE() - INTERVAL 12 MONTH
        GROUP BY month 
        ORDER BY month ASC";

$result = $conn->query($sql);

$labels = [];
$values = [];

while ($row = $result->fetch_assoc()) {
    $labels[] = date("M Y", strtotime($row['month'] . "-01"));
    $values[] = $row['total'];
}

echo json_encode(['labels' => $labels, 'values' => $values]);

$conn->close();
?>