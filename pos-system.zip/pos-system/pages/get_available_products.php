<?php
include '../includes/db.php';
header('Content-Type: application/json');

$term = isset($_GET['term']) ? '%' . $conn->real_escape_string($_GET['term']) . '%' : '%';

$stmt = $conn->prepare("SELECT id, product_name, specifications, sale_price FROM purchases WHERE available_qty > 0 AND product_name LIKE ?");
$stmt->bind_param("s", $term);
$stmt->execute();
$result = $stmt->get_result();

$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}

echo json_encode($products);

$stmt->close();
$conn->close();
?>