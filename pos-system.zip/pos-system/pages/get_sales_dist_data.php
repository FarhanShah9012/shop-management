<?php
include '../includes/db.php';
header('Content-Type: application/json');

// Get sales count by category from the new invoice tables
$sql = "SELECT p.category, SUM(ii.quantity) as count 
        FROM invoice_items ii
        JOIN purchases p ON ii.purchase_id = p.id
        GROUP BY p.category";

$result = $conn->query($sql);

$labels = [];
$values = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $labels[] = $row['category'];
        $values[] = $row['count'];
    }
}

// If no sales, provide default empty data for the chart
if (empty($labels)) {
    $labels = ['No Sales Data'];
    $values = [1];
}

echo json_encode(['labels' => $labels, 'values' => $values]);

$conn->close();
?>