<?php
// File: /pos-system/pages/api_add_customer.php
include '../includes/db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
    exit;
}

$name = trim($_POST['name'] ?? '');
$phone = trim($_POST['phone'] ?? '');

if (empty($name) || empty($phone)) {
    echo json_encode(['success' => false, 'error' => 'Customer name and phone are required.']);
    exit;
}

$conn->begin_transaction();

try {
    // Check if phone number already exists
    $stmt_check = $conn->prepare("SELECT id FROM customers WHERE phone = ?");
    $stmt_check->bind_param("s", $phone);
    $stmt_check->execute();
    $result = $stmt_check->get_result();
    if ($result->num_rows > 0) {
        throw new Exception('A customer with this phone number already exists.');
    }
    $stmt_check->close();

    // Insert new customer
    $stmt_insert = $conn->prepare("INSERT INTO customers (name, phone) VALUES (?, ?)");
    $stmt_insert->bind_param("ss", $name, $phone);
    $stmt_insert->execute();
    $new_customer_id = $stmt_insert->insert_id;
    $stmt_insert->close();

    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Customer added successfully.', 'customer' => ['id' => $new_customer_id, 'name' => $name, 'phone' => $phone]]);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$conn->close();
?>