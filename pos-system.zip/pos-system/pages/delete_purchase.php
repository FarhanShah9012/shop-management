<?php
include '../includes/db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE' || !isset($_GET['id'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid request.']);
    exit;
}

$id = (int)$_GET['id'];

$conn->begin_transaction();
try {
    // First delete associated IMEIs
    $stmt_imei = $conn->prepare("DELETE FROM imei_table WHERE purchase_id = ?");
    $stmt_imei->bind_param("i", $id);
    $stmt_imei->execute();
    $stmt_imei->close();

    // Then delete the purchase record
    $stmt_purchase = $conn->prepare("DELETE FROM purchases WHERE id = ?");
    $stmt_purchase->bind_param("i", $id);
    $stmt_purchase->execute();
    
    if ($stmt_purchase->affected_rows > 0) {
        $conn->commit();
        echo json_encode(['success' => true]);
    } else {
        throw new Exception("Purchase record not found or already deleted.");
    }
    $stmt_purchase->close();

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$conn->close();
?>