<?php
include '../includes/db.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'error' => 'Invalid data received.']);
    exit;
}

$is_edit = !empty($data['id']);
$conn->begin_transaction();

try {
    if ($is_edit) {
        // --- EDIT LOGIC ---
        $id = $data['id'];
        $new_quantity = isset($data['new_quantity']) ? (int)$data['new_quantity'] : 0;
        
        // Step 1: Update the main purchase details, only incrementing quantity if new stock was added.
        $sql = "UPDATE purchases SET 
                    product_name=?, category=?, specifications=?, quantity = quantity + ?, 
                    purchase_price=?, sale_price=?, purchase_date=?, 
                    supplier_name=?, phone=?, address=?, cnic=? 
                WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "sssisdsssssi",
            $data['product_name'], $data['category'], $data['specifications'], $new_quantity,
            $data['purchase_price'], $data['sale_price'], $data['purchase_date'],
            $data['supplier_name'], $data['phone'], $data['address'], $data['cnic'],
            $id
        );
        $stmt->execute();
        $stmt->close();
        
        // Step 2: If there are new IMEIs, insert them. Do NOT delete old ones.
        if (!empty($data['new_imeis'])) {
            $imei_sql = "INSERT INTO imei_table (purchase_id, imei1, imei2) VALUES (?, ?, ?)";
            $imei_stmt = $conn->prepare($imei_sql);
            foreach ($data['new_imeis'] as $imei_pair) {
                $imei_stmt->bind_param("iss", $id, $imei_pair['imei1'], $imei_pair['imei2']);
                $imei_stmt->execute();
            }
            $imei_stmt->close();
        }
        
        $message = 'Purchase updated successfully';

    } else {
        // --- ADD NEW LOGIC (Remains the same) ---
        $total_quantity = count($data['imeis']);
        $sql = "INSERT INTO purchases (product_name, category, specifications, quantity, purchase_price, sale_price, purchase_date, supplier_name, phone, address, cnic) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssidssssss", $data['product_name'], $data['category'], $data['specifications'], $total_quantity, $data['purchase_price'], $data['sale_price'], $data['purchase_date'], $data['supplier_name'], $data['phone'], $data['address'], $data['cnic']);
        $stmt->execute();
        
        $purchase_id = $stmt->insert_id;
        $stmt->close();

        // Insert IMEIs for the new purchase
        $imei_sql = "INSERT INTO imei_table (purchase_id, imei1, imei2) VALUES (?, ?, ?)";
        $imei_stmt = $conn->prepare($imei_sql);
        foreach ($data['imeis'] as $imei_pair) {
            $imei_stmt->bind_param("iss", $purchase_id, $imei_pair['imei1'], $imei_pair['imei2']);
            $imei_stmt->execute();
        }
        $imei_stmt->close();
        
        $message = 'Purchase added successfully';
    }

    $conn->commit();
    echo json_encode(['success' => true, 'message' => $message]);

} catch (mysqli_sql_exception $exception) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $exception->getMessage()]);
}

$conn->close();
?>