<?php
// File: /pos-system/pages/api_get_customers.php
include '../includes/db.php';
header('Content-Type: application/json');

$result = $conn->query("SELECT id, name, phone FROM customers ORDER BY name ASC");
$customers = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $customers[] = $row;
    }
}
echo json_encode($customers);
$conn->close();
?>