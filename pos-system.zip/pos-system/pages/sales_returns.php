<?php
include '../includes/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Returns Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Inter', sans-serif; background-color: #F9FAFB; }
        .table-row:hover { background-color: #f3f4f6; }
        .action-btn { transition: all 0.2s ease; }
        .action-btn:hover { transform: scale(1.05); }
        .close-modal { font-size: 2rem; line-height: 1; }
    </style>
</head>
<body class="bg-secondary text-primary">
    <?php include '../includes/sidebar.php'; ?>
    <div class="ml-64 transition-all duration-300 ease-in-out">
        <?php include '../includes/header.php'; ?>
        <div class="container mx-auto px-4 py-8">
            <div class="flex justify-between items-center mb-8">
                <div>
                    <h1 class="text-3xl font-bold text-primary">Sales Returns</h1>
                    <p class="text-gray-600 mt-2">Create a return from a past sale</p>
                </div>
            </div>

            <!-- Search and Filters -->
            <div class="bg-white p-4 rounded-lg shadow-sm mb-6">
                <form method="GET" action="sales_returns.php" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                    <div class="md:col-span-2">
                        <label for="search" class="block text-sm font-medium text-gray-700 mb-1">Search</label>
                        <input type="text" id="search" name="search" placeholder="Search by Invoice No, Customer Name, or Phone Number..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label for="from_date" class="block text-sm font-medium text-gray-700 mb-1">From Date</label>
                        <input type="date" id="from_date" name="from_date" value="<?php echo isset($_GET['from_date']) ? $_GET['from_date'] : ''; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label for="to_date" class="block text-sm font-medium text-gray-700 mb-1">To Date</label>
                        <input type="date" id="to_date" name="to_date" value="<?php echo isset($_GET['to_date']) ? $_GET['to_date'] : ''; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div class="md:col-start-4">
                        <button type="submit" class="w-full bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">Filter</button>
                    </div>
                </form>
            </div>

            <!-- Sales Table -->
            <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                <?php
                $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
                $per_page = 10;
                $offset = ($page - 1) * $per_page;

                $search = isset($_GET['search']) ? trim($_GET['search']) : '';
                $from_date = isset($_GET['from_date']) && !empty($_GET['from_date']) ? $_GET['from_date'] : '';
                $to_date = isset($_GET['to_date']) && !empty($_GET['to_date']) ? $_GET['to_date'] : '';

                $where = [];
                $params = [];
                $types = '';

                if ($search) {
                    $where[] = "(invoice_number LIKE ? OR customer_name LIKE ? OR customer_phone LIKE ?)";
                    $like_search = "%$search%";
                    array_push($params, $like_search, $like_search, $like_search);
                    $types .= 'sss';
                }
                if ($from_date) {
                    $where[] = "invoice_date >= ?";
                    $params[] = $from_date;
                    $types .= 's';
                }
                if ($to_date) {
                    $where[] = "invoice_date <= ?";
                    $params[] = $to_date;
                    $types .= 's';
                }
                $where_clause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);
                
                $count_sql = "SELECT COUNT(*) as total FROM invoices $where_clause";
                $stmt = $conn->prepare($count_sql);
                if ($types) $stmt->bind_param($types, ...$params);
                $stmt->execute();
                $total = $stmt->get_result()->fetch_assoc()['total'];
                $stmt->close();
                
                $pages = ceil($total / $per_page);
                ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <?php foreach(['S.No', 'Invoice No', 'Invoice Date', 'Total Amount', 'Customer Name', 'Phone', 'Actions'] as $header): ?>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?= $header ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody id="sales-table-body" class="bg-white divide-y divide-gray-200">
                             <?php
                            $sql = "SELECT * FROM invoices $where_clause ORDER BY invoice_date DESC, id DESC LIMIT ? OFFSET ?";
                            $stmt = $conn->prepare($sql);
                            $query_params = $params;
                            array_push($query_params, $per_page, $offset);
                            $query_types = $types . 'ii';
                            if ($query_types) $stmt->bind_param($query_types, ...$query_params);
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($result->num_rows > 0) {
                                $s_no = $offset + 1;
                                while ($row = $result->fetch_assoc()) {
                                    echo '<tr class="table-row" data-invoice-id="' . $row['id'] . '">';
                                    echo '<td class="px-6 py-4 whitespace-nowrap">' . $s_no++ . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap font-medium text-gray-900">' . htmlspecialchars($row['invoice_number']) . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap">' . date('d M Y', strtotime($row['invoice_date'])) . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap">Rs. ' . number_format($row['grand_total'], 2) . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($row['customer_name']) . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($row['customer_phone']) . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap text-sm font-medium"><div class="flex space-x-3">
                                        <button class="return-btn action-btn bg-yellow-500 text-white px-3 py-1 rounded-md hover:bg-yellow-600" title="Return"><i class="fas fa-undo mr-1"></i> Return</button>
                                    </div></td>';
                                    echo '</tr>';
                                }
                            } else {
                                echo '<tr><td colspan="7" class="text-center py-10 text-gray-500">No sales records found.</td></tr>';
                            }
                            $stmt->close();
                            ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($pages > 1): ?>
                <div class="border-t border-gray-200 px-4 py-3 flex items-center justify-center">
                    <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                        <?php
                        $query_string = "search=".urlencode($search)."&from_date=$from_date&to_date=$to_date";
                        if ($page > 1) echo "<a href='?page=".($page-1)."&$query_string' class='relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50'><i class='fas fa-chevron-left'></i></a>";
                        for ($i = 1; $i <= $pages; $i++) {
                            if ($i == $page) {
                                echo "<a href='#' aria-current='page' class='z-10 bg-blue-50 border-blue-500 text-blue-600 relative inline-flex items-center px-4 py-2 border text-sm font-medium'>$i</a>";
                            } else {
                                echo "<a href='?page=$i&$query_string' class='bg-white border-gray-300 text-gray-500 hover:bg-gray-50 relative inline-flex items-center px-4 py-2 border text-sm font-medium'>$i</a>";
                            }
                        }
                        if ($page < $pages) echo "<a href='?page=".($page+1)."&$query_string' class='relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50'><i class='fas fa-chevron-right'></i></a>";
                        ?>
                    </nav>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Return Modal -->
        <div id="returnModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div class="relative top-10 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
                <div class="flex justify-between items-center border-b pb-3">
                    <h3 id="modalTitle" class="text-lg leading-6 font-medium text-gray-900">Process Return for Invoice #<span id="modal-invoice-no"></span></h3>
                    <button id="closeModalBtn" class="text-black close-modal">&times;</button>
                </div>
                <form id="returnForm" class="mt-4 space-y-4">
                    <input type="hidden" name="invoice_item_id" id="return-invoice-item-id">
                    <h4 class="font-semibold">Select Item to Return:</h4>
                    <div id="returnable-items-list" class="space-y-2 max-h-60 overflow-y-auto border p-3 rounded-md">
                        <!-- Items will be loaded here via AJAX -->
                    </div>
                    <div class="text-center text-gray-500 hidden" id="no-returnable-items">No more items can be returned from this invoice.</div>
                    
                    <div class="grid grid-cols-2 gap-4 pt-4 border-t">
                        <div>
                            <label for="return-tax" class="block text-sm font-medium text-gray-700">Return Tax</label>
                            <input type="number" name="return_tax" id="return-tax" value="0" step="0.01" class="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" disabled>
                        </div>
                        <div>
                            <label for="returnable-amount" class="block text-sm font-medium text-gray-700">Returnable Amount</label>
                            <input type="number" name="return_amount" id="returnable-amount" readonly class="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100">
                        </div>
                    </div>
                    <div class="items-center px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                        <button type="submit" id="saveReturnBtn" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 sm:ml-3 sm:w-auto sm:text-sm" disabled>Save Return</button>
                        <button type="button" class="close-modal mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 sm:mt-0 sm:w-auto sm:text-sm">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    $(document).ready(function() {
        const modal = $('#returnModal');
        let selectedItemPrice = 0;

        function openModal() { modal.removeClass('hidden'); }
        function closeModal() { modal.addClass('hidden'); }

        $('.close-modal, #closeModalBtn').on('click', closeModal);

        $('#sales-table-body').on('click', '.return-btn', function() {
            const row = $(this).closest('tr');
            const invoiceId = row.data('invoice-id');
            const invoiceNo = row.find('td:nth-child(2)').text();
            
            $('#modal-invoice-no').text(invoiceNo);
            $('#returnable-items-list').html('<p class="text-center">Loading items...</p>');
            $('#returnForm')[0].reset();
            $('#saveReturnBtn, #return-tax').prop('disabled', true);
            selectedItemPrice = 0;

            $.getJSON(`api_get_returnable_items.php?invoice_id=${invoiceId}`, function(response) {
                if (response.success) {
                    const itemsList = $('#returnable-items-list');
                    itemsList.empty();
                    if (response.items.length > 0) {
                        $('#no-returnable-items').addClass('hidden');
                        response.items.forEach(item => {
                            const imeis = item.imeis.map(i => `${i.imei1} / ${i.imei2}`).join('<br>');
                            const itemHTML = `
                                <label class="flex items-start p-3 border rounded-md hover:bg-gray-50 cursor-pointer">
                                    <input type="radio" name="selected_item" class="mt-1 h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" 
                                           value="${item.id}" data-price="${item.sale_price_per_unit}">
                                    <div class="ml-3 text-sm">
                                        <p class="font-medium">${item.product_name} (${item.specification})</p>
                                        <p class="text-gray-600">Sale Price: Rs. ${parseFloat(item.sale_price_per_unit).toFixed(2)}</p>
                                        <p class="text-xs text-gray-500 mt-1">${imeis}</p>
                                    </div>
                                </label>`;
                            itemsList.append(itemHTML);
                        });
                    } else {
                        $('#returnable-items-list').empty();
                        $('#no-returnable-items').removeClass('hidden');
                    }
                } else {
                    alert('Error: ' + response.error);
                }
            });

            openModal();
        });

        function calculateReturnAmount() {
            const tax = parseFloat($('#return-tax').val()) || 0;
            if (selectedItemPrice > 0) {
                const returnableAmount = selectedItemPrice - tax;
                $('#returnable-amount').val(returnableAmount.toFixed(2));
            } else {
                $('#returnable-amount').val('0.00');
            }
        }

        $('#returnForm').on('change', 'input[name="selected_item"]', function() {
            if ($(this).is(':checked')) {
                selectedItemPrice = parseFloat($(this).data('price'));
                $('#return-invoice-item-id').val($(this).val());
                $('#saveReturnBtn, #return-tax').prop('disabled', false);
                calculateReturnAmount();
            }
        });

        $('#return-tax').on('input', calculateReturnAmount);

        $('#returnForm').on('submit', function(e) {
            e.preventDefault();
            
            if (!$('#return-invoice-item-id').val()) {
                alert('Please select an item to return.');
                return;
            }

            const formData = $(this).serialize();
            $('#saveReturnBtn').prop('disabled', true).text('Processing...');

            $.ajax({
                url: 'api_process_return.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        alert(response.message);
                        closeModal();
                        location.reload(); 
                    } else {
                        alert('Error: ' + response.error);
                    }
                },
                error: function() {
                    alert('An error occurred while processing the return.');
                },
                complete: function() {
                    $('#saveReturnBtn').prop('disabled', false).text('Save Return');
                }
            });
        });
    });
    </script>
</body>
</html>