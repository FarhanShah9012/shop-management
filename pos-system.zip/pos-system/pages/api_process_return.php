<?php
// File: /pos-system/pages/api_process_return.php
include '../includes/db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
    exit;
}

$invoice_item_id = isset($_POST['invoice_item_id']) ? (int)$_POST['invoice_item_id'] : 0;
$return_tax = isset($_POST['return_tax']) ? (float)$_POST['return_tax'] : 0;
$return_amount = isset($_POST['return_amount']) ? (float)$_POST['return_amount'] : 0;
$return_date = date('Y-m-d'); // Use current date for the return

if (!$invoice_item_id || $return_amount < 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid data provided for return. Please select an item.']);
    exit;
}

$conn->begin_transaction();

try {
    // 1. Get the invoice item details and ensure it's not already returned
    $stmt = $conn->prepare("SELECT ii.*, i.customer_id FROM invoice_items ii JOIN invoices i ON ii.invoice_id = i.id WHERE ii.id = ? AND ii.status = 'Sold' FOR UPDATE");
    $stmt->bind_param("i", $invoice_item_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $item_details = $result->fetch_assoc();
    $stmt->close();

    if (!$item_details) {
        throw new Exception("Item not found, or it has already been returned.");
    }
    
    $original_purchase_id = $item_details['purchase_id'];
    $quantity_to_return = $item_details['quantity'];
    $customer_id = $item_details['customer_id'];
    
    if ($quantity_to_return <= 0) {
        throw new Exception("Cannot return an item with zero quantity.");
    }
    
    $new_purchase_price_per_unit = $return_amount / $quantity_to_return;

    // 2. Get details from the original purchase to create a new purchase record for the return
    $stmt_orig_purchase = $conn->prepare("SELECT * FROM purchases WHERE id = ?");
    $stmt_orig_purchase->bind_param("i", $original_purchase_id);
    $stmt_orig_purchase->execute();
    $original_purchase_details = $stmt_orig_purchase->get_result()->fetch_assoc();
    $stmt_orig_purchase->close();

    if (!$original_purchase_details) {
        throw new Exception("Original purchase record not found. Cannot process return.");
    }

    // 3. Insert into the sales_returns table
    $stmt_return = $conn->prepare("INSERT INTO sales_returns (invoice_item_id, customer_id, return_date, return_tax, return_amount) VALUES (?, ?, ?, ?, ?)");
    $stmt_return->bind_param("iisdd", $invoice_item_id, $customer_id, $return_date, $return_tax, $return_amount);
    $stmt_return->execute();
    $sales_return_id = $stmt_return->insert_id;
    $stmt_return->close();

    // 4. Update the item's status in invoice_items to 'Returned'
    $stmt_update_item = $conn->prepare("UPDATE invoice_items SET status = 'Returned' WHERE id = ?");
    $stmt_update_item->bind_param("i", $invoice_item_id);
    $stmt_update_item->execute();
    $stmt_update_item->close();

    // 5. Create a NEW purchase record for the returned item
    $stmt_new_purchase = $conn->prepare(
        "INSERT INTO purchases (product_name, category, specifications, quantity, purchase_price, sale_price, purchase_date, supplier_name, phone, address, cnic) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt_new_purchase->bind_param(
        "sssidssssss",
        $original_purchase_details['product_name'],
        $original_purchase_details['category'],
        $original_purchase_details['specifications'],
        $quantity_to_return,
        $new_purchase_price_per_unit,
        $original_purchase_details['sale_price'],
        $return_date,
        $original_purchase_details['supplier_name'],
        $original_purchase_details['phone'],
        $original_purchase_details['address'],
        $original_purchase_details['cnic']
    );
    $stmt_new_purchase->execute();
    $new_purchase_id = $stmt_new_purchase->insert_id;
    $stmt_new_purchase->close();

    // 6. Restore stock: Update IMEI status and re-assign it to the new purchase record
    $stmt_imei = $conn->prepare("UPDATE imei_table SET status = 'In Stock', invoice_item_id = NULL, purchase_id = ? WHERE invoice_item_id = ?");
    $stmt_imei->bind_param("ii", $new_purchase_id, $invoice_item_id);
    $stmt_imei->execute();
    $stmt_imei->close();
    
    // 7. Add a credit entry to the customer's ledger if they exist
    if ($customer_id && $return_amount > 0) {
        $ledger_stmt = $conn->prepare("INSERT INTO customer_ledger (customer_id, transaction_date, description, ref_id, ref_type, debit, credit) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $description = "Return for item: " . $item_details['product_name'];
        $ref_type = 'RETURN';
        $debit = 0.00;
        $ledger_stmt->bind_param("issisdd", $customer_id, $return_date, $description, $sales_return_id, $ref_type, $debit, $return_amount);
        $ledger_stmt->execute();
        $ledger_stmt->close();
    }

    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Item returned successfully. Stock and customer ledger have been updated.']);

} catch (mysqli_sql_exception $exception) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => 'Database transaction failed: ' . $exception->getMessage()]);
}

$conn->close();
?>