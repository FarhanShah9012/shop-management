<?php
// This must be the very first lines of the file.
session_start();

// This is the authentication check. If the user is not logged in, redirect to the login page.
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php"); // The '..' is important as we are in a subdirectory.
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BusinessPOS Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1F2937',
                        secondary: '#F9FAFB',
                        accent: {
                            purple: '#EDE9FE',
                            blue: '#DBEAFE'
                        }
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
            background-color: #F9FAFB;
        }
        .stat-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.08);
        }
        .chart-container {
            min-height: 300px;
        }
        .low-stock-item:hover { background-color: #f3f4f6; }
        .status-indicator { width: 12px; height: 12px; border-radius: 50%; }
        .success { background-color: #10B981; }
        .failed { background-color: #EF4444; }
    </style>
</head>

<body class="bg-secondary text-primary">
    <?php include '../includes/sidebar.php'; ?>

    <div id="main-content" class="ml-64 transition-all duration-300 ease-in-out">
        <?php include '../includes/header.php'; ?>
        <div class="container mx-auto px-4 py-8">
            <div class="mb-8">
                <!-- MODIFICATION: The welcome message now correctly uses the session variable -->
                <h1 class="text-3xl font-bold text-primary">Dashboard</h1>
                <p class="text-gray-600 mt-2">Welcome back, <?= htmlspecialchars($_SESSION['username']); ?>! Here's what's happening today.</p>
            </div>

            <!-- Stat Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <?php include '../includes/db.php'; ?>
                <div class="stat-card bg-white rounded-xl shadow-sm p-4 flex flex-col">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-gray-600 text-sm">Total Sales</p>
                            <h3 id="totalSales" class="text-2xl font-bold mt-1">Rs.0.00</h3>
                        </div>
                        <div class="bg-accent.purple p-2 rounded-lg">
                            <i class="fas fa-dollar-sign text-purple-600"></i>
                        </div>
                    </div>
                    <div class="mt-4">
                        <select id="salesPeriod" class="stat-period-selector text-xs border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-purple-500">
                            <option value="all">All Time</option>
                            <option value="30d" selected>Last 30 Days</option>
                            <option value="7d">Last 7 Days</option>
                            <option value="this_month">This Month</option>
                        </select>
                    </div>
                </div>

                <div class="stat-card bg-white rounded-xl shadow-sm p-4 flex flex-col">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-gray-600 text-sm">Total Purchases</p>
                            <h3 id="totalPurchases" class="text-2xl font-bold mt-1">Rs.0.00</h3>
                        </div>
                         <div class="bg-accent.purple p-2 rounded-lg">
                            <i class="fas fa-shopping-cart text-purple-600"></i>
                        </div>
                    </div>
                    <div class="mt-4">
                        <select id="purchasesPeriod" class="stat-period-selector text-xs border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-purple-500">
                            <option value="all">All Time</option>
                            <option value="30d" selected>Last 30 Days</option>
                            <option value="7d">Last 7 Days</option>
                            <option value="this_month">This Month</option>
                        </select>
                    </div>
                </div>

                <div class="stat-card bg-white rounded-xl shadow-sm p-4 flex flex-col">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-gray-600 text-sm">Net Profit</p>
                            <h3 id="netProfit" class="text-2xl font-bold mt-1 text-green-600">Rs.0.00</h3>
                        </div>
                        <div class="bg-accent.purple p-2 rounded-lg">
                            <i class="fas fa-chart-line text-purple-600"></i>
                        </div>
                    </div>
                    <div class="mt-4">
                         <select id="profitPeriod" class="stat-period-selector text-xs border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-purple-500">
                            <option value="all">All Time</option>
                            <option value="30d" selected>Last 30 Days</option>
                            <option value="7d">Last 7 Days</option>
                            <option value="this_month">This Month</option>
                        </select>
                    </div>
                </div>

                <div class="stat-card bg-white rounded-xl shadow-sm p-4 flex flex-col">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-gray-600 text-sm">Stock Value (at Sale Price)</p>
                            <h3 id="stockValue" class="text-2xl font-bold mt-1">Rs.0.00</h3>
                        </div>
                        <div class="bg-accent.blue p-2 rounded-lg">
                            <i class="fas fa-boxes text-blue-600"></i>
                        </div>
                    </div>
                    <div class="mt-auto pt-4">
                        <p class="text-xs text-gray-500">Based on current inventory</p>
                    </div>
                </div>
            </div>

            <!-- Charts -->
            <div class="grid grid-cols-1 lg:grid-cols-5 gap-6 mb-8">
                <div class="bg-white rounded-xl shadow-sm p-6 lg:col-span-3">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-lg font-semibold">Sales vs Purchases Over Time</h2>
                    </div>
                    <div class="chart-container">
                        <canvas id="purchasesChart"></canvas>
                    </div>
                </div>

                <div class="bg-white rounded-xl shadow-sm p-6 lg:col-span-2">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-lg font-semibold">Sales Distribution by Category</h2>
                    </div>
                    <div class="chart-container flex items-center justify-center">
                         <canvas id="salesDistChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Low Stock Alerts & IMEI Import -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div class="bg-white rounded-xl shadow-sm p-6 lg:col-span-2">
                    <h2 class="text-lg font-semibold mb-4">Low Stock Items</h2>
                    <div class="overflow-x-auto max-h-96">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead>
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                </tr>
                            </thead>
                            <tbody id="lowStockList" class="divide-y divide-gray-200">
                                <?php
                                $threshold = 10;
                                // FIX: Changed 'available_qty' to 'quantity' to match the updated database schema.
                                $result = $conn->query("SELECT product_name, quantity as total_stock FROM purchases WHERE quantity > 0 AND quantity < $threshold ORDER BY quantity ASC");
                                if ($result && $result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo '<tr class="low-stock-item">';
                                        echo '<td class="px-4 py-3 whitespace-nowrap"><div class="font-medium">' . htmlspecialchars($row['product_name']) . '</div></td>';
                                        echo '<td class="px-4 py-3 whitespace-nowrap"><div class="text-sm">Current: ' . $row['total_stock'] . '</div></td>';
                                        echo '<td class="px-4 py-3 whitespace-nowrap"><div class="flex items-center"><div class="status-indicator failed mr-2"></div><span class="text-sm text-red-600 font-semibold">Low Stock</span></div></td>';
                                        echo '</tr>';
                                    }
                                } else {
                                    echo '<tr><td colspan="3" class="px-4 py-3 text-center text-gray-500">No low stock items.</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="bg-white rounded-xl shadow-sm p-6">
                    <h2 class="text-lg font-semibold mb-4">IMEI Import Status</h2>
                    <div class="space-y-4">
                        <div class="p-4 rounded-lg bg-green-50 flex items-center">
                            <i class="fas fa-check-circle text-green-500 text-xl mr-3"></i>
                            <div><p class="font-medium">Batch #1234</p><p class="text-sm text-green-700">Imported successfully</p></div>
                        </div>
                        <div class="p-4 rounded-lg bg-red-50 flex items-center">
                            <i class="fas fa-exclamation-triangle text-red-500 text-xl mr-3"></i>
                            <div><p class="font-medium">Batch #1235</p><p class="text-sm text-red-700">Failed to import</p></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Admin Announcements -->
            <div class="mt-6 bg-white rounded-xl shadow-sm p-6">
                <div class="flex justify-between items-start">
                    <h2 class="text-lg font-semibold">Admin Announcement</h2>
                    <button id="addAnnouncementBtn" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded inline-flex items-center">
                        <i class="fas fa-plus mr-2"></i> Add
                    </button>
                </div>
                <div id="announcementList" class="mt-4">
                    <?php
                    $result_announcements = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC");
                    if ($result_announcements && $result_announcements->num_rows > 0) {
                        while ($row = $result_announcements->fetch_assoc()) {
                            echo '<div class="announcement-item mb-4 p-4 border border-gray-200 rounded-lg" id="announcement-'.$row['id'].'">';
                            echo '<h3 class="font-bold text-lg">' . htmlspecialchars($row['title']) . '</h3>';
                            echo '<p class="text-gray-700 mt-1">' . nl2br(htmlspecialchars($row['description'])) . '</p>';
                            echo '<p class="text-xs text-gray-500 mt-2">Posted on: ' . date('d M Y, h:i A', strtotime($row['created_at'])) . '</p>';
                            echo '<div class="mt-3 flex justify-end space-x-2">';
                            echo '<button class="edit-announcement text-yellow-600 hover:text-yellow-900" data-id="' . $row['id'] . '" data-title="'.htmlspecialchars($row['title']).'" data-description="'.htmlspecialchars($row['description']).'"><i class="fas fa-edit"></i> Edit</button>';
                            echo '<button class="delete-announcement text-red-600 hover:text-red-900" data-id="' . $row['id'] . '"><i class="fas fa-trash"></i> Delete</button>';
                            echo '</div>';
                            echo '</div>';
                        }
                    } else {
                        echo '<p id="no-announcements" class="text-gray-500">No announcements yet.</p>';
                    }
                    ?>
                </div>
            </div>
        </div>

        <!-- Add/Edit Announcement Modal -->
        <div id="announcementModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div class="relative top-20 mx-auto p-5 border w-full max-w-md shadow-lg rounded-md bg-white">
                <div class="mt-3">
                    <h3 id="modalTitle" class="text-lg leading-6 font-medium text-gray-900 text-center">Add Announcement</h3>
                    <form id="announcementForm" class="mt-4 space-y-4">
                        <input type="hidden" name="id" id="announcementId">
                        <div>
                            <label for="announcementTitle" class="block text-sm font-medium text-gray-700">Title</label>
                            <input type="text" name="title" id="announcementTitle" placeholder="Announcement Title" class="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                        </div>
                        <div>
                            <label for="announcementDescription" class="block text-sm font-medium text-gray-700">Description</label>
                            <textarea name="description" id="announcementDescription" placeholder="Description" rows="4" class="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500" required></textarea>
                        </div>
                        <div class="items-center px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                            <button type="submit" id="saveAnnouncementBtn" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">Save</button>
                            <button type="button" class="close-modal mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:w-auto sm:text-sm">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        let purchasesChart, salesDistChart;

        // Function to format currency
        const formatCurrency = (value) => `Rs.${parseFloat(value).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

        // Fetch and update stat cards
        function updateStats() {
            const salesPeriod = document.getElementById('salesPeriod').value;
            const purchasesPeriod = document.getElementById('purchasesPeriod').value;
            const profitPeriod = document.getElementById('profitPeriod').value;

            $.ajax({
                url: `get_dashboard_stats.php?sales_period=${salesPeriod}&purchases_period=${purchasesPeriod}&profit_period=${profitPeriod}`,
                dataType: 'json',
                success: function(data) {
                    $('#totalSales').text(formatCurrency(data.total_sales));
                    $('#totalPurchases').text(formatCurrency(data.total_purchases));
                    $('#netProfit').text(formatCurrency(data.net_profit));
                    $('#stockValue').text(formatCurrency(data.stock_value));
                },
                error: function(error) {
                    console.error('Error fetching stats:', error);
                }
            });
        }

        // Fetch data for Sales vs Purchases Chart
        function updatePurchasesChart() {
            $.ajax({
                url: 'get_sales_vs_purchases_chart_data.php',
                dataType: 'json',
                success: function(data) {
                    const ctx = document.getElementById('purchasesChart').getContext('2d');
                    if(purchasesChart) purchasesChart.destroy();
                    purchasesChart = new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: data.labels,
                            datasets: [
                                {
                                    label: 'Total Sales (Rs.)',
                                    data: data.sales_values,
                                    backgroundColor: 'rgba(59, 130, 246, 0.5)',
                                    borderColor: 'rgba(59, 130, 246, 1)',
                                    borderWidth: 1
                                },
                                {
                                    label: 'Total Purchases (Rs.)',
                                    data: data.purchase_values,
                                    backgroundColor: 'rgba(16, 185, 129, 0.5)',
                                    borderColor: 'rgba(16, 185, 129, 1)',
                                    borderWidth: 1
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: { y: { beginAtZero: true } }
                        }
                    });
                }
            });
        }

        // Fetch data for Sales Distribution Chart
        function updateSalesDistChart() {
            $.ajax({
                url: 'get_sales_dist_data.php',
                dataType: 'json',
                success: function(data) {
                    const ctx = document.getElementById('salesDistChart').getContext('2d');
                    if(salesDistChart) salesDistChart.destroy();
                    salesDistChart = new Chart(ctx, {
                        type: 'doughnut',
                        data: {
                            labels: data.labels,
                            datasets: [{
                                label: 'Sales by Category',
                                data: data.values,
                                backgroundColor: ['#3B82F6', '#10B981', '#F59E0B', '#EF4444'],
                                hoverOffset: 4
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                        }
                    });
                }
            });
        }

        // Initial data load
        updateStats();
        updatePurchasesChart();
        updateSalesDistChart();

        // Event listener for stat card period selectors
        document.querySelectorAll('.stat-period-selector').forEach(selector => {
            selector.addEventListener('change', updateStats);
        });

        // Announcement Modal Logic
        const announcementModal = document.getElementById('announcementModal');
        const modalTitle = document.getElementById('modalTitle');
        const announcementForm = document.getElementById('announcementForm');
        const announcementIdInput = document.getElementById('announcementId');
        const announcementTitleInput = document.getElementById('announcementTitle');
        const announcementDescriptionInput = document.getElementById('announcementDescription');

        const openModal = () => announcementModal.classList.remove('hidden');
        const closeModal = () => announcementModal.classList.add('hidden');

        document.getElementById('addAnnouncementBtn').addEventListener('click', () => {
            announcementForm.reset();
            announcementIdInput.value = '';
            modalTitle.textContent = 'Add Announcement';
            openModal();
        });

        document.querySelectorAll('.close-modal').forEach(el => el.addEventListener('click', closeModal));

        document.getElementById('announcementList').addEventListener('click', function(e) {
            if (e.target.closest('.edit-announcement')) {
                const button = e.target.closest('.edit-announcement');
                announcementIdInput.value = button.dataset.id;
                announcementTitleInput.value = button.dataset.title;
                announcementDescriptionInput.value = button.dataset.description;
                modalTitle.textContent = 'Edit Announcement';
                openModal();
            }

            if (e.target.closest('.delete-announcement')) {
                const button = e.target.closest('.delete-announcement');
                const id = button.dataset.id;
                if (confirm('Are you sure you want to delete this announcement?')) {
                    $.ajax({
                        url: `delete_announcement.php?id=${id}`,
                        method: 'DELETE',
                        dataType: 'json',
                        success: function(data) {
                            if (data.success) {
                                $(`#announcement-${id}`).remove();
                                alert('Announcement deleted successfully.');
                            } else {
                                alert('Error: ' + data.error);
                            }
                        }
                    });
                }
            }
        });

        announcementForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const id = formData.get('id');
            const url = id ? 'edit_announcement.php' : 'add_announcement.php';

            $.ajax({
                url: url,
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(data) {
                    if (data.success) {
                        alert(data.message);
                        location.reload();
                    } else {
                        alert('Error: ' . data.error);
                    }
                }
            });
        });
    });
    </script>
</body>
</html>