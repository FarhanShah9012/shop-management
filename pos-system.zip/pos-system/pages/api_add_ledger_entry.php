<?php
// File: /pos-system/pages/api_add_ledger_entry.php
include '../includes/db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
    exit;
}

$customer_id = (int)($_POST['customer_id'] ?? 0);
$date = $_POST['date'] ?? '';
$description = trim($_POST['description'] ?? 'Manual Entry');
$amount = (float)($_POST['amount'] ?? 0);
$type = $_POST['type'] ?? ''; // 'debit' or 'credit'

if ($customer_id <= 0 || empty($date) || $amount <= 0 || !in_array($type, ['debit', 'credit'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid data provided.']);
    exit;
}

$debit = ($type === 'debit') ? $amount : 0;
$credit = ($type === 'credit') ? $amount : 0;
$ref_type = ($type === 'debit') ? 'PAYMENT_DEBIT' : 'PAYMENT_CREDIT';

$stmt = $conn->prepare("INSERT INTO customer_ledger (customer_id, transaction_date, description, ref_type, debit, credit) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("isssdd", $customer_id, $date, $description, $ref_type, $debit, $credit);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Ledger entry added successfully.']);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to add ledger entry.']);
}

$stmt->close();
$conn->close();
?>