<?php
include '../includes/db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id']) || !isset($_POST['title']) || !isset($_POST['description'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid request.']);
    exit;
}

$id = (int)$_POST['id'];
$title = trim($_POST['title']);
$description = trim($_POST['description']);

if (empty($title) || empty($description)) {
    echo json_encode(['success' => false, 'error' => 'Title and description cannot be empty.']);
    exit;
}

$stmt = $conn->prepare("UPDATE announcements SET title = ?, description = ? WHERE id = ?");
$stmt->bind_param("ssi", $title, $description, $id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Announcement updated successfully.']);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to update announcement.']);
}

$stmt->close();
$conn->close();
?>