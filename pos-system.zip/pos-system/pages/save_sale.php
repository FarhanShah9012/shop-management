<?php
include '../includes/db.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['customer_name']) || !isset($data['items']) || empty($data['items'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid or incomplete data.']);
    exit;
}

$conn->begin_transaction();

try {
    // Insert into sales table
    $stmt = $conn->prepare("INSERT INTO sales (customer_name, phone, invoice_no, invoice_date, total_amount, received, remaining) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssddd", 
        $data['customer_name'], 
        $data['phone'], 
        $data['invoice_no'], 
        $data['invoice_date'], 
        $data['invoice_amount'], 
        $data['received_amount'], 
        $data['remaining_amount']
    );
    $stmt->execute();
    $sales_id = $stmt->insert_id;
    $stmt->close();

    // Process each item
    foreach ($data['items'] as $item) {
        // Get purchase details for cost price
        $stmt = $conn->prepare("SELECT id, purchase_price FROM purchases WHERE product_name = ? AND specifications = ? AND available_qty >= ?");
        $stmt->bind_param("ssi", $item['product_name'], $item['specification'], $item['qty']);
        $stmt->execute();
        $result = $stmt->get_result();
        $purchase = $result->fetch_assoc();
        $stmt->close();

        if (!$purchase) {
            throw new Exception("Insufficient stock or product not found: {$item['product_name']}");
        }

        // Insert into sales_items
        $total = $item['qty'] * $item['price'];
        $stmt = $conn->prepare("INSERT INTO sales_items (sales_id, purchase_id, product_name, specification, qty, price, total) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iissidd", 
            $sales_id, 
            $purchase['id'], 
            $item['product_name'], 
            $item['specification'], 
            $item['qty'], 
            $item['price'], 
            $total
        );
        $stmt->execute();
        $sales_item_id = $stmt->insert_id;
        $stmt->close();

        // Insert IMEIs into sales_imeis
        foreach ($item['imeis'] as $imei) {
            $stmt = $conn->prepare("INSERT INTO sales_imeis (sales_item_id, imei) VALUES (?, ?)");
            $stmt->bind_param("is", $sales_item_id, $imei);
            $stmt->execute();
            $stmt->close();

            // Update purchase_imeis status
            $stmt = $conn->prepare("UPDATE purchase_imeis SET status = 'Sold' WHERE purchase_id = ? AND (imei1 = ? OR imei2 = ?)");
            $stmt->bind_param("iss", $purchase['id'], $imei, $imei);
            $stmt->execute();
            $stmt->close();
        }

        // Update purchase available_qty
        $stmt = $conn->prepare("UPDATE purchases SET available_qty = available_qty - ? WHERE id = ?");
        $stmt->bind_param("ii", $item['qty'], $purchase['id']);
        $stmt->execute();
        $stmt->close();

        // Insert into sales for profit calculation
        $stmt = $conn->prepare("INSERT INTO sales (imei_id, sale_price, cost_price, sale_date) VALUES ((SELECT id FROM purchase_imeis WHERE purchase_id = ? AND imei1 = ? LIMIT 1), ?, ?, ?)");
        $stmt->bind_param("isdds", $purchase['id'], $item['imeis'][0], $item['price'], $purchase['purchase_price'], $data['invoice_date']);
        $stmt->execute();
        $stmt->close();
    }

    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Sale saved successfully']);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$conn->close();
?>