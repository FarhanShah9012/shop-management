<?php
include '../includes/db.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'error' => 'Invalid data.']);
    exit;
}

$conn->begin_transaction();

try {
    // --- Customer and Ledger Logic ---
    $customer_id = null;
    $customer_name = trim($data['customer_name']);
    $customer_phone = trim($data['phone_no']);
    $remaining_amount = $data['totals']['invoice_amount'] - $data['totals']['received_amount'];

    if (!empty($customer_phone)) {
        // Find or create customer
        $stmt_cust = $conn->prepare("SELECT id FROM customers WHERE phone = ?");
        $stmt_cust->bind_param("s", $customer_phone);
        $stmt_cust->execute();
        $cust_result = $stmt_cust->get_result();
        if ($cust_row = $cust_result->fetch_assoc()) {
            $customer_id = $cust_row['id'];
        } else {
            // Create new customer if name and phone are provided
            if (!empty($customer_name)) {
                $stmt_new_cust = $conn->prepare("INSERT INTO customers (name, phone) VALUES (?, ?)");
                $stmt_new_cust->bind_param("ss", $customer_name, $customer_phone);
                $stmt_new_cust->execute();
                $customer_id = $stmt_new_cust->insert_id;
                $stmt_new_cust->close();
            }
        }
        $stmt_cust->close();
    }
    // --- End Customer Logic ---


    // 1. Insert into invoices table
    $stmt = $conn->prepare("INSERT INTO invoices (customer_id, invoice_number, customer_name, customer_phone, invoice_date, sub_total, received_amount, previous_balance, grand_total) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssddd", 
        $customer_id,
        $data['invoice_no'], 
        $data['customer_name'], 
        $data['phone_no'], 
        $data['invoice_date'],
        $data['totals']['invoice_amount'],
        $data['totals']['received_amount'],
        $data['totals']['previous_balance'],
        $data['totals']['grand_total']
    );
    $stmt->execute();
    $invoice_id = $stmt->insert_id;
    $stmt->close();
    
    // Add debit to ledger if there is a remaining amount and a customer is linked
    if ($customer_id && $remaining_amount > 0) {
        $ledger_stmt = $conn->prepare("INSERT INTO customer_ledger (customer_id, transaction_date, description, ref_id, ref_type, debit, credit) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $description = "Sale - Invoice #" . $data['invoice_no'];
        $ref_type = 'INVOICE';
        $credit = 0.00;
        $ledger_stmt->bind_param("issisdd", $customer_id, $data['invoice_date'], $description, $invoice_id, $ref_type, $remaining_amount, $credit);
        $ledger_stmt->execute();
        $ledger_stmt->close();
    }


    // 2. Loop through items and process them
    foreach ($data['items'] as $item) {
        $purchase_stmt = $conn->prepare("SELECT purchase_price FROM purchases WHERE id = ?");
        $purchase_stmt->bind_param("i", $item['purchase_id']);
        $purchase_stmt->execute();
        $purchase_price = $purchase_stmt->get_result()->fetch_assoc()['purchase_price'];
        $purchase_stmt->close();

        $item_stmt = $conn->prepare("INSERT INTO invoice_items (invoice_id, purchase_id, product_name, specification, quantity, sale_price_per_unit, purchase_price_per_unit, total) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $item_stmt->bind_param("iissiddd", 
            $invoice_id, $item['purchase_id'], $item['product_name'], $item['specification'],
            $item['qty'], $item['price'], $purchase_price, $item['total']
        );
        $item_stmt->execute();
        $invoice_item_id = $item_stmt->insert_id;
        $item_stmt->close();

        $update_qty_stmt = $conn->prepare("UPDATE purchases SET quantity = quantity - ? WHERE id = ?");
        $update_qty_stmt->bind_param("ii", $item['qty'], $item['purchase_id']);
        $update_qty_stmt->execute();
        $update_qty_stmt->close();

        if (!empty($item['imei_ids'])) {
            $imei_ids_list = implode(',', array_map('intval', $item['imei_ids']));
            $update_imei_stmt = $conn->prepare("UPDATE imei_table SET status = 'Sold', invoice_item_id = ? WHERE id IN ($imei_ids_list)");
            $update_imei_stmt->bind_param("i", $invoice_item_id);
            $update_imei_stmt->execute();
            $update_imei_stmt->close();
        }
    }

    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Sale processed successfully!', 'invoice_data' => $data]);

} catch (mysqli_sql_exception $exception) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => 'Database transaction failed: ' . $exception->getMessage()]);
}

$conn->close();
?>