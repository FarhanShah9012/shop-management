<?php
// File: /pos-system/pages/api_get_returnable_invoice_details.php
include '../includes/db.php';
header('Content-Type: application/json');

$invoice_id = isset($_GET['invoice_id']) ? (int)$_GET['invoice_id'] : 0;
if (!$invoice_id) {
    echo json_encode(['success' => false, 'error' => 'Invoice ID is required.']);
    exit;
}

try {
    // Get basic invoice info
    $stmt_invoice = $conn->prepare("SELECT invoice_number, customer_name FROM invoices WHERE id = ?");
    $stmt_invoice->bind_param("i", $invoice_id);
    $stmt_invoice->execute();
    $invoice = $stmt_invoice->get_result()->fetch_assoc();
    $stmt_invoice->close();

    if (!$invoice) throw new Exception("Invoice not found.");

    // Get items that have been sold under this invoice but NOT yet returned
    $sql = "
        SELECT 
            it.id as imei_id,
            it.imei1,
            it.imei2,
            ii.id as invoice_item_id,
            ii.product_name,
            ii.sale_price_per_unit
        FROM imei_table it
        JOIN invoice_items ii ON it.invoice_item_id = ii.id
        WHERE ii.invoice_id = ? 
        AND it.id NOT IN (SELECT imei_id FROM sales_returns)
    ";
    
    $stmt_items = $conn->prepare($sql);
    $stmt_items->bind_param("i", $invoice_id);
    $stmt_items->execute();
    $result = $stmt_items->get_result();
    $items = [];
    while ($row = $result->fetch_assoc()) {
        $items[] = [
            'imei_id' => $row['imei_id'],
            'invoice_item_id' => $row['invoice_item_id'],
            'product_name' => $row['product_name'],
            'sale_price_per_unit' => $row['sale_price_per_unit'],
            'imei_text' => $row['imei1'] . ' / ' . $row['imei2']
        ];
    }
    $stmt_items->close();

    echo json_encode(['success' => true, 'invoice' => $invoice, 'items' => $items]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$conn->close();
?>