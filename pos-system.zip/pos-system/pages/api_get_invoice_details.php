<?php
// File: /pos-system/pages/api_get_invoice_details.php
include '../includes/db.php';
header('Content-Type: application/json');

$invoice_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$invoice_id) {
    echo json_encode(['success' => false, 'error' => 'Invoice ID is required.']);
    exit;
}

try {
    // 1. Get main invoice data
    $stmt_invoice = $conn->prepare("SELECT * FROM invoices WHERE id = ?");
    $stmt_invoice->bind_param("i", $invoice_id);
    $stmt_invoice->execute();
    $invoice_result = $stmt_invoice->get_result();
    $invoice = $invoice_result->fetch_assoc();
    $stmt_invoice->close();

    if (!$invoice) {
        throw new Exception('Invoice not found.');
    }

    // 2. Get invoice items, including their status
    $stmt_items = $conn->prepare("SELECT *, status as item_status FROM invoice_items WHERE invoice_id = ?");
    $stmt_items->bind_param("i", $invoice_id);
    $stmt_items->execute();
    $items_result = $stmt_items->get_result();
    $items = [];
    while ($item = $items_result->fetch_assoc()) {
        // 3. For each item, get its IMEIs
        $stmt_imei = $conn->prepare("SELECT imei1, imei2 FROM imei_table WHERE invoice_item_id = ?");
        $stmt_imei->bind_param("i", $item['id']);
        $stmt_imei->execute();
        $imei_result = $stmt_imei->get_result();
        $imei_texts = [];
        while ($imei_row = $imei_result->fetch_assoc()) {
            $imei_texts[] = $imei_row['imei1'] . ' / ' . $imei_row['imei2'];
        }
        $stmt_imei->close();
        
        $items[] = [
            'product_name' => $item['product_name'],
            'specification' => $item['specification'],
            'qty' => $item['quantity'],
            'price' => $item['sale_price_per_unit'],
            'total' => $item['total'],
            'imei_texts' => $imei_texts,
            'status' => $item['item_status'] // Add the status here
        ];
    }
    $stmt_items->close();

    // 4. Assemble the final data object in the same structure as sales.php
    $remaining_amount = $invoice['sub_total'] - $invoice['received_amount'];
    
    $response_data = [
        'customer_name' => $invoice['customer_name'],
        'phone_no' => $invoice['customer_phone'],
        'invoice_date' => $invoice['invoice_date'],
        'invoice_no' => $invoice['invoice_number'],
        'items' => $items,
        'totals' => [
            'invoice_amount' => $invoice['sub_total'],
            'received_amount' => $invoice['received_amount'],
            'remaining_amount' => $remaining_amount,
            'previous_balance' => $invoice['previous_balance'],
            'grand_total' => $invoice['grand_total']
        ]
    ];

    echo json_encode(['success' => true, 'data' => $response_data]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$conn->close();
?>