<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Invoice</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- jQuery and jQuery UI for Autocomplete -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    
    <!-- Select2 for searchable dropdown -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <style>
        .select2-container .select2-selection--multiple { border: 1px solid #d1d5db; border-radius: 0.5rem; padding: 2px; }
        .ui-autocomplete { z-index: 9999; max-height: 200px; overflow-y: auto; overflow-x: hidden; }
        .select2-results__option { font-size: 0.875rem; }
    </style>
</head>
<body class="bg-gray-100">
    <?php include '../includes/sidebar.php'; ?>
    <div class="ml-64 transition-all duration-300 ease-in-out p-4">
        <div class="max-w-7xl mx-auto bg-white rounded-2xl shadow-lg p-6 sm:p-8">
            <?php include '../includes/header.php'; ?>
            <!-- Customer and Invoice Info Header -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8 mb-10">
                <div class="flex flex-col gap-6">
                    <div>
                        <label for="customer-name" class="block text-sm font-medium text-gray-700 mb-1">Customer Name</label>
                        <input type="text" id="customer-name" placeholder="Enter customer name" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    <div>
                        <label for="phone-no" class="block text-sm font-medium text-gray-700 mb-1">Phone No</label>
                        <input type="tel" id="phone-no" placeholder="Enter phone number to fetch balance" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
                    </div>
                </div>
                <div class="flex flex-col gap-6">
                    <div>
                        <label for="invoice-date" class="block text-sm font-medium text-gray-700 mb-1">Invoice Date</label>
                        <input type="date" id="invoice-date" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    <div>
                        <label for="invoice-no" class="block text-sm font-medium text-gray-700 mb-1">Invoice No</label>
                        <input type="text" id="invoice-no" value="INV-<?= time() ?>" readonly class="w-full px-4 py-2.5 border border-gray-300 rounded-lg bg-gray-100 text-gray-600">
                    </div>
                </div>
            </div>

            <hr class="mb-6">
            
            <div id="invoice-items-container">
                <div class="hidden md:grid grid-cols-12 gap-4 pb-2 border-b-2 border-gray-200">
                    <div class="col-span-2 text-sm font-semibold text-gray-600">Product Name</div>
                    <div class="col-span-4 text-sm font-semibold text-gray-600">IMEIs</div>
                    <div class="col-span-2 text-sm font-semibold text-gray-600">Specification</div>
                    <div class="col-span-1 text-sm font-semibold text-gray-600">Qty</div>
                    <div class="col-span-1 text-sm font-semibold text-gray-600">Price</div>
                    <div class="col-span-1 text-sm font-semibold text-gray-600 text-right">Total</div>
                    <div class="col-span-1 text-center">Action</div>
                </div>
            </div>

            <div class="text-center my-6">
              <button id="add-item-btn" class="w-full border-2 border-dashed border-gray-300 rounded-lg py-3 text-sm font-semibold text-white bg-[#2563eb] hover:bg-blue-700 transition-colors">
                <svg class="w-5 h-5 inline-block -mt-0.5 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" /></svg>
                Add New Item
              </button>
            </div>
            
            <div class="mt-12 flex flex-col md:flex-row justify-end items-start gap-8">
                <div class="w-full md:w-auto md:min-w-[320px] space-y-4">
                    <div class="flex justify-between items-center"><span class="text-sm font-medium text-gray-600">Invoice Amount</span><span id="invoice-amount" class="text-sm font-semibold text-gray-800">Rs. 0.00</span></div>
                    <div class="flex justify-between items-center">
                        <label for="received-amount" class="text-sm font-medium text-gray-600">Received Amount</label>
                        <input type="number" id="received-amount" value="0" step="0.01" class="w-32 px-3 py-1.5 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-sm text-right">
                    </div>
                    <div class="flex justify-between items-center"><span class="text-sm font-medium text-gray-600">Remaining Amount</span><span id="remaining-amount" class="text-sm font-semibold text-gray-800">Rs. 0.00</span></div>
                    <div class="flex justify-between items-center pt-2 border-t">
                        <label for="previous-balance" class="text-sm font-medium text-gray-600">Previous Balance</label>
                        <input type="number" id="previous-balance" value="0" step="0.01" class="w-32 px-3 py-1.5 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-sm text-right">
                    </div>
                    <div class="flex justify-between items-center bg-gray-100 p-3 rounded-lg mt-2">
                        <span class="text-lg font-bold text-gray-800">Grand Total</span><span id="grand-total" class="text-xl font-bold text-gray-900">Rs. 0.00</span>
                    </div>
                </div>
            </div>

            <div class="mt-8 flex justify-end">
                 <button id="print-invoice-btn" class="flex items-center justify-center gap-2 w-full md:w-auto px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all">
                    <i class="fas fa-print"></i> <span>Print Invoice</span>
                </button>
            </div>
        </div>
    </div>

    <template id="invoice-item-template">
        <div class="item-row grid grid-cols-12 gap-4 items-center mt-4 border-t pt-4 md:border-none md:pt-0">
            <input type="hidden" class="purchase-id">
            <div class="col-span-12 md:col-span-2">
                <input type="text" placeholder="Search product..." class="product-name w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
            </div>
            <div class="col-span-12 md:col-span-4">
                <select class="imeis-select w-full" multiple="multiple"></select>
            </div>
            <div class="col-span-12 md:col-span-2">
                <input type="text" readonly placeholder="Specification" class="specification w-full px-3 py-2 border-gray-200 bg-gray-100 rounded-lg text-sm">
            </div>
            <div class="col-span-4 md:col-span-1">
                <input type="number" value="0" min="0" readonly class="quantity w-full px-2 py-2 border-gray-200 bg-gray-100 rounded-lg text-sm text-center">
            </div>
            <div class="col-span-4 md:col-span-1">
                <input type="number" value="0.00" step="0.01" class="price w-full px-2 py-2 border border-gray-300 rounded-lg text-sm text-right">
            </div>
            <div class="col-span-3 md:col-span-1 text-right text-sm font-medium text-gray-800">
                <span class="total">Rs. 0.00</span>
            </div>
            <div class="col-span-1 text-center">
                <button class="delete-row-btn text-gray-400 hover:text-red-500"><i class="fas fa-trash"></i></button>
            </div>
        </div>
    </template>
    
    <script>
    $(document).ready(function() {
        document.getElementById('invoice-date').valueAsDate = new Date();
        const formatCurrency = (val) => `Rs. ${parseFloat(val).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

        function initializeRow(row) {
            row.find(".product-name").autocomplete({
                source: "api_search_products.php",
                minLength: 1,
                select: function(event, ui) {
                    const item = ui.item;
                    row.find(".purchase-id").val(item.id);
                    row.find(".specification").val(item.specifications);
                    row.find(".price").val(parseFloat(item.price).toFixed(2));
                    $.getJSON(`api_get_imeis.php?purchase_id=${item.id}`, function(imeiData) {
                        const imeiSelect = row.find(".imeis-select");
                        imeiSelect.empty();
                        if (imeiData.length > 0) {
                            imeiData.forEach(function(imei) {
                                imeiSelect.append(new Option(imei.text, imei.id, false, false));
                            });
                        }
                        imeiSelect.trigger('change');
                        imeiSelect.select2('open');
                    });
                    setTimeout(() => updateRow(row), 100);
                }
            });
            row.find(".imeis-select").select2({ placeholder: "Select IMEIs", allowClear: true });
        }

        function updateRow(row) {
            const qty = parseInt(row.find(".quantity").val()) || 0;
            const price = parseFloat(row.find(".price").val()) || 0;
            const rowTotal = qty * price;
            row.find(".total").text(formatCurrency(rowTotal));
            updateTotals();
        }

        function updateTotals() {
            let invoiceAmount = 0;
            $(".item-row").each(function() {
                const qty = parseInt($(this).find(".quantity").val()) || 0;
                const price = parseFloat($(this).find(".price").val()) || 0;
                invoiceAmount += qty * price;
            });
            const receivedAmount = parseFloat($("#received-amount").val()) || 0;
            const previousBalance = parseFloat($("#previous-balance").val()) || 0;
            const remainingAmount = invoiceAmount - receivedAmount;
            const grandTotal = invoiceAmount + previousBalance;
            $("#invoice-amount").text(formatCurrency(invoiceAmount));
            $("#remaining-amount").text(formatCurrency(remainingAmount));
            $("#grand-total").text(formatCurrency(grandTotal));
        }

        function addNewItem() {
            const template = document.getElementById('invoice-item-template');
            const clone = template.content.cloneNode(true);
            const newRow = $(clone.children[0]);
            $("#invoice-items-container").append(newRow);
            initializeRow(newRow);
        }

        $('#phone-no').on('blur', function() {
            const phone = $(this).val().trim();
            if (phone.length > 5) { // Basic validation
                $.getJSON(`api_get_customer_balance.php?phone=${phone}`, function(response) {
                    if (response.success && response.balance > 0) {
                        // FIX: Convert the string response to a number before calling toFixed()
                        $('#previous-balance').val(parseFloat(response.balance).toFixed(2));
                        updateTotals();
                    }
                });
            }
        });
        
        $("#add-item-btn").on("click", addNewItem);
        $("#invoice-items-container").on("input", ".price", function() { updateRow($(this).closest(".item-row")); });
        $("#invoice-items-container").on("change", ".imeis-select", function() {
            const row = $(this).closest(".item-row");
            const selectedImeis = $(this).val();
            row.find(".quantity").val(selectedImeis ? selectedImeis.length : 0);
            updateRow(row);
        });
        $("#invoice-items-container").on("click", ".delete-row-btn", function() {
            $(this).closest(".item-row").remove();
            updateTotals();
        });
        $("#received-amount, #previous-balance").on("input", updateTotals);

        $("#print-invoice-btn").on("click", function() {
            let isValid = true;
            if ($(".item-row").length === 0) {
                alert("Please add at least one item to the invoice.");
                return;
            }

            let invoiceAmount = 0;
            const items = [];
            $(".item-row").each(function() {
                const row = $(this);
                const qty = parseInt(row.find(".quantity").val());
                if (!row.find(".purchase-id").val() || qty === 0) {
                    alert("An item has a quantity of 0 or is incomplete. Please complete or remove the row.");
                    isValid = false;
                    return false;
                }
                const price = parseFloat(row.find(".price").val());
                const total = qty * price;
                invoiceAmount += total;
                items.push({
                    purchase_id: row.find(".purchase-id").val(),
                    product_name: row.find(".product-name").val(),
                    specification: row.find(".specification").val(),
                    qty: qty, price: price, total: total,
                    imei_ids: row.find(".imeis-select").val(),
                    imei_texts: row.find(".imeis-select option:selected").map((_, el) => el.text).get()
                });
            });
            if (!isValid) return;

            const receivedAmount = parseFloat($("#received-amount").val()) || 0;
            const previousBalance = parseFloat($("#previous-balance").val()) || 0;
            const grandTotal = invoiceAmount + previousBalance;
            const remainingAmount = invoiceAmount - receivedAmount;

            let invoiceData = {
                customer_name: $("#customer-name").val(),
                phone_no: $("#phone-no").val(),
                invoice_date: $("#invoice-date").val(),
                invoice_no: $("#invoice-no").val(),
                items: items,
                totals: {
                    invoice_amount: invoiceAmount,
                    received_amount: receivedAmount,
                    remaining_amount: remainingAmount,
                    previous_balance: previousBalance,
                    grand_total: grandTotal
                }
            };
            
            // Critical check: if there is a remaining amount, phone number must be provided.
            if(remainingAmount > 0 && !invoiceData.phone_no) {
                alert("A phone number is required when there is a remaining balance.");
                return;
            }

            fetch('api_process_sale.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(invoiceData)
            })
            .then(res => res.json())
            .then(result => {
                if (result.success) {
                    sessionStorage.setItem('invoicePrintData', JSON.stringify(result.invoice_data));
                    window.open('../invoice.php', '_blank');
                    alert(result.message);
                    location.reload();
                } else {
                    alert("Error: " + result.error);
                }
            }).catch(err => alert("A network error occurred: " + err));
        });

        addNewItem();
        updateTotals();
    });
    </script>
</body>
</html>