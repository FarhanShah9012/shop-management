<?php
include '../includes/db.php';
header('Content-Type: application/json');

// 1. Initialize data structure for the last 12 months
$months = [];
$sales_data = [];
$purchase_data = [];

for ($i = 11; $i >= 0; $i--) {
    $month_key = date('Y-m', strtotime("-$i months"));
    $month_label = date('M Y', strtotime("-$i months"));
    $months[$month_key] = $month_label;
    $sales_data[$month_key] = 0;
    $purchase_data[$month_key] = 0;
}

// 2. Fetch sales data from the invoices table
$sales_sql = "SELECT 
                DATE_FORMAT(invoice_date, '%Y-%m') as month, 
                SUM(sub_total) as total_sales 
              FROM invoices 
              WHERE invoice_date >= CURDATE() - INTERVAL 12 MONTH
              GROUP BY month";
$sales_result = $conn->query($sales_sql);
if ($sales_result) {
    while ($row = $sales_result->fetch_assoc()) {
        if (isset($sales_data[$row['month']])) {
            $sales_data[$row['month']] = (float)$row['total_sales'];
        }
    }
}

// 3. Fetch purchase data
// We calculate the original total value by multiplying the purchase_price with the count of its associated IMEIs,
// as the `quantity` column is dynamic. This gives the true purchase value for that month.
$purchase_sql = "SELECT 
                    DATE_FORMAT(p.purchase_date, '%Y-%m') as month, 
                    SUM(p.purchase_price * i.original_qty) as total_purchases 
                 FROM purchases p 
                 JOIN (SELECT purchase_id, COUNT(*) as original_qty FROM imei_table GROUP BY purchase_id) i ON p.id = i.purchase_id 
                 WHERE p.purchase_date >= CURDATE() - INTERVAL 12 MONTH 
                 GROUP BY month";
$purchase_result = $conn->query($purchase_sql);
if ($purchase_result) {
    while ($row = $purchase_result->fetch_assoc()) {
        if (isset($purchase_data[$row['month']])) {
            $purchase_data[$row['month']] = (float)$row['total_purchases'];
        }
    }
}

// 4. Prepare JSON response
$response = [
    'labels' => array_values($months),
    'sales_values' => array_values($sales_data),
    'purchase_values' => array_values($purchase_data),
];

echo json_encode($response);

$conn->close();
?>