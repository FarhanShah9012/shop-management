/pos-system/pages/save_invoice.php
<?php
include '../includes/db.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

// Start transaction
$conn->begin_transaction();

try {
    // Save invoice header
    $stmt = $conn->prepare("
        INSERT INTO invoices (customer_name, phone, invoice_no, invoice_date, total_amount, received_amount, remaining_amount)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param(
        'ssssddd',
        $data['customer_name'],
        $data['phone'],
        $data['invoice_no'],
        $data['invoice_date'],
        $data['total_amount'],
        $data['received_amount'],
        $data['remaining_amount']
    );
    $stmt->execute();
    $invoice_id = $conn->insert_id;
    $stmt->close();

    // Save invoice items
    foreach ($data['items'] as $item) {
        $stmt = $conn->prepare("
            INSERT INTO invoice_items (invoice_id, product_name, specification, quantity, price, total)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param(
            'issddd',
            $invoice_id,
            $item['product_name'],
            $item['specification'],
            $item['quantity'],
            $item['price'],
            $item['total']
        );
        $stmt->execute();
        $item_id = $conn->insert_id;
        $stmt->close();

        // Save IMEIs and update stock
        foreach ($item['imeis'] as $imei_id) {
            // Save IMEI in invoice
            $stmt = $conn->prepare("
                INSERT INTO invoice_item_imeis (invoice_item_id, imei)
                VALUES (?, ?)
            ");
            $imei_text = $imei_id; // This should be the actual IMEI text
            $stmt->bind_param('is', $item_id, $imei_text);
            $stmt->execute();
            $stmt->close();

            // Update IMEI status to sold
            $stmt = $conn->prepare("
                UPDATE purchase_imeis 
                SET status = 'Sold' 
                WHERE id = ?
            ");
            $stmt->bind_param('i', $imei_id);
            $stmt->execute();
            $stmt->close();
        }

        // Update available quantity in purchases table
        $stmt = $conn->prepare("
            UPDATE purchases 
            SET available_qty = available_qty - ? 
            WHERE product_name = ? AND specifications = ?
        ");
        $stmt->bind_param(
            'iss',
            $item['quantity'],
            $item['product_name'],
            $item['specification']
        );
        $stmt->execute();
        $stmt->close();
    }

    // Commit transaction
    $conn->commit();

    echo json_encode([
        'success' => true,
        'invoice_id' => $invoice_id,
        'message' => 'Invoice saved successfully'
    ]);
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}

$conn->close();
?>