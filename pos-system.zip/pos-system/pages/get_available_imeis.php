<?php
include '../includes/db.php';
header('Content-Type: application/json');

$purchase_id = isset($_GET['purchase_id']) ? (int)$_GET['purchase_id'] : 0;

$stmt = $conn->prepare("SELECT imei1, imei2 FROM purchase_imeis WHERE purchase_id = ? AND status = 'In Stock'");
$stmt->bind_param("i", $purchase_id);
$stmt->execute();
$result = $stmt->get_result();

$imeis = [];
while ($row = $result->fetch_assoc()) {
    $imeis[] = $row;
}

echo json_encode($imeis);

$stmt->close();
$conn->close();
?>