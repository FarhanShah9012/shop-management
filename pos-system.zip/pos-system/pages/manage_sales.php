<?php
// File: /pos-system/pages/manage_sales.php
include '../includes/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Sales</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Inter', sans-serif; background-color: #F9FAFB; }
        .table-row:hover { background-color: #f3f4f6; }
        .action-btn { transition: all 0.2s ease; }
        .action-btn:hover { transform: scale(1.1); }
    </style>
</head>
<body class="bg-secondary text-primary">
    <?php include '../includes/sidebar.php'; ?>
    <div class="ml-64 transition-all duration-300 ease-in-out">
        <?php include '../includes/header.php'; ?>
        <div class="container mx-auto px-4 py-8">
            <div class="flex justify-between items-center mb-8">
                <div>
                    <h1 class="text-3xl font-bold text-primary">Manage Sales</h1>
                    <p class="text-gray-600 mt-2">View, print, or delete sales records</p>
                </div>
            </div>

            <!-- Search and Filters -->
            <div class="bg-white p-4 rounded-lg shadow-sm mb-6">
                <form method="GET" action="manage_sales.php" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                    <div class="md:col-span-2">
                        <label for="search" class="block text-sm font-medium text-gray-700 mb-1">Search</label>
                        <input type="text" id="search" name="search" placeholder="Search by Invoice No, Customer, Phone..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label for="from_date" class="block text-sm font-medium text-gray-700 mb-1">From Date</label>
                        <input type="date" id="from_date" name="from_date" value="<?php echo isset($_GET['from_date']) ? $_GET['from_date'] : ''; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label for="to_date" class="block text-sm font-medium text-gray-700 mb-1">To Date</label>
                        <input type="date" id="to_date" name="to_date" value="<?php echo isset($_GET['to_date']) ? $_GET['to_date'] : ''; ?>" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div class="md:col-start-4">
                        <button type="submit" class="w-full bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">Filter</button>
                    </div>
                </form>
            </div>

            <!-- Sales Table -->
            <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                <?php
                // PHP code for pagination and filtering remains the same until the SQL query
                $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
                $per_page = 10;
                $offset = ($page - 1) * $per_page;

                $search = isset($_GET['search']) ? trim($_GET['search']) : '';
                $from_date = isset($_GET['from_date']) && !empty($_GET['from_date']) ? $_GET['from_date'] : '';
                $to_date = isset($_GET['to_date']) && !empty($_GET['to_date']) ? $_GET['to_date'] : '';

                $where = [];
                $params = [];
                $types = '';

                if ($search) {
                    $where[] = "(i.invoice_number LIKE ? OR i.customer_name LIKE ? OR i.customer_phone LIKE ?)";
                    $like_search = "%$search%";
                    array_push($params, $like_search, $like_search, $like_search);
                    $types .= 'sss';
                }
                if ($from_date) {
                    $where[] = "i.invoice_date >= ?";
                    $params[] = $from_date;
                    $types .= 's';
                }
                if ($to_date) {
                    $where[] = "i.invoice_date <= ?";
                    $params[] = $to_date;
                    $types .= 's';
                }

                $where_clause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);
                
                $count_sql = "SELECT COUNT(*) as total FROM invoices i $where_clause";
                $stmt_count = $conn->prepare($count_sql);
                if ($types) $stmt_count->bind_param($types, ...$params);
                $stmt_count->execute();
                $total = $stmt_count->get_result()->fetch_assoc()['total'];
                $stmt_count->close();
                
                $pages = ceil($total / $per_page);
                ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <?php foreach(['S.No', 'Invoice No', 'Invoice Date', 'Customer Name', 'Phone', 'Total Amount', 'Actions'] as $header): ?>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?= $header ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody id="sales-table-body" class="bg-white divide-y divide-gray-200">
                            <?php
                            // MODIFIED SQL to get return counts
                            $sql = "
                                SELECT i.*, 
                                (SELECT COUNT(*) FROM sales_returns sr WHERE sr.invoice_item_id = i.id) as return_count,
                                (SELECT SUM(quantity) FROM invoice_items ii WHERE ii.invoice_id = i.id) as total_items
                                FROM invoices i $where_clause 
                                ORDER BY i.invoice_date DESC, i.id DESC 
                                LIMIT ? OFFSET ?
                            ";
                            $stmt = $conn->prepare($sql);
                            $query_params = $params;
                            array_push($query_params, $per_page, $offset);
                            $query_types = $types . 'ii';
                            if ($query_types) $stmt->bind_param($query_types, ...$query_params);
                            $stmt->execute();
                            $result = $stmt->get_result();

                            if ($result->num_rows > 0) {
                                $s_no = $offset + 1;
                                while ($row = $result->fetch_assoc()) {
                                    $return_badge = '';
                                    if ($row['return_count'] > 0) {
                                        if ($row['return_count'] >= $row['total_items']) {
                                            $return_badge = '<span class="ml-2 text-xs font-semibold bg-red-100 text-red-800 px-2 py-0.5 rounded-full">Returned</span>';
                                        } else {
                                            $return_badge = '<span class="ml-2 text-xs font-semibold bg-yellow-100 text-yellow-800 px-2 py-0.5 rounded-full">Partially Returned</span>';
                                        }
                                    }

                                    echo '<tr class="table-row" data-invoice-id="' . $row['id'] . '">';
                                    echo '<td class="px-6 py-4 whitespace-nowrap">' . $s_no++ . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap font-medium text-gray-900">' . htmlspecialchars($row['invoice_number']) . $return_badge . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap">' . date('d M Y', strtotime($row['invoice_date'])) . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($row['customer_name']) . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($row['customer_phone']) . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap">Rs. ' . number_format($row['grand_total'], 2) . '</td>';
                                    echo '<td class="px-6 py-4 whitespace-nowrap text-sm font-medium"><div class="flex space-x-3">
                                        <button class="print-btn action-btn text-blue-600 hover:text-blue-900" title="Print"><i class="fas fa-print"></i></button>
                                        <button class="delete-btn action-btn text-red-600 hover:text-red-900" title="Delete"><i class="fas fa-trash"></i></button>
                                    </div></td>';
                                    echo '</tr>';
                                }
                            } else {
                                echo '<tr><td colspan="7" class="text-center py-10 text-gray-500">No sales records found.</td></tr>';
                            }
                            $stmt->close();
                            ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($pages > 1): ?>
                <div class="border-t border-gray-200 px-4 py-3 flex items-center justify-center">
                    <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                         <?php
                        $query_string = "search=".urlencode($search)."&from_date=$from_date&to_date=$to_date";
                        if ($page > 1) echo "<a href='?page=".($page-1)."&$query_string' class='relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50'><i class='fas fa-chevron-left'></i></a>";
                        for ($i = 1; $i <= $pages; $i++) {
                            if ($i == $page) {
                                echo "<a href='#' aria-current='page' class='z-10 bg-blue-50 border-blue-500 text-blue-600 relative inline-flex items-center px-4 py-2 border text-sm font-medium'>$i</a>";
                            } else {
                                echo "<a href='?page=$i&$query_string' class='bg-white border-gray-300 text-gray-500 hover:bg-gray-50 relative inline-flex items-center px-4 py-2 border text-sm font-medium'>$i</a>";
                            }
                        }
                        if ($page < $pages) echo "<a href='?page=".($page+1)."&$query_string' class='relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50'><i class='fas fa-chevron-right'></i></a>";
                        ?>
                    </nav>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="js/manage_sales_actions.js"></script> <!-- Assuming you might create a separate JS file -->
    <script>
    $(document).ready(function() {
        $('#sales-table-body').on('click', '.print-btn', function() {
            const invoiceId = $(this).closest('tr').data('invoice-id');
            
            $.getJSON(`api_get_invoice_details.php?id=${invoiceId}`, function(response) {
                if(response.success) {
                    sessionStorage.setItem('invoicePrintData', JSON.stringify(response.data));
                    window.open('../invoice.php', '_blank');
                } else {
                    alert('Error: ' + response.error);
                }
            });
        });

        $('#sales-table-body').on('click', '.delete-btn', function() {
            const row = $(this).closest('tr');
            const invoiceId = row.data('invoice-id');
            const invoiceNo = row.find('td:nth-child(2)').text().trim().split(" ")[0]; // Get only invoice number

            if (confirm(`Are you sure you want to delete Invoice ${invoiceNo}?\nThis will restore the sold items back to stock.`)) {
                $.ajax({
                    url: `api_delete_sale.php?id=${invoiceId}`,
                    type: 'DELETE',
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            alert('Invoice deleted successfully.');
                            row.fadeOut(500, function() {
                                $(this).remove();
                            });
                        } else {
                            alert('Error: ' + response.error);
                        }
                    },
                    error: function() {
                        alert('An error occurred while trying to delete the invoice.');
                    }
                });
            }
        });
    });
    </script>
</body>
</html>