<?php
include '../includes/db.php';
header('Content-Type: application/json');

$purchase_id = isset($_GET['purchase_id']) ? (int)$_GET['purchase_id'] : 0;

if (!$purchase_id) {
    echo json_encode(['error' => 'Purchase ID is required.']);
    exit;
}

$sql = "SELECT id, imei1, imei2 FROM imei_table WHERE purchase_id = ? AND status = 'In Stock'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $purchase_id);
$stmt->execute();
$result = $stmt->get_result();
$imeis = [];
while ($row = $result->fetch_assoc()) {
    $imeis[] = [
        'id' => $row['id'],
        'text' => $row['imei1'] . ' / ' . $row['imei2']
    ];
}
echo json_encode($imeis);
$stmt->close();
$conn->close();
?>