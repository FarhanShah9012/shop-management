<?php
// File: /pos-system/pages/api_get_returnable_items.php
include '../includes/db.php';
header('Content-Type: application/json');

$invoice_id = isset($_GET['invoice_id']) ? (int)$_GET['invoice_id'] : 0;

if (!$invoice_id) {
    echo json_encode(['success' => false, 'error' => 'Invoice ID is required.']);
    exit;
}

try {
    // Select items that have not been returned yet
    $stmt_items = $conn->prepare("SELECT * FROM invoice_items WHERE invoice_id = ? AND status = 'Sold'");
    $stmt_items->bind_param("i", $invoice_id);
    $stmt_items->execute();
    $items_result = $stmt_items->get_result();
    
    $items = [];
    while ($item = $items_result->fetch_assoc()) {
        $stmt_imei = $conn->prepare("SELECT imei1, imei2 FROM imei_table WHERE invoice_item_id = ?");
        $stmt_imei->bind_param("i", $item['id']);
        $stmt_imei->execute();
        $imei_result = $stmt_imei->get_result();
        $item['imeis'] = [];
        while ($imei_row = $imei_result->fetch_assoc()) {
            $item['imeis'][] = $imei_row;
        }
        $stmt_imei->close();
        $items[] = $item;
    }
    $stmt_items->close();

    echo json_encode(['success' => true, 'items' => $items]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Database Error: ' . $e->getMessage()]);
}

$conn->close();
?>