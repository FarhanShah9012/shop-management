<?php
// File: /pos-system/pages/api_delete_sale.php
include '../includes/db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE' || !isset($_GET['id'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid request method or missing ID.']);
    exit;
}

$invoice_id = (int)$_GET['id'];
$conn->begin_transaction();

try {
    // 1. Get ONLY 'Sold' items associated with the invoice before deleting.
    // Returned items have already had their stock restored.
    $stmt_items = $conn->prepare("SELECT id, purchase_id, quantity FROM invoice_items WHERE invoice_id = ? AND status = 'Sold'");
    $stmt_items->bind_param("i", $invoice_id);
    $stmt_items->execute();
    $items_result = $stmt_items->get_result();
    $items_to_restore = [];
    while ($row = $items_result->fetch_assoc()) {
        $items_to_restore[] = $row;
    }
    $stmt_items->close();

    // 2. Loop through items to restore stock if there are any
    if (!empty($items_to_restore)) {
        foreach ($items_to_restore as $item) {
            // a. Restore quantity in the purchases table
            $stmt_purchase = $conn->prepare("UPDATE purchases SET quantity = quantity + ? WHERE id = ?");
            $stmt_purchase->bind_param("ii", $item['quantity'], $item['purchase_id']);
            $stmt_purchase->execute();
            $stmt_purchase->close();

            // b. Restore IMEI status in the imei_table
            $stmt_imei = $conn->prepare("UPDATE imei_table SET status = 'In Stock', invoice_item_id = NULL WHERE invoice_item_id = ?");
            $stmt_imei->bind_param("i", $item['id']);
            $stmt_imei->execute();
            $stmt_imei->close();
        }
    }
    
    // 3. Delete the invoice itself. This will cascade and delete all associated invoice_items and sales_returns.
    $stmt_del = $conn->prepare("DELETE FROM invoices WHERE id = ?");
    $stmt_del->bind_param("i", $invoice_id);
    $stmt_del->execute();
    
    if ($stmt_del->affected_rows === 0) {
        throw new Exception("Invoice with ID $invoice_id not found.");
    }
    $stmt_del->close();

    // 4. Commit the transaction
    $conn->commit();
    echo json_encode(['success' => true]);

} catch (mysqli_sql_exception $exception) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => 'Database transaction failed: ' . $exception->getMessage()]);
}

$conn->close();
?>