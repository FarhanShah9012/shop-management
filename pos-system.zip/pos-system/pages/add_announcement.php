<?php
include '../includes/db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['title']) || !isset($_POST['description'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid request.']);
    exit;
}

$title = trim($_POST['title']);
$description = trim($_POST['description']);

if (empty($title) || empty($description)) {
    echo json_encode(['success' => false, 'error' => 'Title and description cannot be empty.']);
    exit;
}

$stmt = $conn->prepare("INSERT INTO announcements (title, description) VALUES (?, ?)");
$stmt->bind_param("ss", $title, $description);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Announcement added successfully.']);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to add announcement.']);
}

$stmt->close();
$conn->close();
?>