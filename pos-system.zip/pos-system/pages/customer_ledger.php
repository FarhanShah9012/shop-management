<?php include '../includes/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Ledger</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <style>
        .select2-container--default .select2-selection--single { height: 42px; border: 1px solid #d1d5db; border-radius: 0.375rem; }
        .select2-container--default .select2-selection--single .select2-selection__rendered { line-height: 42px; padding-left: 1rem; }
        .select2-container--default .select2-selection--single .select2-selection__arrow { height: 40px; }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">
     <?php include '../includes/sidebar.php'; ?>
    <div class="ml-64 transition-all duration-300 ease-in-out p-6">
        <?php include '../includes/header.php'; ?>
        
        <!-- Header Section -->
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-3xl font-bold text-gray-900">Customer Ledger</h1>
            <button id="addCustomerBtn" class="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700 flex items-center">
                <i class="fas fa-plus mr-2"></i> Add Customer
            </button>
        </div>

        <!-- Filters & Search Section -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="lg:col-span-2">
                    <label for="customer_select" class="block text-sm font-medium text-gray-700 mb-1">Customer</label>
                    <select id="customer_select" class="w-full">
                        <option value="">Select a customer</option>
                    </select>
                </div>
                <div>
                    <label for="from_date" class="block text-sm font-medium text-gray-700 mb-1">From Date</label>
                    <input type="date" id="from_date" class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500">
                </div>
                <div>
                    <label for="to_date" class="block text-sm font-medium text-gray-700 mb-1">To Date</label>
                    <input type="date" id="to_date" class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500">
                </div>
            </div>
            <div class="flex justify-end space-x-3 mt-4">
                <button id="reset_filters" class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50">Reset</button>
                <button id="search_ledger" class="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700">Search</button>
            </div>
        </div>

        <!-- Customer Info Summary Card -->
        <div id="summary_card" class="bg-white rounded-lg shadow-md p-6 mb-8 hidden">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-y-4 gap-x-2">
                <div class="lg:col-span-2">
                    <h3 class="text-lg font-medium text-gray-900" id="summary_customer_name"></h3>
                    <p class="text-gray-600" id="summary_customer_phone"></p>
                    <div class="mt-2">
                        <button id="addDebitBtn" class="px-3 py-1 bg-red-500 text-white rounded text-xs font-semibold hover:bg-red-600"><i class="fas fa-minus-circle mr-1"></i> Add Debit</button>
                        <button id="addCreditBtn" class="px-3 py-1 bg-green-500 text-white rounded text-xs font-semibold hover:bg-green-600"><i class="fas fa-plus-circle mr-1"></i> Add Credit</button>
                    </div>
                </div>
                <div class="border-t pt-2 md:border-t-0 md:border-l md:pt-0 md:pl-4">
                    <p class="text-sm text-gray-500">Opening Balance</p>
                    <p class="text-lg font-semibold" id="summary_opening_balance">Rs. 0.00</p>
                </div>
                <div class="border-t pt-2 md:border-t-0 md:border-l md:pt-0 md:pl-4">
                    <p class="text-sm text-gray-500">Outstanding Balance</p>
                    <p class="text-lg font-semibold text-red-600" id="summary_outstanding_balance">Rs. 0.00</p>
                </div>
                <div class="border-t pt-2 md:border-t-0 md:border-l md:pt-0 md:pl-4">
                    <p class="text-sm text-gray-500">Total Sales</p>
                    <p class="text-lg font-semibold" id="summary_total_sales">Rs. 0.00</p>
                </div>
            </div>
        </div>

        <!-- Ledger Table -->
        <div id="ledger_table_container" class="bg-white rounded-lg shadow-md overflow-hidden hidden">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Debit</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Credit</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Balance</th>
                            <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="ledger_tbody" class="bg-white divide-y divide-gray-200">
                        <!-- Rows will be injected by JS -->
                    </tbody>
                </table>
            </div>
            <!-- Totals Footer -->
            <div class="bg-gray-50 px-6 py-4 border-t border-gray-200 text-right">
                <div class="grid grid-cols-3 gap-4 font-semibold">
                    <div>Total Debit: <span id="total_debit" class="text-red-600">Rs. 0.00</span></div>
                    <div>Total Credit: <span id="total_credit" class="text-green-600">Rs. 0.00</span></div>
                    <div>Closing Balance: <span id="closing_balance" class="text-blue-600">Rs. 0.00</span></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Customer Modal -->
    <div id="customerModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Add New Customer</h3>
            <form id="addCustomerForm">
                <div class="space-y-4">
                    <div>
                        <label for="customer_name" class="block text-sm font-medium">Name</label>
                        <input type="text" id="customer_name" name="name" class="mt-1 w-full p-2 border rounded" required>
                    </div>
                    <div>
                        <label for="customer_phone" class="block text-sm font-medium">Phone</label>
                        <input type="tel" id="customer_phone" name="phone" class="mt-1 w-full p-2 border rounded" required>
                    </div>
                </div>
                <div class="mt-6 flex justify-end space-x-2">
                    <button type="button" class="close-modal px-4 py-2 bg-gray-300 rounded">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Ledger Entry Modal -->
    <div id="ledgerEntryModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <h3 class="text-lg font-medium text-gray-900 mb-4" id="ledgerModalTitle">Add Entry</h3>
            <form id="addLedgerEntryForm">
                <input type="hidden" name="customer_id" id="ledger_customer_id">
                <input type="hidden" name="type" id="ledger_type">
                <div class="space-y-4">
                    <div>
                        <label for="ledger_date" class="block text-sm font-medium">Date</label>
                        <input type="date" id="ledger_date" name="date" class="mt-1 w-full p-2 border rounded" required>
                    </div>
                    <div>
                        <label for="ledger_description" class="block text-sm font-medium">Description</label>
                        <input type="text" id="ledger_description" name="description" class="mt-1 w-full p-2 border rounded" value="Manual Payment" required>
                    </div>
                    <div>
                        <label for="ledger_amount" class="block text-sm font-medium">Amount</label>
                        <input type="number" step="0.01" id="ledger_amount" name="amount" class="mt-1 w-full p-2 border rounded" required>
                    </div>
                </div>
                <div class="mt-6 flex justify-end space-x-2">
                    <button type="button" class="close-modal px-4 py-2 bg-gray-300 rounded">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Save Entry</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    $(document).ready(function() {
        const formatCurrency = (val) => `Rs. ${parseFloat(val || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

        $('#customer_select').select2({
            placeholder: 'Search for a customer by name or phone',
            width: '100%'
        });

        function loadCustomers() {
            $.getJSON('api_get_customers.php', function(data) {
                const customerSelect = $('#customer_select');
                customerSelect.empty().append('<option value="">Select a customer</option>');
                data.forEach(cust => {
                    customerSelect.append(new Option(`${cust.name} - ${cust.phone}`, cust.id, false, false));
                });
                customerSelect.trigger('change');
            });
        }

        function loadLedger() {
            const customerId = $('#customer_select').val();
            if (!customerId) {
                $('#summary_card, #ledger_table_container').addClass('hidden');
                return;
            }

            const fromDate = $('#from_date').val();
            const toDate = $('#to_date').val();

            $.getJSON(`api_get_customer_ledger.php?customer_id=${customerId}&from_date=${fromDate}&to_date=${toDate}`, function(response) {
                if (response.success) {
                    const summary = response.summary;
                    $('#summary_customer_name').text(summary.customer_info.name);
                    $('#summary_customer_phone').text(summary.customer_info.phone);
                    $('#summary_opening_balance').text(formatCurrency(summary.opening_balance));
                    $('#summary_outstanding_balance').text(formatCurrency(summary.outstanding_balance));
                    $('#summary_total_sales').text(formatCurrency(summary.total_sales));
                    $('#summary_card').removeClass('hidden');

                    const tbody = $('#ledger_tbody');
                    tbody.empty();
                    response.transactions.forEach(tx => {
                        let actionsHtml = '-';
                        if (tx.debit > 0) { // Any transaction that debits the account can be paid against.
                            const escapedDesc = $('<textarea />').html(tx.description).text();
                            actionsHtml = `<button class="add-credit-row-btn text-green-600 hover:text-green-800 text-xs font-semibold" data-ref-desc="${escapedDesc}">Add Credit</button>`;
                        }

                        const row = `
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700">${tx.transaction_date}</td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700">${tx.description}</td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-red-600 text-right">${tx.debit > 0 ? formatCurrency(tx.debit) : '-'}</td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-green-600 text-right">${tx.credit > 0 ? formatCurrency(tx.credit) : '-'}</td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-semibold text-blue-700 text-right">${formatCurrency(tx.running_balance)}</td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-center">${actionsHtml}</td>
                            </tr>
                        `;
                        tbody.append(row);
                    });
                    
                    $('#total_debit').text(formatCurrency(response.totals.total_debit));
                    $('#total_credit').text(formatCurrency(response.totals.total_credit));
                    $('#closing_balance').text(formatCurrency(response.totals.closing_balance));
                    $('#ledger_table_container').removeClass('hidden');
                } else {
                    alert('Error: ' + response.error);
                }
            });
        }

        // Event Handlers
        $('#addCustomerBtn').on('click', () => $('#customerModal').removeClass('hidden'));
        $('#addDebitBtn').on('click', () => {
            $('#ledgerModalTitle').text('Add Debit Entry');
            $('#ledger_type').val('debit');
            $('#ledger_customer_id').val($('#customer_select').val());
            $('#ledger_date').val(new Date().toISOString().split('T')[0]);
            $('#ledgerEntryModal').removeClass('hidden');
        });
        $('#addCreditBtn').on('click', () => {
            $('#ledgerModalTitle').text('Add Credit Entry');
            $('#ledger_type').val('credit');
            $('#ledger_customer_id').val($('#customer_select').val());
            $('#ledger_date').val(new Date().toISOString().split('T')[0]);
            $('#ledgerEntryModal').removeClass('hidden');
        });

        $('#ledger_tbody').on('click', '.add-credit-row-btn', function() {
            const refDesc = $(this).data('ref-desc');
            $('#ledgerModalTitle').text('Add Credit Entry');
            $('#ledger_type').val('credit');
            $('#ledger_customer_id').val($('#customer_select').val());
            $('#ledger_date').val(new Date().toISOString().split('T')[0]);
            $('#ledger_description').val(`Payment for ${refDesc}`);
            $('#ledgerEntryModal').removeClass('hidden');
            $('#ledger_amount').focus();
        });

        $('.close-modal').on('click', () => {
            $('#customerModal, #ledgerEntryModal').addClass('hidden');
            $('#addCustomerForm, #addLedgerEntryForm')[0].reset();
        });

        $('#addCustomerForm').on('submit', function(e) {
            e.preventDefault();
            $.ajax({ url: 'api_add_customer.php', type: 'POST', data: $(this).serialize(), dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        alert(response.message);
                        $('.close-modal').click();
                        loadCustomers();
                        setTimeout(() => $('#customer_select').val(response.customer.id).trigger('change'), 500);
                    } else { alert('Error: ' + response.error); }
                }
            });
        });
        
        $('#addLedgerEntryForm').on('submit', function(e) {
            e.preventDefault();
            $.ajax({ url: 'api_add_ledger_entry.php', type: 'POST', data: $(this).serialize(), dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        alert(response.message);
                        $('.close-modal').click();
                        loadLedger();
                    } else { alert('Error: ' + response.error); }
                }
            });
        });

        $('#search_ledger').on('click', loadLedger);
        $('#customer_select').on('change', loadLedger);
        $('#reset_filters').on('click', function() {
            $('#from_date, #to_date').val('');
            loadLedger();
        });

        loadCustomers();
    });
    </script>
</body>
</html>