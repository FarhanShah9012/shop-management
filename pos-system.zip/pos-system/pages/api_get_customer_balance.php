<?php
// File: /pos-system/pages/api_get_customer_balance.php
include '../includes/db.php';
header('Content-Type: application/json');

$phone = trim($_GET['phone'] ?? '');

if (empty($phone)) {
    echo json_encode(['success' => false, 'error' => 'Phone number is required.']);
    exit;
}

// Find customer by phone
$stmt_customer = $conn->prepare("SELECT id FROM customers WHERE phone = ?");
$stmt_customer->bind_param("s", $phone);
$stmt_customer->execute();
$customer_result = $stmt_customer->get_result();

if ($customer_result->num_rows === 0) {
    echo json_encode(['success' => true, 'balance' => 0, 'message' => 'New customer.']);
    exit;
}

$customer = $customer_result->fetch_assoc();
$customer_id = $customer['id'];
$stmt_customer->close();

// Calculate current balance
$stmt_balance = $conn->prepare("SELECT (SUM(debit) - SUM(credit)) as balance FROM customer_ledger WHERE customer_id = ?");
$stmt_balance->bind_param("i", $customer_id);
$stmt_balance->execute();
$balance_result = $stmt_balance->get_result()->fetch_assoc();
$stmt_balance->close();

$balance = $balance_result['balance'] ?? 0;

echo json_encode(['success' => true, 'balance' => $balance]);

$conn->close();
?>