<?php
// pos-system/acc-pages/purchase.php

// The database connection file is expected at ../includes/db.php
require_once '../includes/db.php';

// --- API ENDPOINT LOGIC ---
// Handles all AJAX requests for Create, Read (single item), Update, Delete
if (isset($_REQUEST['action'])) {
    header('Content-Type: application/json');
    $response = ['status' => 'error', 'message' => 'An unknown error occurred.'];

    switch ($_REQUEST['action']) {
        case 'add_purchase':
            $stmt = $conn->prepare("INSERT INTO accessory_purchases (product_name, purchase_date, quantity, purchase_price, sale_price, supplier_name, supplier_phone, supplier_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssiddsss", $_POST['product_name'], $_POST['purchase_date'], $_POST['quantity'], $_POST['purchase_price'], $_POST['sale_price'], $_POST['supplier_name'], $_POST['supplier_phone'], $_POST['supplier_address']);
            if ($stmt->execute()) {
                $response = ['status' => 'success', 'message' => 'Item added successfully.'];
            } else {
                $response['message'] = 'Database Error: ' . $stmt->error;
            }
            $stmt->close();
            break;

        case 'get_purchase':
            if (isset($_GET['id'])) {
                $id = intval($_GET['id']);
                $stmt = $conn->prepare("SELECT * FROM accessory_purchases WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($purchase = $result->fetch_assoc()) {
                    $response = ['status' => 'success', 'data' => $purchase];
                } else {
                    $response['message'] = 'Purchase record not found.';
                }
                $stmt->close();
            } else {
                $response['message'] = 'No ID provided.';
            }
            break;

        case 'update_purchase':
            $id = intval($_POST['id']);
            $new_stock = intval($_POST['new_stock']);

            // First, get the current quantity
            $stmt_get = $conn->prepare("SELECT quantity FROM accessory_purchases WHERE id = ?");
            $stmt_get->bind_param("i", $id);
            $stmt_get->execute();
            $current_data = $stmt_get->get_result()->fetch_assoc();
            $stmt_get->close();

            if ($current_data) {
                $new_quantity = $current_data['quantity'] + $new_stock;

                $stmt_update = $conn->prepare("UPDATE accessory_purchases SET product_name = ?, purchase_date = ?, quantity = ?, purchase_price = ?, sale_price = ?, supplier_name = ?, supplier_phone = ?, supplier_address = ? WHERE id = ?");
                $stmt_update->bind_param("ssiddsssi", $_POST['product_name'], $_POST['purchase_date'], $new_quantity, $_POST['purchase_price'], $_POST['sale_price'], $_POST['supplier_name'], $_POST['supplier_phone'], $_POST['supplier_address'], $id);
                
                if ($stmt_update->execute()) {
                    $response = ['status' => 'success', 'message' => 'Item updated successfully.'];
                } else {
                    $response['message'] = 'Database Error: ' . $stmt_update->error;
                }
                $stmt_update->close();
            } else {
                $response['message'] = 'Item not found for update.';
            }
            break;

        case 'delete_purchase':
            if (isset($_POST['id'])) {
                $id = intval($_POST['id']);
                $stmt = $conn->prepare("DELETE FROM accessory_purchases WHERE id = ?");
                $stmt->bind_param("i", $id);
                if ($stmt->execute()) {
                    $response = ['status' => 'success', 'message' => 'Item deleted successfully.'];
                } else {
                    $response['message'] = 'Database Error: ' . $stmt->error;
                }
                $stmt->close();
            } else {
                $response['message'] = 'No ID provided.';
            }
            break;

        default:
            $response['message'] = 'Invalid action specified.';
            break;
    }

    echo json_encode($response);
    $conn->close();
    exit; // Stop script execution after handling AJAX
}

// --- PAGE DISPLAY & DATA FETCHING LOGIC ---
// Pagination
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 5;
$offset = ($page - 1) * $records_per_page;

// Search and Filter
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
$from_date = isset($_GET['from_date']) && !empty($_GET['from_date']) ? $_GET['from_date'] : '';
$to_date = isset($_GET['to_date']) && !empty($_GET['to_date']) ? $_GET['to_date'] : '';

// Build WHERE clause for filtering
$where_conditions = [];
$params = [];
$types = '';

if ($search_term !== '') {
    $where_conditions[] = "(product_name LIKE ? OR supplier_name LIKE ? OR supplier_phone LIKE ? OR supplier_address LIKE ?)";
    $like_search_term = "%{$search_term}%";
    array_push($params, $like_search_term, $like_search_term, $like_search_term, $like_search_term);
    $types .= 'ssss';
}
if ($from_date !== '') {
    $where_conditions[] = "purchase_date >= ?";
    $params[] = $from_date;
    $types .= 's';
}
if ($to_date !== '') {
    $where_conditions[] = "purchase_date <= ?";
    $params[] = $to_date;
    $types .= 's';
}

$where_sql = '';
if (count($where_conditions) > 0) {
    $where_sql = 'WHERE ' . implode(' AND ', $where_conditions);
}

// Get total number of records for pagination
$total_query = "SELECT COUNT(*) as total FROM accessory_purchases {$where_sql}";
$stmt_total = $conn->prepare($total_query);
if ($types) {
    $stmt_total->bind_param($types, ...$params);
}
$stmt_total->execute();
$total_records = $stmt_total->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_records / $records_per_page);
$stmt_total->close();

// Fetch records for the current page
$query = "SELECT * FROM accessory_purchases {$where_sql} ORDER BY purchase_date DESC, id DESC LIMIT ? OFFSET ?";
$page_types = $types . 'ii';
$page_params = $params;
array_push($page_params, $records_per_page, $offset);

$stmt = $conn->prepare($query);
if ($page_types) {
    $stmt->bind_param($page_types, ...$page_params);
}
$stmt->execute();
$result = $stmt->get_result();
$purchases = [];
while ($row = $result->fetch_assoc()) {
    $purchases[] = $row;
}
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accessories Purchase</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 min-h-screen">
    <?php include '../includes/sidebar.php'; ?>

    <div class="ml-64 transition-all duration-300 ease-in-out">
        <main class="p-8">
            <!-- Header Section -->
            <div class="mb-8">
                <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <h1 class="text-3xl font-bold text-gray-900">Accessories Purchase</h1>
                    <button id="addNewItemBtn" class="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700 flex items-center justify-center">
                        <i class="fas fa-plus mr-2"></i> Add New Item
                    </button>
                </div>
                
                <!-- Search and Date Filters Form -->
                <form method="GET" action="purchase.php" class="mt-6 bg-white rounded-lg shadow-md p-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
                        <div class="lg:col-span-2">
                            <label for="search" class="block text-sm font-medium text-gray-700 mb-1">Search</label>
                            <div class="relative">
                                <input 
                                    type="text" 
                                    name="search"
                                    id="search"
                                    placeholder="Search by Product, Supplier, Phone..." 
                                    class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                                    value="<?= htmlspecialchars($search_term) ?>"
                                >
                                <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                    <i class="fas fa-search text-gray-400"></i>
                                </div>
                            </div>
                        </div>
                        <div>
                            <label for="from_date" class="block text-sm font-medium text-gray-700 mb-1">From Date</label>
                            <input type="date" name="from_date" id="from_date" class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" value="<?= htmlspecialchars($from_date) ?>">
                        </div>
                        <div>
                            <label for="to_date" class="block text-sm font-medium text-gray-700 mb-1">To Date</label>
                            <input type="date" name="to_date" id="to_date" class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" value="<?= htmlspecialchars($to_date) ?>">
                        </div>
                    </div>
                    <div class="mt-4 flex justify-end gap-3">
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700 flex items-center justify-center">
                            <i class="fas fa-filter mr-2"></i> Apply Filters
                        </button>
                        <a href="purchase.php" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-md text-sm font-medium hover:bg-gray-300">
                            Reset Filters
                        </a>
                    </div>
                </form>
            </div>

            <!-- Table Section -->
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product Name</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Purchase Price</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sale Price</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Supplier</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php if (count($purchases) > 0): ?>
                                <?php foreach ($purchases as $purchase): ?>
                                    <tr id="row-<?= $purchase['id'] ?>">
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?= htmlspecialchars($purchase['product_name']) ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?= date("M d, Y", strtotime($purchase['purchase_date'])) ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?= htmlspecialchars($purchase['quantity']) ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">Rs. <?= number_format($purchase['purchase_price'], 2) ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">Rs. <?= number_format($purchase['sale_price'], 2) ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="p-2 rounded-md bg-gray-50 border max-w-xs">
                                                <div class="text-sm font-medium text-gray-900"><?= htmlspecialchars($purchase['supplier_name']) ?></div>
                                                <div class="text-xs text-gray-600 mt-1">
                                                    <i class="fas fa-phone-alt fa-fw mr-1"></i>
                                                    <?= htmlspecialchars($purchase['supplier_phone'] ?: 'N/A') ?>
                                                </div>
                                                <div class="text-xs text-gray-600 mt-1">
                                                    <i class="fas fa-map-marker-alt fa-fw mr-1"></i>
                                                    <?= htmlspecialchars($purchase['supplier_address'] ?: 'N/A') ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                            <div class="flex space-x-3">
                                                <button onclick="openEditModal(<?= $purchase['id'] ?>)" class="text-blue-600 hover:text-blue-900" title="Edit"><i class="fas fa-edit"></i></button>
                                                <button onclick="deletePurchase(<?= $purchase['id'] ?>)" class="text-red-600 hover:text-red-900" title="Delete"><i class="fas fa-trash"></i></button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="px-6 py-4 text-center text-gray-500">No purchase records found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <div class="bg-white px-4 py-3 border-t border-gray-200 sm:px-6 flex flex-col sm:flex-row items-center justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-700">
                            Showing <span class="font-medium"><?= $offset + 1 ?></span> to <span class="font-medium"><?= min($offset + $records_per_page, $total_records) ?></span> of
                            <span class="font-medium"><?= $total_records ?></span> results
                        </p>
                    </div>
                    <div class="flex space-x-2">
                        <?php
                            // Preserve existing query string parameters
                            $query_params = $_GET;
                        ?>
                        <a href="?<?php $query_params['page'] = $page - 1; echo http_build_query($query_params); ?>" class="<?= $page <= 1 ? 'pointer-events-none opacity-50' : '' ?> px-3 py-1 rounded-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                            Previous
                        </a>
                        <a href="?<?php $query_params['page'] = $page + 1; echo http_build_query($query_params); ?>" class="<?= $page >= $total_pages ? 'pointer-events-none opacity-50' : '' ?> px-3 py-1 rounded-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                            Next
                        </a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Add/Edit Modal -->
    <div id="purchaseModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
        <div class="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
            <div class="flex justify-between items-center border-b pb-3">
                <h3 class="text-2xl font-bold text-gray-900" id="modalTitle">Add New Item</h3>
                <button id="closeModalBtn" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times fa-lg"></i>
                </button>
            </div>
            <div class="mt-5">
                <form id="purchaseForm">
                    <input type="hidden" name="action" id="formAction">
                    <input type="hidden" name="id" id="purchaseId">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Product Information -->
                        <div class="md:col-span-2">
                            <h4 class="text-lg font-semibold text-gray-700 mb-2 border-b">Product Details</h4>
                        </div>
                        <div>
                            <label for="product_name" class="block text-sm font-medium text-gray-700">Product Name</label>
                            <input type="text" name="product_name" id="product_name" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        <div>
                            <label for="purchase_date" class="block text-sm font-medium text-gray-700">Purchase Date</label>
                            <input type="date" name="purchase_date" id="purchase_date" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        <div>
                            <label for="quantity" class="block text-sm font-medium text-gray-700">Quantity</label>
                            <input type="number" name="quantity" id="quantity" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" min="0">
                        </div>
                        <div id="newStockContainer" class="hidden">
                            <label for="new_stock" class="block text-sm font-medium text-gray-700">Add New Stock</label>
                            <input type="number" name="new_stock" id="new_stock" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" value="0" min="0">
                        </div>
                        <div>
                            <label for="purchase_price" class="block text-sm font-medium text-gray-700">Purchase Price (Rs.)</label>
                            <input type="number" step="0.01" name="purchase_price" id="purchase_price" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" min="0">
                        </div>
                        <div>
                            <label for="sale_price" class="block text-sm font-medium text-gray-700">Sale Price (Rs.)</label>
                            <input type="number" step="0.01" name="sale_price" id="sale_price" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" min="0">
                        </div>
                        
                        <!-- Supplier Information -->
                        <div class="md:col-span-2">
                             <h4 class="text-lg font-semibold text-gray-700 mt-4 mb-2 border-b">Supplier Details</h4>
                        </div>
                        <div>
                            <label for="supplier_name" class="block text-sm font-medium text-gray-700">Supplier Name</label>
                            <input type="text" name="supplier_name" id="supplier_name" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        <div>
                            <label for="supplier_phone" class="block text-sm font-medium text-gray-700">Supplier Phone</label>
                            <input type="tel" name="supplier_phone" id="supplier_phone" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        <div class="md:col-span-2">
                            <label for="supplier_address" class="block text-sm font-medium text-gray-700">Supplier Address</label>
                            <textarea name="supplier_address" id="supplier_address" rows="3" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"></textarea>
                        </div>
                    </div>
                    <div class="mt-6 flex justify-end gap-4">
                        <button type="button" id="cancelModalBtn" class="px-6 py-2 bg-gray-200 text-gray-700 rounded-md text-sm font-medium hover:bg-gray-300">Cancel</button>
                        <button type="submit" id="saveBtn" class="px-6 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const modal = document.getElementById('purchaseModal');
            const addNewItemBtn = document.getElementById('addNewItemBtn');
            const closeModalBtn = document.getElementById('closeModalBtn');
            const cancelModalBtn = document.getElementById('cancelModalBtn');
            const purchaseForm = document.getElementById('purchaseForm');
            const modalTitle = document.getElementById('modalTitle');
            const formAction = document.getElementById('formAction');
            const purchaseId = document.getElementById('purchaseId');
            const quantityInput = document.getElementById('quantity');
            const newStockContainer = document.getElementById('newStockContainer');
            const newStockInput = document.getElementById('new_stock');
            const saveBtn = document.getElementById('saveBtn');

            function openModal() { modal.classList.remove('hidden'); }
            function closeModal() { modal.classList.add('hidden'); }

            addNewItemBtn.addEventListener('click', () => {
                purchaseForm.reset();
                modalTitle.textContent = 'Add New Item';
                saveBtn.textContent = 'Save';
                formAction.value = 'add_purchase';
                purchaseId.value = '';
                quantityInput.disabled = false;
                newStockContainer.classList.add('hidden');
                openModal();
            });

            closeModalBtn.addEventListener('click', closeModal);
            cancelModalBtn.addEventListener('click', closeModal);

            window.openEditModal = async (id) => {
                purchaseForm.reset();
                const response = await fetch(`?action=get_purchase&id=${id}`);
                const result = await response.json();

                if (result.status === 'success' && result.data) {
                    const data = result.data;
                    modalTitle.textContent = 'Edit Item';
                    saveBtn.textContent = 'Update';
                    formAction.value = 'update_purchase';
                    purchaseId.value = data.id;

                    document.getElementById('product_name').value = data.product_name;
                    document.getElementById('purchase_date').value = data.purchase_date;
                    quantityInput.value = data.quantity;
                    quantityInput.disabled = true; // Original quantity is not directly editable
                    document.getElementById('purchase_price').value = data.purchase_price;
                    document.getElementById('sale_price').value = data.sale_price;
                    document.getElementById('supplier_name').value = data.supplier_name;
                    document.getElementById('supplier_phone').value = data.supplier_phone;
                    document.getElementById('supplier_address').value = data.supplier_address;
                    
                    newStockInput.value = 0;
                    newStockContainer.classList.remove('hidden');

                    openModal();
                } else {
                    alert('Error: Could not fetch item data.');
                }
            };

            window.deletePurchase = async (id) => {
                if (!confirm('Are you sure you want to delete this item?')) {
                    return;
                }
                const formData = new FormData();
                formData.append('action', 'delete_purchase');
                formData.append('id', id);

                const response = await fetch('purchase.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();

                if (result.status === 'success') {
                    alert(result.message);
                    location.reload(); // Reload to show updated table
                } else {
                    alert('Error: ' + result.message);
                }
            };
            
            purchaseForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                const formData = new FormData(purchaseForm);
                if(quantityInput.disabled) {
                    formData.append('quantity', quantityInput.value);
                }

                const response = await fetch('purchase.php', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();
                if (result.status === 'success') {
                    alert(result.message);
                    closeModal();
                    location.reload(); // Reload page to reflect changes
                } else {
                    alert('Error: ' + result.message);
                }
            });
        });
    </script>
</body>
</html>