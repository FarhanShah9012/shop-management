<?php
// pos-system/acc-pages/acc-manage-sales.php
require_once '../includes/db.php';

// --- API ENDPOINT LOGIC ---
// Handles all AJAX requests for deleting or fetching an invoice for printing.
if (isset($_REQUEST['action'])) {
    header('Content-Type: application/json');
    $response = ['status' => 'error', 'message' => 'An unknown error occurred.'];

    switch ($_REQUEST['action']) {
        
        case 'delete_invoice':
            if (isset($_POST['id'])) {
                $invoice_id = intval($_POST['id']);
                
                $conn->begin_transaction();
                try {
                    // 1. Get all items from the invoice to restore stock
                    $stmt_get_items = $conn->prepare("SELECT product_id, quantity FROM sales_items WHERE sales_invoice_id = ?");
                    $stmt_get_items->bind_param("i", $invoice_id);
                    $stmt_get_items->execute();
                    $items_result = $stmt_get_items->get_result();
                    $items_to_restore = $items_result->fetch_all(MYSQLI_ASSOC);
                    $stmt_get_items->close();

                    // 2. Restore stock for each item
                    $stmt_restore_stock = $conn->prepare("UPDATE accessory_purchases SET quantity = quantity + ? WHERE id = ?");
                    foreach ($items_to_restore as $item) {
                        $stmt_restore_stock->bind_param("ii", $item['quantity'], $item['product_id']);
                        $stmt_restore_stock->execute();
                    }
                    $stmt_restore_stock->close();

                    // 3. Delete the invoice (ON DELETE CASCADE will handle sales_items)
                    $stmt_delete_invoice = $conn->prepare("DELETE FROM sales_invoices WHERE id = ?");
                    $stmt_delete_invoice->bind_param("i", $invoice_id);
                    $stmt_delete_invoice->execute();
                    $stmt_delete_invoice->close();
                    
                    $conn->commit();
                    $response = ['status' => 'success', 'message' => 'Invoice deleted and stock restored successfully.'];
                } catch (Exception $e) {
                    $conn->rollback();
                    $response['message'] = 'Transaction Failed: ' . $e->getMessage();
                }
            } else {
                $response['message'] = 'No Invoice ID provided.';
            }
            break;

        case 'get_invoice_for_print':
             if (isset($_GET['id'])) {
                $invoice_id = intval($_GET['id']);
                
                // Fetch main invoice data
                $stmt_inv = $conn->prepare("SELECT * FROM sales_invoices WHERE id = ?");
                $stmt_inv->bind_param("i", $invoice_id);
                $stmt_inv->execute();
                $invoice_data = $stmt_inv->get_result()->fetch_assoc();
                $stmt_inv->close();

                if ($invoice_data) {
                    // Fetch invoice items
                    $stmt_items = $conn->prepare("SELECT product_name, quantity, price, total FROM sales_items WHERE sales_invoice_id = ?");
                    $stmt_items->bind_param("i", $invoice_id);
                    $stmt_items->execute();
                    $items_result = $stmt_items->get_result();
                    $invoice_items = $items_result->fetch_all(MYSQLI_ASSOC);
                    $stmt_items->close();

                    // Reconstruct the data object to match what acc-invoice.php expects
                    $print_data = [
                        'customer_name'  => $invoice_data['customer_name'],
                        'customer_phone' => $invoice_data['customer_phone'],
                        'invoice_date'   => $invoice_data['invoice_date'],
                        'invoice_number' => $invoice_data['invoice_number'],
                        'items'          => [],
                        'summary'        => [
                            'invoice_amount'   => (float) $invoice_data['invoice_amount'],
                            'previous_balance' => (float) $invoice_data['previous_balance'],
                            'grand_total'      => (float) $invoice_data['grand_total'],
                            'received_amount'  => (float) $invoice_data['received_amount'],
                            'remaining_amount' => (float) $invoice_data['remaining_amount']
                        ]
                    ];
                    foreach ($invoice_items as $item) {
                        $print_data['items'][] = [
                            'name'  => $item['product_name'],
                            'qty'   => (int) $item['quantity'],
                            'price' => (float) $item['price'],
                            'total' => (float) $item['total']
                        ];
                    }
                    $response = ['status' => 'success', 'data' => $print_data];
                } else {
                    $response['message'] = 'Invoice not found.';
                }
            } else {
                $response['message'] = 'No ID provided.';
            }
            break;

        default:
            $response['message'] = 'Invalid action specified.';
            break;
    }

    echo json_encode($response);
    $conn->close();
    exit;
}

// --- PAGE DISPLAY & DATA FETCHING LOGIC ---
$records_per_page = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $records_per_page;

// Filters
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
$from_date = isset($_GET['from_date']) && !empty($_GET['from_date']) ? $_GET['from_date'] : '';
$to_date = isset($_GET['to_date']) && !empty($_GET['to_date']) ? $_GET['to_date'] : '';

$where_conditions = [];
$params = [];
$types = '';

if ($search_term !== '') {
    $where_conditions[] = "(invoice_number LIKE ? OR customer_name LIKE ? OR customer_phone LIKE ?)";
    $like_search_term = "%{$search_term}%";
    array_push($params, $like_search_term, $like_search_term, $like_search_term);
    $types .= 'sss';
}
if ($from_date !== '') {
    $where_conditions[] = "invoice_date >= ?";
    $params[] = $from_date;
    $types .= 's';
}
if ($to_date !== '') {
    $where_conditions[] = "invoice_date <= ?";
    $params[] = $to_date;
    $types .= 's';
}

$where_sql = count($where_conditions) > 0 ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get total records for pagination
$total_query = "SELECT COUNT(*) as total FROM sales_invoices {$where_sql}";
$stmt_total = $conn->prepare($total_query);
if ($types) $stmt_total->bind_param($types, ...$params);
$stmt_total->execute();
$total_records = $stmt_total->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_records / $records_per_page);
$stmt_total->close();

// Fetch records for the current page
// MODIFIED: Added `return_status` to the SELECT query
$query = "SELECT id, invoice_number, invoice_date, customer_name, customer_phone, grand_total, return_status FROM sales_invoices {$where_sql} ORDER BY invoice_date DESC, id DESC LIMIT ? OFFSET ?";
$page_types = $types . 'ii';
$page_params = $params;
array_push($page_params, $records_per_page, $offset);

$stmt = $conn->prepare($query);
if ($page_types) $stmt->bind_param($page_types, ...$page_params);
$stmt->execute();
$result = $stmt->get_result();
$invoices = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Sales Invoices</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 min-h-screen">
    <?php include '../includes/sidebar.php'; ?>

    <div class="ml-64 transition-all duration-300 ease-in-out">
        <main class="p-8">
            <h1 class="text-3xl font-bold text-gray-900 mb-8">Manage Sales Invoices</h1>

            <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                <form action="acc-manage-sales.php" method="GET" class="space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
                        <div class="lg:col-span-2">
                            <label for="search" class="block text-sm font-medium text-gray-700">Search</label>
                            <div class="mt-1 relative">
                                <input type="text" id="search" name="search" placeholder="Search by Invoice #, Customer, or Phone..." class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" value="<?= htmlspecialchars($search_term) ?>">
                                <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><i class="fas fa-search text-gray-400"></i></div>
                            </div>
                        </div>
                        <div>
                            <label for="from_date" class="block text-sm font-medium text-gray-700">From Date</label>
                            <input type="date" name="from_date" id="from_date" class="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" value="<?= htmlspecialchars($from_date) ?>">
                        </div>
                        <div>
                            <label for="to_date" class="block text-sm font-medium text-gray-700">To Date</label>
                            <input type="date" name="to_date" id="to_date" class="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" value="<?= htmlspecialchars($to_date) ?>">
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 pt-2">
                        <a href="acc-manage-sales.php" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-md text-sm font-medium hover:bg-gray-300">Reset</a>
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700 flex items-center"><i class="fas fa-filter mr-2"></i>Filter</button>
                    </div>
                </form>
            </div>

            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Invoice No</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Amount</th>
                                <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php if (count($invoices) > 0): ?>
                                <?php foreach ($invoices as $invoice): ?>
                                    <tr>
                                        <!-- MODIFIED: Added badges to show return status -->
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                            <span class="text-blue-600"><?= htmlspecialchars($invoice['invoice_number']) ?></span>
                                            <?php if ($invoice['return_status'] === 'Partial'): ?>
                                                <span class="ml-2 text-xs bg-yellow-100 text-yellow-800 font-medium px-2 py-0.5 rounded-full">Partially Returned</span>
                                            <?php elseif ($invoice['return_status'] === 'Full'): ?>
                                                <span class="ml-2 text-xs bg-red-100 text-red-800 font-medium px-2 py-0.5 rounded-full">Fully Returned</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?= date("M d, Y", strtotime($invoice['invoice_date'])) ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm font-medium text-gray-900"><?= htmlspecialchars($invoice['customer_name']) ?></div>
                                            <div class="text-xs text-gray-500"><?= htmlspecialchars($invoice['customer_phone'] ?: 'N/A') ?></div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Rs. <?= number_format($invoice['grand_total'], 2) ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
                                            <div class="flex justify-center space-x-4">
                                                <button onclick="printInvoice(<?= $invoice['id'] ?>)" class="text-indigo-600 hover:text-indigo-900" title="Print Invoice">
                                                    <i class="fas fa-print fa-lg"></i>
                                                </button>
                                                <button onclick="deleteInvoice(<?= $invoice['id'] ?>)" class="text-red-600 hover:text-red-900" title="Delete Invoice">
                                                    <i class="fas fa-trash fa-lg"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="px-6 py-10 text-center text-gray-500">
                                        <i class="fas fa-file-invoice-dollar fa-3x text-gray-300"></i>
                                        <p class="mt-2">No sales records found.</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($total_pages > 1): ?>
                <div class="bg-white px-4 py-3 border-t border-gray-200 sm:px-6 flex flex-col sm:flex-row items-center justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-700">
                            Showing <span class="font-medium"><?= $offset + 1 ?></span> to <span class="font-medium"><?= min($offset + $records_per_page, $total_records) ?></span> of
                            <span class="font-medium"><?= $total_records ?></span> results
                        </p>
                    </div>
                    <div class="flex space-x-2">
                        <?php $query_params = $_GET; ?>
                        <a href="?<?php $query_params['page'] = $page - 1; echo http_build_query($query_params); ?>" class="<?= $page <= 1 ? 'pointer-events-none opacity-50' : '' ?> px-3 py-1 rounded-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">Previous</a>
                        <a href="?<?php $query_params['page'] = $page + 1; echo http_build_query($query_params); ?>" class="<?= $page >= $total_pages ? 'pointer-events-none opacity-50' : '' ?> px-3 py-1 rounded-md border border-gray-300 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">Next</a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

<script>
    async function deleteInvoice(id) {
        if (!confirm('Are you sure you want to delete this invoice? This will restore the sold item quantities to the stock. This action cannot be undone.')) {
            return;
        }

        const formData = new FormData();
        formData.append('action', 'delete_invoice');
        formData.append('id', id);

        try {
            const response = await fetch('acc-manage-sales.php', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            if (result.status === 'success') {
                alert(result.message);
                location.reload();
            } else {
                alert('Error: ' + result.message);
            }
        } catch (error) {
            alert('An error occurred while communicating with the server.');
        }
    }

    async function printInvoice(id) {
        try {
            const response = await fetch(`acc-manage-sales.php?action=get_invoice_for_print&id=${id}`);
            const result = await response.json();

            if (result.status === 'success') {
                // Store data in sessionStorage for the invoice page to access
                sessionStorage.setItem('invoiceData', JSON.stringify(result.data));
                // Redirect to the invoice page
                window.open('acc-invoice.php', '_blank');
            } else {
                alert('Error: ' + result.message);
            }
        } catch (error) {
            alert('An error occurred while fetching invoice data.');
        }
    }
</script>

</body>
</html>