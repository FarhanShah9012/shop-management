<?php
// pos-system/acc-pages/acc-return.php
require_once '../includes/db.php';

// --- HELPER FUNCTION TO RENDER TABLE AND PAGINATION ---
function render_invoice_table_and_pagination($invoices, $total_pages, $page, $offset, $records_per_page, $total_records) {
    // Render Table Body
    ob_start();
    if (count($invoices) > 0) {
        foreach ($invoices as $invoice) { ?>
            <tr>
                <td class="px-6 py-4 whitespace-nowrap">
                    <div class="text-sm font-medium text-blue-600"><?= htmlspecialchars($invoice['invoice_number']) ?></div>
                    <?php if ($invoice['return_status'] === 'Partial'): ?>
                        <span class="text-xs bg-yellow-100 text-yellow-800 font-medium px-2 py-0.5 rounded-full">Partially Returned</span>
                    <?php endif; ?>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?= date("M d, Y", strtotime($invoice['invoice_date'])) ?></td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <div class="text-sm font-medium text-gray-900"><?= htmlspecialchars($invoice['customer_name']) ?></div>
                    <div class="text-xs text-gray-500"><?= htmlspecialchars($invoice['customer_phone'] ?: 'N/A') ?></div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Rs. <?= number_format($invoice['grand_total'], 2) ?></td>
                <td class="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
                    <div class="flex justify-center space-x-4">
                        <button onclick="openReturnModal(<?= $invoice['id'] ?>)" class="text-indigo-600 hover:text-indigo-900" title="Process Return">
                            <i class="fas fa-undo fa-lg"></i>
                        </button>
                        <button onclick="deleteInvoice(<?= $invoice['id'] ?>)" class="text-red-600 hover:text-red-900" title="Delete Invoice Record">
                            <i class="fas fa-trash fa-lg"></i>
                        </button>
                    </div>
                </td>
            </tr>
        <?php }
    } else { ?>
        <tr><td colspan="5" class="px-6 py-10 text-center text-gray-500"><i class="fas fa-file-invoice-dollar fa-3x text-gray-300"></i><p class="mt-2">No invoices found matching criteria.</p></td></tr>
    <?php }
    $table_html = ob_get_clean();

    // Render Pagination
    ob_start();
    if ($total_pages > 1) { ?>
        <div class="bg-white px-4 py-3 border-t sm:px-6 flex items-center justify-between">
             <p class="text-sm text-gray-700">Showing <span class="font-medium"><?= $offset + 1 ?></span> to <span class="font-medium"><?= min($offset + $records_per_page, $total_records) ?></span> of <span class="font-medium"><?= $total_records ?></span> results</p>
            <div class="flex space-x-2">
                <?php $query_params = $_GET; ?>
                <a href="?<?php $query_params['page'] = $page - 1; echo http_build_query($query_params); ?>" class="<?= $page <= 1 ? 'pointer-events-none opacity-50' : '' ?> page-link px-3 py-1 rounded-md border bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">Prev</a>
                <a href="?<?php $query_params['page'] = $page + 1; echo http_build_query($query_params); ?>" class="<?= $page >= $total_pages ? 'pointer-events-none opacity-50' : '' ?> page-link px-3 py-1 rounded-md border bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">Next</a>
            </div>
        </div>
    <?php }
    $pagination_html = ob_get_clean();
    
    return ['table_html' => $table_html, 'pagination_html' => $pagination_html];
}

// --- API ENDPOINT LOGIC ---
if (isset($_REQUEST['action'])) {
    header('Content-Type: application/json');
    $response = ['status' => 'error', 'message' => 'An unknown error occurred.'];

    // NEW: Handle AJAX filtering action
    if ($_REQUEST['action'] === 'filter_invoices') {
        // This block handles AJAX requests from the filter form
        $records_per_page = 10;
        $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
        $offset = ($page - 1) * $records_per_page;

        $search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
        $from_date = isset($_GET['from_date']) && !empty($_GET['from_date']) ? $_GET['from_date'] : '';
        $to_date = isset($_GET['to_date']) && !empty($_GET['to_date']) ? $_GET['to_date'] : '';

        $where_conditions = ["return_status != 'Full'"];
        $params = [];
        $types = '';

        if ($search_term !== '') {
            $where_conditions[] = "(invoice_number LIKE ? OR customer_name LIKE ? OR customer_phone LIKE ?)";
            $like_search_term = "%{$search_term}%";
            array_push($params, $like_search_term, $like_search_term, $like_search_term);
            $types .= 'sss';
        }
        if ($from_date !== '') { $where_conditions[] = "invoice_date >= ?"; $params[] = $from_date; $types .= 's'; }
        if ($to_date !== '') { $where_conditions[] = "invoice_date <= ?"; $params[] = $to_date; $types .= 's'; }
        $where_sql = 'WHERE ' . implode(' AND ', $where_conditions);

        $total_query = "SELECT COUNT(*) as total FROM sales_invoices {$where_sql}";
        $stmt_total = $conn->prepare($total_query);
        if ($types) $stmt_total->bind_param($types, ...$params);
        $stmt_total->execute();
        $total_records = $stmt_total->get_result()->fetch_assoc()['total'];
        $total_pages = ceil($total_records / $records_per_page);
        $stmt_total->close();

        $query = "SELECT id, invoice_number, invoice_date, customer_name, customer_phone, grand_total, return_status FROM sales_invoices {$where_sql} ORDER BY invoice_date DESC, id DESC LIMIT ? OFFSET ?";
        $page_types = $types . 'ii';
        $page_params = $params;
        array_push($page_params, $records_per_page, $offset);

        $stmt = $conn->prepare($query);
        if ($page_types) $stmt->bind_param($page_types, ...$page_params);
        $stmt->execute();
        $invoices = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        $rendered_content = render_invoice_table_and_pagination($invoices, $total_pages, $page, $offset, $records_per_page, $total_records);
        
        echo json_encode(['status' => 'success', 'data' => $rendered_content]);
        $conn->close();
        exit;
    }

    switch ($_REQUEST['action']) {
        case 'get_invoice_details':
            if (isset($_GET['id'])) {
                $invoice_id = intval($_GET['id']);
                
                // Fetch main invoice data
                $stmt_inv = $conn->prepare("SELECT * FROM sales_invoices WHERE id = ?");
                $stmt_inv->bind_param("i", $invoice_id);
                $stmt_inv->execute();
                $invoice_data = $stmt_inv->get_result()->fetch_assoc();
                $stmt_inv->close();

                if ($invoice_data) {
                    $stmt_items = $conn->prepare("SELECT si.id as sales_item_id, si.product_id, si.product_name, si.quantity, si.price FROM sales_items si WHERE si.sales_invoice_id = ?");
                    $stmt_items->bind_param("i", $invoice_id);
                    $stmt_items->execute();
                    $invoice_items = $stmt_items->get_result()->fetch_all(MYSQLI_ASSOC);
                    $stmt_items->close();

                    // This part is problematic due to schema mismatch, but we make it non-fatal for now.
                    // This assumes no items have been returned yet. A full fix requires schema alignment.
                    $returned_quantities = [];
                    
                    foreach ($invoice_items as &$item) {
                        $already_returned = $returned_quantities[$item['product_id']] ?? 0;
                        $item['returnable_qty'] = $item['quantity'] - $already_returned;
                    }
                    $response = ['status' => 'success', 'data' => ['invoice' => $invoice_data, 'items' => $invoice_items]];
                } else { $response['message'] = 'Invoice not found.'; }
            } else { $response['message'] = 'No ID provided.'; }
            break;

        // =================== START OF FIX ===================
        case 'process_return':
            $data = json_decode(file_get_contents('php://input'), true);
            $invoice_id = intval($data['invoice_id']);
            $items_to_return = $data['items'];
            $total_refund_amount = 0;

            if (empty($items_to_return)) {
                 $response['message'] = 'No items selected for return.';
                 echo json_encode($response);
                 exit;
            }

            $conn->begin_transaction();
            try {
                // MODIFIED: This query now matches the `sales_returns` table schema.
                // NOTE: The schema has a UNIQUE constraint on `invoice_item_id`, meaning an item can only be returned once.
                // This logic does not support multiple partial returns for the same line item.
                $stmt_log_return = $conn->prepare("INSERT INTO sales_returns (invoice_item_id, return_date, return_amount) VALUES (?, ?, ?)");
                $stmt_update_stock = $conn->prepare("UPDATE accessory_purchases SET quantity = quantity + ? WHERE id = ?");

                foreach ($items_to_return as $item) {
                    $product_id = intval($item['product_id']);
                    $return_qty = intval($item['return_qty']);
                    $price = floatval($item['price']);
                    
                    // NEW: Get the sales_item_id from the data sent by JS
                    $sales_item_id = intval($item['sales_item_id']);
                    $current_date = date('Y-m-d');
                    $return_amount = $return_qty * $price;
                    
                    if ($return_qty > 0) {
                        // MODIFIED: Bind parameters for the new, correct query.
                        $stmt_log_return->bind_param("isd", $sales_item_id, $current_date, $return_amount);
                        $stmt_log_return->execute();
                        
                        // This part was already correct.
                        $stmt_update_stock->bind_param("ii", $return_qty, $product_id);
                        $stmt_update_stock->execute();
                        
                        $total_refund_amount += $return_amount;
                    }
                }
                $stmt_log_return->close();
                $stmt_update_stock->close();
                
                // This part is fine. It updates the parent invoice.
                $stmt_update_invoice = $conn->prepare("UPDATE sales_invoices SET invoice_amount = invoice_amount - ?, grand_total = grand_total - ? WHERE id = ?");
                $stmt_update_invoice->bind_param("ddi", $total_refund_amount, $total_refund_amount, $invoice_id);
                $stmt_update_invoice->execute();
                $stmt_update_invoice->close();

                // MODIFIED: The original status check logic was also broken due to schema mismatch.
                // This simplified logic sets the status to 'Partial'. A full implementation of 'Full' status
                // would require more complex logic and possibly a schema change. This prevents the code from crashing.
                $new_status = 'Partial';
                $stmt_set_status = $conn->prepare("UPDATE sales_invoices SET return_status = ? WHERE id = ?");
                $stmt_set_status->bind_param("si", $new_status, $invoice_id);
                $stmt_set_status->execute();
                $stmt_set_status->close();

                $conn->commit();
                $response = ['status' => 'success', 'message' => 'Return processed successfully. Stock and invoice updated.'];
            } catch (Exception $e) {
                $conn->rollback();
                // Provide a more specific error message if it's a duplicate entry error
                if ($conn->errno == 1062) { // 1062 is the error code for duplicate entry
                    $response['message'] = 'Transaction Failed: One or more items have already been logged as returned and cannot be returned again.';
                } else {
                    $response['message'] = 'Transaction Failed: ' . $e->getMessage();
                }
            }
            break;
        // =================== END OF FIX ===================

        case 'delete_invoice':
            if (isset($_POST['id'])) {
                $invoice_id = intval($_POST['id']);
                $conn->begin_transaction();
                try {
                    $stmt_get_items = $conn->prepare("SELECT product_id, quantity FROM sales_items WHERE sales_invoice_id = ?");
                    $stmt_get_items->bind_param("i", $invoice_id);
                    $stmt_get_items->execute();
                    $items_to_restore = $stmt_get_items->get_result()->fetch_all(MYSQLI_ASSOC);
                    $stmt_get_items->close();
                    $stmt_restore_stock = $conn->prepare("UPDATE accessory_purchases SET quantity = quantity + ? WHERE id = ?");
                    foreach ($items_to_restore as $item) {
                        $stmt_restore_stock->bind_param("ii", $item['quantity'], $item['product_id']);
                        $stmt_restore_stock->execute();
                    }
                    $stmt_restore_stock->close();
                    $stmt_delete_invoice = $conn->prepare("DELETE FROM sales_invoices WHERE id = ?");
                    $stmt_delete_invoice->bind_param("i", $invoice_id);
                    $stmt_delete_invoice->execute();
                    $stmt_delete_invoice->close();
                    $conn->commit();
                    $response = ['status' => 'success', 'message' => 'Invoice deleted and stock restored successfully.'];
                } catch (Exception $e) {
                    $conn->rollback();
                    $response['message'] = 'Transaction Failed: ' . $e->getMessage();
                }
            } else { $response['message'] = 'No Invoice ID provided.'; }
            break;
    }

    echo json_encode($response);
    $conn->close();
    exit;
}

// --- INITIAL PAGE LOAD DATA FETCHING ---
$records_per_page = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $records_per_page;
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
$from_date = isset($_GET['from_date']) && !empty($_GET['from_date']) ? $_GET['from_date'] : '';
$to_date = isset($_GET['to_date']) && !empty($_GET['to_date']) ? $_GET['to_date'] : '';
$where_conditions = ["return_status != 'Full'"];
$params = [];
$types = '';
if ($search_term !== '') { $where_conditions[] = "(invoice_number LIKE ? OR customer_name LIKE ? OR customer_phone LIKE ?)"; $like_search_term = "%{$search_term}%"; array_push($params, $like_search_term, $like_search_term, $like_search_term); $types .= 'sss'; }
if ($from_date !== '') { $where_conditions[] = "invoice_date >= ?"; $params[] = $from_date; $types .= 's'; }
if ($to_date !== '') { $where_conditions[] = "invoice_date <= ?"; $params[] = $to_date; $types .= 's'; }
$where_sql = 'WHERE ' . implode(' AND ', $where_conditions);
$total_query = "SELECT COUNT(*) as total FROM sales_invoices {$where_sql}";
$stmt_total = $conn->prepare($total_query);
if ($types) $stmt_total->bind_param($types, ...$params);
$stmt_total->execute();
$total_records = $stmt_total->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_records / $records_per_page);
$stmt_total->close();
$query = "SELECT id, invoice_number, invoice_date, customer_name, customer_phone, grand_total, return_status FROM sales_invoices {$where_sql} ORDER BY invoice_date DESC, id DESC LIMIT ? OFFSET ?";
$page_types = $types . 'ii';
$page_params = $params;
array_push($page_params, $records_per_page, $offset);
$stmt = $conn->prepare($query);
if ($page_types) $stmt->bind_param($page_types, ...$page_params);
$stmt->execute();
$invoices = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Sales Returns</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 min-h-screen">
    <?php include '../includes/sidebar.php'; ?>

    <div class="ml-64 transition-all duration-300 ease-in-out">
        <main class="p-8">
            <h1 class="text-3xl font-bold text-gray-900 mb-8">Manage Sales Returns</h1>

            <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                <form id="filterForm" class="space-y-4">
                     <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
                        <div class="lg:col-span-2">
                            <label for="search" class="block text-sm font-medium text-gray-700">Search Invoices</label>
                            <div class="mt-1 relative">
                                <input type="text" id="search" name="search" placeholder="Search by Invoice #, Customer, or Phone..." class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md" value="<?= htmlspecialchars($search_term) ?>">
                                <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><i class="fas fa-search text-gray-400"></i></div>
                            </div>
                        </div>
                        <div>
                            <label for="from_date" class="block text-sm font-medium text-gray-700">From Date</label>
                            <input type="date" name="from_date" id="from_date" class="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md" value="<?= htmlspecialchars($from_date) ?>">
                        </div>
                        <div>
                            <label for="to_date" class="block text-sm font-medium text-gray-700">To Date</label>
                            <input type="date" name="to_date" id="to_date" class="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md" value="<?= htmlspecialchars($to_date) ?>">
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 pt-2">
                        <button type="button" id="resetBtn" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-md text-sm font-medium hover:bg-gray-300">Reset</button>
                        <button type="button" id="filterBtn" class="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700 flex items-center"><i class="fas fa-filter mr-2"></i>Filter</button>
                    </div>
                </form>
            </div>

            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Invoice No</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total Amount</th>
                                <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="invoiceTableBody" class="bg-white divide-y divide-gray-200">
                            <?php 
                                $initial_content = render_invoice_table_and_pagination($invoices, $total_pages, $page, $offset, $records_per_page, $total_records);
                                echo $initial_content['table_html'];
                            ?>
                        </tbody>
                    </table>
                </div>
                <div id="paginationContainer">
                    <?php echo $initial_content['pagination_html']; ?>
                </div>
            </div>
        </main>
    </div>

    <!-- Return Modal -->
    <div id="returnModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-10 mx-auto p-5 border w-full max-w-4xl shadow-lg rounded-md bg-white">
            <div class="flex justify-between items-center border-b pb-3">
                <h3 class="text-2xl font-bold text-gray-900">Process Return for Invoice <span id="modalInvoiceNumber" class="text-blue-600"></span></h3>
                <button onclick="closeReturnModal()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times fa-lg"></i>
                </button>
            </div>
            <div class="mt-5">
                <form id="returnForm">
                    <input type="hidden" id="modalInvoiceId">
                    
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 text-sm bg-gray-50 p-4 rounded-lg">
                        <div><strong>Customer:</strong> <span id="modalCustomerName"></span></div>
                        <div><strong>Phone:</strong> <span id="modalCustomerPhone"></span></div>
                        <div><strong>Date:</strong> <span id="modalInvoiceDate"></span></div>
                    </div>

                    <h4 class="text-lg font-semibold text-gray-700 mb-2">Invoice Items</h4>
                    <div class="overflow-x-auto border rounded-lg">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-100">
                                <tr>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-600 uppercase">Product</th>
                                    <th class="px-4 py-2 text-center text-xs font-medium text-gray-600 uppercase">Sold Qty</th>
                                    <th class="px-4 py-2 text-center text-xs font-medium text-gray-600 uppercase">Returned Qty</th>
                                    <th class="px-4 py-2 text-center text-xs font-medium text-gray-600 uppercase">Returnable Qty</th>
                                    <th class="px-4 py-2 text-center text-xs font-medium text-gray-600 uppercase">Qty to Return</th>
                                </tr>
                            </thead>
                            <tbody id="modalItemsTbody" class="bg-white divide-y divide-gray-200">
                                <!-- JS will populate this -->
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-6 flex justify-between items-center">
                        <div>
                            <span class="text-lg font-bold">Total Refund:</span>
                            <span id="modalTotalRefund" class="text-lg font-bold text-red-600">Rs. 0.00</span>
                        </div>
                        <div class="flex gap-4">
                            <button type="button" onclick="closeReturnModal()" class="px-6 py-2 bg-gray-200 text-gray-700 rounded-md font-medium hover:bg-gray-300">Cancel</button>
                            <button type="submit" id="saveReturnBtn" class="px-6 py-2 bg-indigo-600 text-white rounded-md font-medium hover:bg-indigo-700 flex items-center">
                                <i class="fas fa-check mr-2"></i> Confirm Return
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const filterForm = document.getElementById('filterForm');
        const filterBtn = document.getElementById('filterBtn');
        const resetBtn = document.getElementById('resetBtn');
        
        async function applyFilters(page = 1) {
            const formData = new FormData(filterForm);
            const params = new URLSearchParams(formData);
            params.append('action', 'filter_invoices');
            params.append('page', page);

            document.getElementById('invoiceTableBody').innerHTML = '<tr><td colspan="5" class="text-center p-10"><i class="fas fa-spinner fa-spin text-2xl"></i></td></tr>';
            
            try {
                const response = await fetch(`?${params.toString()}`);
                const result = await response.json();

                if (result.status === 'success') {
                    document.getElementById('invoiceTableBody').innerHTML = result.data.table_html;
                    document.getElementById('paginationContainer').innerHTML = result.data.pagination_html;
                    attachPaginationListeners();
                } else {
                    document.getElementById('invoiceTableBody').innerHTML = `<tr><td colspan="5" class="text-center p-10 text-red-500">Error: ${result.message}</td></tr>`;
                }
            } catch (error) {
                document.getElementById('invoiceTableBody').innerHTML = `<tr><td colspan="5" class="text-center p-10 text-red-500">An error occurred while filtering.</td></tr>`;
            }
        }

        function attachPaginationListeners() {
            document.querySelectorAll('.page-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const url = new URL(this.href);
                    const page = url.searchParams.get('page');
                    applyFilters(page);
                });
            });
        }
        
        filterBtn.addEventListener('click', () => applyFilters(1));
        resetBtn.addEventListener('click', () => { filterForm.reset(); applyFilters(1); });
        attachPaginationListeners();
    });

    const returnModal = document.getElementById('returnModal');
    const modalItemsTbody = document.getElementById('modalItemsTbody');
    const returnForm = document.getElementById('returnForm');

    function closeReturnModal() {
        returnModal.classList.add('hidden');
        modalItemsTbody.innerHTML = ''; // Clear content on close
    }

    async function openReturnModal(invoiceId) {
        returnModal.classList.remove('hidden');
        modalItemsTbody.innerHTML = '<tr><td colspan="5" class="text-center p-6"><i class="fas fa-spinner fa-spin text-2xl text-gray-500"></i></td></tr>';

        try {
            const response = await fetch(`?action=get_invoice_details&id=${invoiceId}`);
            const result = await response.json();

            if (result.status === 'success') {
                const { invoice, items } = result.data;
                
                document.getElementById('modalInvoiceNumber').textContent = invoice.invoice_number;
                document.getElementById('modalCustomerName').textContent = invoice.customer_name;
                document.getElementById('modalCustomerPhone').textContent = invoice.customer_phone || 'N/A';
                document.getElementById('modalInvoiceDate').textContent = new Date(invoice.invoice_date).toLocaleDateString('en-GB');
                document.getElementById('modalInvoiceId').value = invoice.id;

                modalItemsTbody.innerHTML = '';
                if (items.length > 0) {
                    items.forEach(item => {
                        const row = document.createElement('tr');
                        // =================== START OF FIX ===================
                        // MODIFIED: Added `data-sales-item-id` to the row to pass it to the backend.
                        row.dataset.salesItemId = item.sales_item_id;
                        // =================== END OF FIX ===================
                        row.dataset.productId = item.product_id;
                        row.dataset.price = item.price;
                        row.dataset.returnableQty = item.returnable_qty;

                        row.innerHTML = `
                            <td class="px-4 py-3 text-sm text-gray-800">${item.product_name}</td>
                            <td class="px-4 py-3 text-center text-sm">${item.quantity}</td>
                            <td class="px-4 py-3 text-center text-sm">${item.quantity - item.returnable_qty}</td>
                            <td class="px-4 py-3 text-center text-sm font-medium">${item.returnable_qty}</td>
                            <td class="px-4 py-3 text-center">
                                <input type="number" class="return-qty-input w-24 text-center border border-gray-300 rounded-md p-1" value="0" min="0" max="${item.returnable_qty}" ${item.returnable_qty === 0 ? 'disabled' : ''}>
                            </td>
                        `;
                        modalItemsTbody.appendChild(row);
                    });
                } else {
                    modalItemsTbody.innerHTML = '<tr><td colspan="5" class="text-center p-6 text-gray-500">No items found for this invoice.</td></tr>';
                }
                updateRefundTotal();
            } else {
                modalItemsTbody.innerHTML = `<tr><td colspan="5" class="text-center p-6 text-red-500">Error: ${result.message}</td></tr>`;
            }
        } catch (error) {
            modalItemsTbody.innerHTML = `<tr><td colspan="5" class="text-center p-6 text-red-500">An error occurred while fetching invoice details.</td></tr>`;
        }
    }

    function updateRefundTotal() {
        let totalRefund = 0;
        modalItemsTbody.querySelectorAll('tr').forEach(row => {
            const price = parseFloat(row.dataset.price) || 0;
            const returnQtyInput = row.querySelector('.return-qty-input');
            if (returnQtyInput) {
                const returnQty = parseInt(returnQtyInput.value) || 0;
                totalRefund += price * returnQty;
            }
        });
        document.getElementById('modalTotalRefund').textContent = `Rs. ${totalRefund.toFixed(2)}`;
    }

    modalItemsTbody.addEventListener('input', function(e) {
        if (e.target.classList.contains('return-qty-input')) {
            const input = e.target;
            const maxQty = parseInt(input.max);
            if (parseInt(input.value) > maxQty) input.value = maxQty;
            if (parseInt(input.value) < 0) input.value = 0;
            updateRefundTotal();
        }
    });

    returnForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const saveBtn = document.getElementById('saveReturnBtn');
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Processing...';

        const invoiceId = document.getElementById('modalInvoiceId').value;
        const itemsToReturn = [];

        modalItemsTbody.querySelectorAll('tr').forEach(row => {
            const returnQtyInput = row.querySelector('.return-qty-input');
            if (returnQtyInput) {
                const returnQty = parseInt(returnQtyInput.value) || 0;
                if (returnQty > 0) {
                    // =================== START OF FIX ===================
                    // MODIFIED: Added `sales_item_id` to the object being sent to the PHP script.
                    itemsToReturn.push({
                        sales_item_id: row.dataset.salesItemId,
                        product_id: row.dataset.productId,
                        return_qty: returnQty,
                        price: parseFloat(row.dataset.price)
                    });
                    // =================== END OF FIX ===================
                }
            }
        });

        if (itemsToReturn.length === 0) {
            alert('Please enter a quantity for at least one item to return.');
            saveBtn.disabled = false;
            saveBtn.innerHTML = '<i class="fas fa-check mr-2"></i> Confirm Return';
            return;
        }
        
        try {
            const response = await fetch('?action=process_return', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ invoice_id: invoiceId, items: itemsToReturn })
            });
            const result = await response.json();

            if (result.status === 'success') {
                alert(result.message);
                closeReturnModal();
                location.reload();
            } else {
                alert('Error: ' + result.message);
            }
        } catch (error) {
            alert('An error occurred while communicating with the server.');
        } finally {
            saveBtn.disabled = false;
            saveBtn.innerHTML = '<i class="fas fa-check mr-2"></i> Confirm Return';
        }
    });
    
    async function deleteInvoice(id) {
        if (!confirm('Are you sure you want to delete this invoice record? This will restore the sold item quantities to the stock. This action cannot be undone.')) {
            return;
        }
        const formData = new FormData();
        formData.append('action', 'delete_invoice');
        formData.append('id', id);
        try {
            const response = await fetch('acc-returns.php', { method: 'POST', body: formData });
            const result = await response.json();
            if (result.status === 'success') {
                alert(result.message);
                location.reload();
            } else {
                alert('Error: ' + result.message);
            }
        } catch (error) {
            alert('An error occurred while communicating with the server.');
        }
    }

</script>

</body>
</html>