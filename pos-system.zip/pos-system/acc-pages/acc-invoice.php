<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Invoice</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    /* Define the page size and margins for printing */
    @page {
        size: 15cm 21cm;
        margin: 1cm;
    }

    @media print {
      body { 
        -webkit-print-color-adjust: exact; 
        background-color: #fff; /* Ensure a white background for printing */
      }
      /* Make the invoice container fill the printable area */
      .invoice-container { 
        width: 100%;
        height: auto;
        min-height: 0;
        margin: 0;
        padding: 0;
        box-shadow: none; 
        border: none;
      }
    }
  </style>
</head>
<body class="bg-gray-200">
  <!-- The "Print" and "New Sale" buttons have been removed from this section -->

  <div id="invoice" class="invoice-container w-[570px] min-h-[797px] p-6 mx-auto bg-white my-8 shadow-lg flex flex-col">
    <!-- Header -->
    <header class="border-b border-black pb-4">
      <div class="flex justify-between items-start">
        <div class="text-left text-sm leading-snug">
          <h1 class="text-4xl font-bold">DMM BR_1</h1>
          <p>Yousaf Shah Khan Plaza near <br>Taj Cenima Shaheedan Bazaar Mardan</p>
          <p>Phone: 0300-1234567</p>
          <p>Seller: Zahid Mehmood</p>
        </div>
        <div class="text-right">
          <h2 class="text-lg font-semibold underline">INVOICE</h2>
        </div>
      </div>
      <div class="flex justify-center mt-2">
        <img id="qrCode" src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=Invoice" alt="QR Code" class="w-[2.5cm] h-[2.5cm] border border-black p-1">
      </div>
    </header>

    <!-- Customer Info -->
    <section class="mt-4 text-sm border-b border-black pb-2 grid grid-cols-2 gap-y-1">
      <div>
        <p><span class="font-semibold">Customer:</span> <span id="custName">___________________</span></p>
        <p><span class="font-semibold">Phone:</span> <span id="custPhone">___________________</span></p>
      </div>
      <div class="text-right">
        <p><span class="font-semibold">Invoice No:</span> <span id="invNo">__________</span></p>
        <p><span class="font-semibold">Date:</span> <span id="invDate">__________</span></p>
      </div>
    </section>

    <!-- Invoice Table -->
    <section class="mt-4 text-sm">
      <table class="w-full table-auto border border-black border-collapse">
        <thead>
          <tr class="border-b border-black bg-gray-200">
            <th class="border-r border-black px-2 py-1">#</th>
            <th class="border-r border-black px-2 py-1 text-left">Product</th>
            <th class="border-r border-black px-2 py-1">Qty</th>
            <th class="border-r border-black px-2 py-1 text-right">Price</th>
            <th class="px-2 py-1 text-right">Total</th>
          </tr>
        </thead>
        <tbody id="invoiceItems">
          <!-- Items will be populated by JS -->
        </tbody>
      </table>
    </section>

    <!-- Spacer to push content to the bottom -->
    <div class="flex-grow"></div>

    <!-- Payment Section -->
    <section class="text-sm border-t border-black pt-2 mt-auto">
      <div class="flex justify-between items-start">
        <div class="w-1/2 pr-4">
          <div class="bg-gray-100 border border-gray-300 rounded p-2 text-xs leading-snug">
            <p class="font-semibold text-[18px]">Note:</p>
            <p class="text-[15px]">Please retain this invoice for warranty & exchange. No claims will be entertained without it. Thank you for your trust!</p>
          </div>
        </div>
        <div class="w-1/2 text-right">
          <div class="flex justify-between"><span>Invoice Amount:</span><span id="summaryInvoiceAmount">Rs. 0.00</span></div>
          <div class="flex justify-between"><span>Previous Balance:</span><span id="summaryPrevBalance">Rs. 0.00</span></div>
          <div class="flex justify-between font-bold border-t border-black mt-1 pt-1"><span>Total:</span><span id="summaryTotal">Rs. 0.00</span></div>
          <div class="flex justify-between"><span>Received:</span><span id="summaryReceived">Rs. 0.00</span></div>
          <div class="flex justify-between"><span>Balance:</span><span id="summaryBalance">Rs. 0.00</span></div>
          <div class="flex justify-between font-bold bg-gray-200 px-1"><span>Grand Total:</span><span id="summaryGrandTotal">Rs. 0.00</span></div>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="mt-4 text-center text-sm border-t border-black pt-2">
      <p>A Smart Solution By Farhan Shah | 031234567890</p>
      <p>www.developer-farhanshah.netlify.app</p>
    </footer>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', () => {
        const dataString = sessionStorage.getItem('invoiceData');
        if (!dataString) {
            // If there's no data, the user likely refreshed the page or navigated here directly.
            // You can optionally show a message or redirect them.
            const invoiceBody = document.getElementById('invoice');
            if (invoiceBody) {
                invoiceBody.innerHTML = '<div class="text-center p-10">No invoice data to display. Please <a href="sales.php" class="text-blue-600 underline">create a new sale</a>.</div>';
            }
            return;
        }

        const data = JSON.parse(dataString);
        
        // Populate customer and invoice details
        document.getElementById('custName').textContent = data.customer_name || 'N/A';
        document.getElementById('custPhone').textContent = data.customer_phone || 'N/A';
        document.getElementById('invNo').textContent = data.invoice_number;
        document.getElementById('invDate').textContent = new Date(data.invoice_date).toLocaleDateString('en-GB');

        // Populate items table
        const itemsTbody = document.getElementById('invoiceItems');
        itemsTbody.innerHTML = ''; // Clear any placeholder
        data.items.forEach((item, index) => {
            const row = `
                <tr class="border-b border-black">
                    <td class="border-r border-black px-2 py-1 text-center">${index + 1}</td>
                    <td class="border-r border-black px-2 py-1">${item.name}</td>
                    <td class="border-r border-black px-2 py-1 text-center">${item.qty}</td>
                    <td class="border-r border-black px-2 py-1 text-right">Rs. ${item.price.toFixed(2)}</td>
                    <td class="px-2 py-1 text-right">Rs. ${item.total.toFixed(2)}</td>
                </tr>
            `;
            itemsTbody.innerHTML += row;
        });

        // Populate summary
        document.getElementById('summaryInvoiceAmount').textContent = `Rs. ${data.summary.invoice_amount.toFixed(2)}`;
        document.getElementById('summaryPrevBalance').textContent = `Rs. ${data.summary.previous_balance.toFixed(2)}`;
        document.getElementById('summaryTotal').textContent = `Rs. ${data.summary.grand_total.toFixed(2)}`;
        document.getElementById('summaryGrandTotal').textContent = `Rs. ${data.summary.grand_total.toFixed(2)}`;
        document.getElementById('summaryReceived').textContent = `Rs. ${data.summary.received_amount.toFixed(2)}`;
        document.getElementById('summaryBalance').textContent = `Rs. ${data.summary.remaining_amount.toFixed(2)}`;

        // Update QR Code
        const qrData = `Invoice: ${data.invoice_number}, Customer: ${data.customer_name}, Total: ${data.summary.grand_total.toFixed(2)}`;
        document.getElementById('qrCode').src = `https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(qrData)}`;

        // Clear sessionStorage so it's not used again on refresh
        sessionStorage.removeItem('invoiceData');

        // Automatically trigger print dialog
        setTimeout(() => {
            window.print();
        }, 500);
    });
  </script>
</body>
</html>