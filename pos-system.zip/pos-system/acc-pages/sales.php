<?php
// pos-system/acc-pages/sales.php
require_once '../includes/db.php';

// --- API ENDPOINT FOR AJAX REQUESTS ---
if (isset($_GET['action'])) {
    header('Content-Type: application/json');
    $response = ['status' => 'error', 'message' => 'An unknown error occurred.'];

    switch ($_GET['action']) {
        // ACTION: Search for products to add to the invoice
        case 'search_products':
            $term = isset($_GET['term']) ? $_GET['term'] . '%' : '%';
            $stmt = $conn->prepare("SELECT id, product_name, sale_price, quantity FROM accessory_purchases WHERE (product_name LIKE ? OR product_code LIKE ?) AND quantity > 0");
            $stmt->bind_param("ss", $term, $term);
            $stmt->execute();
            $result = $stmt->get_result();
            $products = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            echo json_encode($products);
            exit;

        // ACTION: Get the next available invoice number
        case 'get_invoice_number':
            $result = $conn->query("SELECT MAX(id) as max_id FROM sales_invoices");
            $max_id = $result->fetch_assoc()['max_id'];
            $next_id = ($max_id ?? 0) + 1;
            $invoice_number = 'INV-' . str_pad($next_id, 5, '0', STR_PAD_LEFT);
            echo json_encode(['invoice_number' => $invoice_number]);
            exit;
    }
}

// ACTION: Process and save the entire sale
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'process_sale') {
    header('Content-Type: application/json');
    $data = json_decode($_POST['data'], true);
    
    $conn->begin_transaction();
    try {
        // 1. Insert into sales_invoices table
        $stmt_invoice = $conn->prepare("INSERT INTO sales_invoices (invoice_number, customer_name, customer_phone, invoice_date, invoice_amount, previous_balance, received_amount, remaining_amount, grand_total) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt_invoice->bind_param("ssssddddd", 
            $data['invoice_number'], $data['customer_name'], $data['customer_phone'], $data['invoice_date'],
            $data['summary']['invoice_amount'], $data['summary']['previous_balance'], $data['summary']['received_amount'],
            $data['summary']['remaining_amount'], $data['summary']['grand_total']
        );
        $stmt_invoice->execute();
        $invoice_id = $conn->insert_id;
        $stmt_invoice->close();

        // 2. Insert into sales_items and update stock in accessory_purchases
        $stmt_item = $conn->prepare("INSERT INTO sales_items (sales_invoice_id, product_id, product_name, quantity, price, total) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt_stock_update = $conn->prepare("UPDATE accessory_purchases SET quantity = quantity - ? WHERE id = ?");

        foreach ($data['items'] as $item) {
            // Insert sale item
            $stmt_item->bind_param("iisidd", $invoice_id, $item['id'], $item['name'], $item['qty'], $item['price'], $item['total']);
            $stmt_item->execute();
            
            // Update stock
            $stmt_stock_update->bind_param("ii", $item['qty'], $item['id']);
            $stmt_stock_update->execute();
        }
        $stmt_item->close();
        $stmt_stock_update->close();

        $conn->commit();
        echo json_encode(['status' => 'success', 'message' => 'Sale processed successfully!', 'invoice_id' => $invoice_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['status' => 'error', 'message' => 'Transaction Failed: ' . $e->getMessage()]);
    }
    $conn->close();
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Sales Invoice</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .suggestion-box {
            position: absolute;
            border: 1px solid #ddd;
            background: white;
            z-index: 1000;
            max-height: 200px;
            overflow-y: auto;
            width: calc(100% - 1.5rem); /* Match parent width minus padding */
        }
        .suggestion-item {
            padding: 8px;
            cursor: pointer;
        }
        .suggestion-item:hover {
            background-color: #f0f0f0;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <?php include '../includes/sidebar.php'; ?>

    <div class="ml-64 transition-all duration-300 ease-in-out">
        <main class="p-8">
            <form id="salesForm">
                <h1 class="text-3xl font-bold text-gray-900 mb-8">Create Sales Invoice</h1>

                <!-- Invoice Header Section -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                    <h2 class="text-xl font-semibold text-gray-800 border-b pb-3 mb-4">Customer & Invoice Details</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div>
                            <label for="customer_name" class="block text-sm font-medium text-gray-700">Customer Name</label>
                            <input type="text" id="customer_name" placeholder="Enter customer name" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        <div>
                            <label for="customer_phone" class="block text-sm font-medium text-gray-700">Phone</label>
                            <input type="tel" id="customer_phone" placeholder="Enter phone number" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        <div>
                            <label for="invoice_date" class="block text-sm font-medium text-gray-700">Invoice Date</label>
                            <input type="date" id="invoice_date" value="<?= date('Y-m-d') ?>" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        <div>
                            <label for="invoice_number" class="block text-sm font-medium text-gray-700">Invoice Number</label>
                            <input type="text" id="invoice_number" readonly class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm bg-gray-100 cursor-not-allowed">
                        </div>
                    </div>
                </div>

                <!-- Sale Items Section -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="p-6 flex justify-between items-center border-b">
                        <h2 class="text-xl font-semibold text-gray-800">Sale Items</h2>
                        <button type="button" id="addItemBtn" class="px-4 py-2 bg-green-600 text-white rounded-md text-sm font-medium hover:bg-green-700 flex items-center justify-center">
                            <i class="fas fa-plus mr-2"></i> Add Item
                        </button>
                    </div>
                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col" class="w-2/5 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product Name</th>
                                    <th scope="col" class="w-1/5 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                                    <th scope="col" class="w-1/5 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                                    <th scope="col" class="w-1/5 px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                                    <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                                </tr>
                            </thead>
                            <tbody id="saleItemsTbody" class="bg-white divide-y divide-gray-200">
                                <!-- Rows will be added dynamically by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Payment and Summary Section -->
                <div class="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
                    <div class="lg:col-span-2"></div>
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h2 class="text-xl font-semibold text-gray-800 border-b pb-3 mb-4">Payment Summary</h2>
                        <div class="space-y-4 text-sm">
                            <div class="flex justify-between items-center">
                                <span class="font-medium text-gray-600">Invoice Amount:</span>
                                <span class="font-bold text-gray-900" id="invoiceAmount">Rs. 0.00</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <label for="previous_balance" class="font-medium text-gray-600">Previous Balance:</label>
                                <input type="number" id="previous_balance" value="0.00" step="0.01" class="w-28 text-right px-2 py-1 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500">
                            </div>
                            <hr>
                            <div class="flex justify-between items-center text-lg">
                                <span class="font-bold text-gray-800">Grand Total:</span>
                                <span class="font-extrabold text-blue-600" id="grandTotal">Rs. 0.00</span>
                            </div>
                            <hr>
                            <div class="flex justify-between items-center">
                                <label for="received_amount" class="font-medium text-gray-600">Received Amount:</label>
                                <input type="number" id="received_amount" placeholder="0.00" step="0.01" required class="w-28 text-right px-2 py-1 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500">
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="font-medium text-gray-600">Remaining Amount:</span>
                                <span class="font-bold text-red-600" id="remainingAmount">Rs. 0.00</span>
                            </div>
                        </div>
                        <div class="mt-6">
                            <button type="submit" id="printInvoiceBtn" class="w-full px-4 py-3 bg-blue-600 text-white font-bold rounded-md text-sm hover:bg-blue-700 flex items-center justify-center gap-2">
                                <i class="fas fa-print"></i> Save & Print Invoice
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </main>
    </div>
    
    <!-- JS Template for table row -->
    <template id="saleItemRowTemplate">
        <tr class="sale-item-row">
            <td class="px-6 py-4 whitespace-nowrap relative">
                <input type="hidden" class="product-id">
                <input type="text" placeholder="Type to search product..." class="product-name w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required>
                <div class="suggestion-box hidden"></div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <input type="number" value="1" min="1" class="quantity w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <input type="number" step="0.01" class="price w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" required>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 total">
                Rs. 0.00
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-center">
                <button type="button" class="remove-item-btn text-red-600 hover:text-red-900" title="Remove Item">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </td>
        </tr>
    </template>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const salesForm = document.getElementById('salesForm');
    const addItemBtn = document.getElementById('addItemBtn');
    const tbody = document.getElementById('saleItemsTbody');
    const rowTemplate = document.getElementById('saleItemRowTemplate');

    // --- INITIALIZE PAGE ---
    function initializePage() {
        // Fetch and set the invoice number
        fetch('?action=get_invoice_number')
            .then(res => res.json())
            .then(data => {
                document.getElementById('invoice_number').value = data.invoice_number;
            });
        
        // Add one empty row to start with
        addItemRow();
        
        // Clear form (useful if user navigates back)
        salesForm.reset();
        document.getElementById('invoice_date').valueAsDate = new Date();
        updateSummary();
    }
    
    // --- DYNAMIC ROW & TABLE LOGIC ---
    function addItemRow() {
        const newRow = rowTemplate.content.cloneNode(true);
        tbody.appendChild(newRow);
    }

    tbody.addEventListener('click', function(e) {
        if (e.target.closest('.remove-item-btn')) {
            e.target.closest('tr').remove();
            updateSummary();
        }
    });

    tbody.addEventListener('input', function(e) {
        const row = e.target.closest('tr');
        if (e.target.classList.contains('product-name')) {
            handleProductSearch(e.target);
        }
        if (e.target.classList.contains('quantity') || e.target.classList.contains('price')) {
            updateRowTotal(row);
            updateSummary();
        }
    });

    function updateRowTotal(row) {
        const quantity = parseFloat(row.querySelector('.quantity').value) || 0;
        const price = parseFloat(row.querySelector('.price').value) || 0;
        const total = quantity * price;
        row.querySelector('.total').textContent = `Rs. ${total.toFixed(2)}`;
    }
    
    // --- PRODUCT SEARCH & AUTO-SUGGESTION ---
    async function handleProductSearch(inputElement) {
        const term = inputElement.value;
        const suggestionBox = inputElement.nextElementSibling;

        if (term.length < 1) {
            suggestionBox.classList.add('hidden');
            return;
        }

        const response = await fetch(`?action=search_products&term=${term}`);
        const products = await response.json();
        
        suggestionBox.innerHTML = '';
        if (products.length > 0) {
            products.forEach(product => {
                const item = document.createElement('div');
                item.className = 'suggestion-item';
                item.textContent = `${product.product_name} (Stock: ${product.quantity})`;
                item.dataset.product = JSON.stringify(product);
                item.addEventListener('click', () => selectProduct(product, inputElement.closest('tr')));
                suggestionBox.appendChild(item);
            });
            suggestionBox.classList.remove('hidden');
        } else {
            suggestionBox.classList.add('hidden');
        }
    }

    function selectProduct(product, row) {
        row.querySelector('.product-id').value = product.id;
        row.querySelector('.product-name').value = product.product_name;
        row.querySelector('.price').value = parseFloat(product.sale_price).toFixed(2);
        
        const quantityInput = row.querySelector('.quantity');
        quantityInput.max = product.quantity; // Set max based on stock
        if (parseInt(quantityInput.value) > product.quantity) {
             quantityInput.value = product.quantity;
        }
        
        row.querySelector('.suggestion-box').classList.add('hidden');
        updateRowTotal(row);
        updateSummary();
    }

    // --- PAYMENT SUMMARY CALCULATION ---
    const summaryInputs = ['previous_balance', 'received_amount'];
    summaryInputs.forEach(id => document.getElementById(id).addEventListener('input', updateSummary));
    
    function updateSummary() {
        let invoiceAmount = 0;
        document.querySelectorAll('.sale-item-row').forEach(row => {
            const quantity = parseFloat(row.querySelector('.quantity').value) || 0;
            const price = parseFloat(row.querySelector('.price').value) || 0;
            invoiceAmount += quantity * price;
        });
        document.getElementById('invoiceAmount').textContent = `Rs. ${invoiceAmount.toFixed(2)}`;

        const prevBalance = parseFloat(document.getElementById('previous_balance').value) || 0;
        const grandTotal = invoiceAmount + prevBalance;
        document.getElementById('grandTotal').textContent = `Rs. ${grandTotal.toFixed(2)}`;

        const receivedAmount = parseFloat(document.getElementById('received_amount').value) || 0;
        const remainingAmount = grandTotal - receivedAmount;
        document.getElementById('remainingAmount').textContent = `Rs. ${remainingAmount.toFixed(2)}`;
    }

    // --- FORM SUBMISSION & PRINTING ---
    salesForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const printBtn = document.getElementById('printInvoiceBtn');
        printBtn.disabled = true;
        printBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Processing...';
        
        // 1. Collect all data
        const invoiceData = {
            customer_name: document.getElementById('customer_name').value,
            customer_phone: document.getElementById('customer_phone').value,
            invoice_date: document.getElementById('invoice_date').value,
            invoice_number: document.getElementById('invoice_number').value,
            items: [],
            summary: {
                invoice_amount: parseFloat(document.getElementById('invoiceAmount').textContent.replace('Rs. ', '')),
                previous_balance: parseFloat(document.getElementById('previous_balance').value) || 0,
                grand_total: parseFloat(document.getElementById('grandTotal').textContent.replace('Rs. ', '')),
                received_amount: parseFloat(document.getElementById('received_amount').value) || 0,
                remaining_amount: parseFloat(document.getElementById('remainingAmount').textContent.replace('Rs. ', ''))
            }
        };

        let hasItems = false;
        document.querySelectorAll('.sale-item-row').forEach(row => {
            const productId = row.querySelector('.product-id').value;
            if (productId) { // Only include rows with a selected product
                hasItems = true;
                invoiceData.items.push({
                    id: productId,
                    name: row.querySelector('.product-name').value,
                    qty: parseInt(row.querySelector('.quantity').value),
                    price: parseFloat(row.querySelector('.price').value),
                    total: parseInt(row.querySelector('.quantity').value) * parseFloat(row.querySelector('.price').value)
                });
            }
        });
        
        if (!hasItems) {
            alert('Please add at least one product to the invoice.');
            printBtn.disabled = false;
            printBtn.innerHTML = '<i class="fas fa-print"></i> Save & Print Invoice';
            return;
        }

        // 2. Send data to server to process sale & update stock
        const formData = new FormData();
        formData.append('action', 'process_sale');
        formData.append('data', JSON.stringify(invoiceData));

        try {
            const response = await fetch('sales.php', { method: 'POST', body: formData });
            const result = await response.json();

            if (result.status === 'success') {
                // 3. Store data in sessionStorage for the invoice page
                sessionStorage.setItem('invoiceData', JSON.stringify(invoiceData));
                
                // 4. Redirect to invoice page
                window.location.href = 'acc-invoice.php';
                
                // 5. Clear the form for the next sale (after redirection)
                initializePage(); // This will run when the user navigates back

            } else {
                alert('Error: ' + result.message);
                printBtn.disabled = false;
                printBtn.innerHTML = '<i class="fas fa-print"></i> Save & Print Invoice';
            }
        } catch (error) {
            alert('A network error occurred. Please try again.');
            printBtn.disabled = false;
            printBtn.innerHTML = '<i class="fas fa-print"></i> Save & Print Invoice';
        }
    });
    
    // --- EVENT LISTENERS ---
    addItemBtn.addEventListener('click', addItemRow);
    
    // Hide suggestion box if clicked outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.suggestion-box') && !e.target.classList.contains('product-name')) {
            document.querySelectorAll('.suggestion-box').forEach(box => box.classList.add('hidden'));
        }
    });
    
    initializePage();
});
</script>
</body>
</html>