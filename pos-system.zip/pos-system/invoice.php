<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Invoice</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style> @media print { body { -webkit-print-color-adjust: exact; } .returned-tag { color: #EF4444 !important; } } </style>
</head>
<body>
  <div class="invoice-container w-[570px] h-auto min-h-[797px] p-6 mx-auto bg-white">
    <!-- Header -->
    <header class="border-b border-black pb-4">
      <div class="flex justify-between items-start">
        <div class="text-left text-sm leading-snug">
          <h1 class="text-4xl font-bold">DMM BR_1</h1>
          <p>Yousaf Shah Khan Plaza near <br>Taj Cenima Shaheedan Bazaar Mardan</p>
          <p>Phone: 0300-1234567</p>
          <p>Seller: Zahid Mehmood</p>
        </div>
        <div class="text-right">
          <h2 class="text-lg font-semibold underline">INVOICE</h2>
        </div>
      </div>
      <div class="flex justify-center mt-2">
        <img id="qr-code" src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=Invoice" alt="QR Code" class="w-[2.5cm] h-[2.5cm] border border-black p-1">
      </div>
    </header>

    <!-- Customer Info -->
    <section class="mt-4 text-sm border-b border-black pb-2 grid grid-cols-2 gap-y-1">
      <div>
        <p><span class="font-semibold">Customer:</span> <span id="customer-name"></span></p>
        <p><span class="font-semibold">Phone:</span> <span id="customer-phone"></span></p>
      </div>
      <div class="text-right">
        <p><span class="font-semibold">Invoice No:</span> <span id="invoice-no"></span></p>
        <p><span class="font-semibold">Date:</span> <span id="invoice-date"></span></p>
      </div>
    </section>

    <!-- Invoice Table -->
    <section class="mt-4 text-sm">
      <table class="w-full table-auto border border-black border-collapse">
        <thead>
          <tr class="border-b border-black bg-gray-200">
            <th class="border-r border-black px-2 py-1">#</th>
            <th class="border-r border-black px-2 py-1 text-left">Product</th>
            <th class="border-r border-black px-2 py-1 text-left">IMEI(s)</th>
            <th class="border-r border-black px-2 py-1">Qty</th>
            <th class="border-r border-black px-2 py-1 text-right">Price</th>
            <th class="px-2 py-1 text-right">Total</th>
          </tr>
        </thead>
        <tbody id="invoice-items-body">
          <!-- Items will be injected here -->
        </tbody>
      </table>
    </section>

    <!-- Spacer to push content down -->
    <div class="flex-grow"></div>

    <!-- Payment Section with Message Box -->
    <section class="text-sm border-t border-black pt-2 mt-auto">
      <div class="flex justify-between items-start">
        <div class="w-1/2 pr-4">
          <div class="bg-gray-100 border border-gray-300 rounded p-2 text-xs leading-snug">
            <p class="font-semibold text-[18px]">Note:</p>
            <p class="text-[15px]">Please retain this invoice for warranty & exchange. No claims will be entertained without it. Thank you for your trust!</p>
          </div>
        </div>
        <div class="w-1/2 text-right">
          <div class="flex justify-between"><span>Subtotal:</span><span id="sub-total"></span></div>
          <div class="flex justify-between font-bold border-t border-black mt-1 pt-1"><span>Total:</span><span id="total-amount"></span></div>
          <div class="flex justify-between"><span>Received:</span><span id="received-amount"></span></div>
          <div class="flex justify-between"><span>Balance:</span><span id="remaining-amount"></span></div>
          <div class="flex justify-between"><span>Prev Balance:</span><span id="previous-balance"></span></div>
          <div class="flex justify-between font-bold bg-gray-200 px-1"><span>Grand Total:</span><span id="grand-total"></span></div>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer style="margin-top: 20;" class="mt-4 text-center text-sm border-t border-black pt-2">
      <p>A Smart Solution By Farhan Shah | 031234567890</p>
      <p>www.developer-farhanshah.netlify.app</p>
    </footer>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
        const dataString = sessionStorage.getItem('invoicePrintData');
        if (!dataString) {
            document.body.innerHTML = "<h1>No invoice data found. Please create an invoice first.</h1>";
            return;
        }
        
        const data = JSON.parse(dataString);
        const formatCurrency = (val) => `Rs. ${parseFloat(val).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

        // Populate header and customer info
        document.getElementById('customer-name').textContent = data.customer_name;
        document.getElementById('customer-phone').textContent = data.phone_no;
        document.getElementById('invoice-no').textContent = data.invoice_no;
        document.getElementById('invoice-date').textContent = new Date(data.invoice_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
        document.getElementById('qr-code').src = `https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(data.invoice_no)}`;
        
        // Populate items table
        const itemsBody = document.getElementById('invoice-items-body');
        itemsBody.innerHTML = '';
        data.items.forEach((item, index) => {
            const row = document.createElement('tr');
            row.className = 'border-b border-black';
            const itemStatus = item.status === 'Returned' ? ' <span class="font-bold text-red-600 returned-tag">(Returned)</span>' : '';
            
            row.innerHTML = `
                <td class="border-r border-black px-2 py-1 text-center align-top">${index + 1}</td>
                <td class="border-r border-black px-2 py-1 align-top">${item.product_name} (${item.specification})${itemStatus}</td>
                <td class="border-r border-black px-2 py-1 align-top text-xs">${item.imei_texts.join('<br>')}</td>
                <td class="border-r border-black px-2 py-1 text-center align-top">${item.qty}</td>
                <td class="border-r border-black px-2 py-1 text-right align-top">${formatCurrency(item.price)}</td>
                <td class="px-2 py-1 text-right align-top">${formatCurrency(item.total)}</td>
            `;
            itemsBody.appendChild(row);
        });

        // Populate totals
        document.getElementById('sub-total').textContent = formatCurrency(data.totals.invoice_amount);
        document.getElementById('total-amount').textContent = formatCurrency(data.totals.invoice_amount);
        document.getElementById('received-amount').textContent = formatCurrency(data.totals.received_amount);
        document.getElementById('remaining-amount').textContent = formatCurrency(data.totals.remaining_amount);
        document.getElementById('previous-balance').textContent = formatCurrency(data.totals.previous_balance);
        document.getElementById('grand-total').textContent = formatCurrency(data.totals.grand_total);
        
        // Print and clean up
        setTimeout(() => {
            window.print();
            window.onafterprint = () => {
                sessionStorage.removeItem('invoicePrintData');
                // window.close(); // Optional: close the tab after printing
            };
        }, 500); // Small delay to ensure all content is rendered
    });
  </script>
</body>
</html>